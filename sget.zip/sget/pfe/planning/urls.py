from django.conf.urls import url

from . import views

urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'^new_semestre/$', views.initialisation, name ='nouveau_semestre'),
    url(r'^planning/$',views.planning, name ='planning_semaine'),
    url(r'^profile/$',views.profile, name ='profil'),
    url(r'^validation/$',views.validation, name ='emploi_de_temps'),
    url(r'^valide/$',views.valide, name ='mon_niveau'),
    url(r'^publication/$',views.publication, name='publier'),
    url(r'^iut/$',views.iut, name='iut-fv'),
    url(r'^statistique/$',views.statistique, name='statistique'),
    url(r'^confirmation/$',views.confirme, name='confirmation'),
    
   

]