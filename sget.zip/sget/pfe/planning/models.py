from django.db import models
from .fonction import *
from django.contrib.auth.backends import BaseBackend
from django.contrib.auth.hashers import check_password
from django.contrib.auth.models import User, Group


# Create your models here.

class Personne(User):
	"""classe de tous les utilisateurs confondus qui sera associer a un role dans la table role"""

	telephone = models.CharField(max_length=25, unique=True)
	# matricule = models.CharField(max_length=200, unique=True, null=True)
	# email_parent1 = models.CharField(max_length=200, null=True)
	# email_parent2 = models.CharField(max_length=200, null=True)
	# role = models.ForeignKey(Role, on_delete=models.CASCADE)

	def is_etudiant(self):
		return self.groups.filter(name='Etudiant').exists()

	def is_parent(self):
		return self.groups.filter(name='Parent').exists()

	def is_delegue(self):
		return self.groups.filter(name='Delegue').exists()

	def is_professeur(self):
		return self.groups.filter(name='Professeur').exists()

	def is_responsable_niveau(self):
		return self.groups.filter(name='Responsable de Niveau').exists()

	def is_chef_departement(self):
		return self.groups.filter(name='Chef de Departement').exists()



class Professeur(Personne):
	titre = models.CharField(max_length=25, default='M.')


	def affiche_matiere(self):
		return Matiere.objects.filter(professeur=self.id)

	def professeur_occuper(self, jour, debut):
		heures = DoubleHeure.objects.filter(jour__date_jour=jour, heure_debut=debut,  etat='valider').filter(matiere__in = Matiere.objects.filter(professeur=self.id))
		if not heures:
			return True

		else :
			return False

	def delete_profesor_heure(self, jour, debut):
		"""
		cette methode supprime toutes les sollicitations d'heure dans la meme plage d'heure du professeur

		"""
		heures = DoubleHeure.objects.filter(jour__date_jour=jour, heure_debut=debut)
		
		#matieres = heures.matieres.filter(professeur=self.id)
		for heure in heures:
			for matiere in heure.matieres.all():
				if(matiere.professeur.id==self.id):
					heure.matieres.remove(matiere)
					# heure1.delete()

	def __str__(self):
		nom = str(self.titre)+" "+str(self.first_name)+" "+str(self.last_name)
		return nom
					


		



class ResponsableNiveau(Professeur):
	pass

class ChefDepartement(Professeur):
	pass



	


class Departement(models.Model):
	"""
	la classe departement comprend un chef de departement et regroupe un ensemble defiliere
	"""
	libelle = models.CharField(max_length=200, unique=True)
	description = models.TextField(null=True)
	nbre_filiere = models.PositiveSmallIntegerField(null=True)
	professeurs = models.ManyToManyField(Professeur, related_name='depart', blank=True)
	chef_departement = models.ForeignKey(ChefDepartement, on_delete= models.CASCADE, null=True)

	def __str__(self):
		return self.libelle


	def affiche_filieres(self):
		return Filiere.objects.filter(departement=self)


	def affiche_enseignants(self):
		return Professeur.objects.filter(depart=self)

	


class Filiere(models.Model):
	"""
	la classe filiere a un responsable de niveau a sa tete et un certains nombre d'etudiant 
	aussi une filiere appartient toujours a un departement
	"""
	libelle = models.CharField(max_length=200, unique=True)
	description = models.TextField(null=True)
	abrege = models.CharField(max_length=100,null=True)
	nbre_etudiant = models.PositiveSmallIntegerField(null=True)
	niveau = models.PositiveSmallIntegerField()
	departement = models.ForeignKey(Departement, on_delete=models.CASCADE)
	responsable_niveau = models.ForeignKey(ResponsableNiveau, on_delete= models.PROTECT)

	def __str__(self):
		return self.libelle

	def affiche_options(self):
		return Classe.objects,filter(filiere=self)

	def affiche_abrege(self):
		if self.abrege:
			return self.abrege
		else :
			return 'GI'




class Classe(models.Model):
	"""
	la classe classe a un delegue comme responsable et un certains nombre d'etudiant. une classe recoit des matiere
	dispenser a plusieurs professeur
	"""
	libelle = models.CharField(max_length=200)
	abrege = models.CharField(max_length=10, null=True)
	nbre_etudiant = models.PositiveSmallIntegerField(default=0)
	filiere = models.ForeignKey(Filiere, on_delete=models.CASCADE)
	# delegue = models.OneToOneField(Delegue, on_delete= models.PROTECT)

	def __str__(self):
		return self.libelle

	def affiche_etudiants():
		return Etudiant.objects.filter(option=self)


class Etudiant(Personne):
	option = models.ForeignKey(Classe, on_delete=models.PROTECT)

	def __str__(self):
		return self.username

	def getplanningsemaine(self):
		planning = PlanningSemaine.objects.get(date_debut=debut_semaine() , classe=self.option)
		return planning.id


class Delegue(Etudiant):
	"""docstring for Delegue"""
	pass

class Parent(Personne):
	enfants = models.ManyToManyField(Etudiant, related_name='parent', blank=True)

	def getenfant(self):
		enfants = Etudiant.objects.filter(parent=self)
		return enfants
	


class Ressource(models.Model):
	"""
	classe des ressources critiques comme les salles de classes, le video-projecteur, le micro...
	le delegue est reponsable de ces ressource qui sont dans la personnalite du departement
	"""
	libelle = models.CharField(max_length=200)
	description = models.TextField()	
	# etat = models.CharField(max_length=100)
	# typeR = models.CharField(max_length=100)
	departement = models.ForeignKey(Departement, on_delete=models.CASCADE)
	

	def __str__(self):
		return self.libelle

	def libererRessource(self):
		if self.classe.exists():
			self.classe = None

	def getHeureLibre(self, heure):
		if heure.salle==self:
			return False
		else:
			return True





class SalleDeClasse(Ressource):
	"""

	"""
	nombre_place = models.PositiveSmallIntegerField()
	porte = models.CharField(max_length=10)

	def __str__(self):
		return str(self.porte)




class AnneeAcademique(models.Model):
	libelle = models.CharField(max_length=25, unique=True)
	

	def __str__(self):
		return self.libelle
	
	


class Semestre(models.Model):
	numero = models.PositiveSmallIntegerField()
	lmd = models.PositiveSmallIntegerField()
	date_debut = models.DateField()
	date_fin = models.DateField()
	annee = models.ForeignKey(AnneeAcademique, on_delete=models.CASCADE)

	def __str__(self):
		chaine = 'S'+str(self.numero)+'/lmd'+str(self.lmd)
		return chaine



class Module(models.Model):
	"""
		un module represente le blog dans le quel est ranger chaque matiere dons une matiere est forcement dans un
		module. les modules sont supdivise en deux 'obligatiore' et 'libre'. tous ont  comme type de module nous pouvons avoir les modules 
	
		-  transversale
		-  fondamentale
		-  professionnel
		-  
	"""
	libelle = models.CharField(max_length=200, null=True)
	code = models.CharField(max_length=10, unique=True)
	# categorie_module = models.CharField(max_length=100,default='Obligatoire')
	type_module = models.CharField(max_length=25)
	nbre_credit = models.PositiveSmallIntegerField()
	nbre_heure = models.PositiveSmallIntegerField()
	tpe = models.PositiveSmallIntegerField(null=True)
	numero_semestre= models.PositiveSmallIntegerField(default=1)
	option = models.ForeignKey(Classe, on_delete=models.CASCADE, null=True)
	
	def __str__(self):
		return self.libelle


class Matiere(models.Model):
	"""
	une matiere est dispenser par un professeur dans une classe professeur = models.ForeignKey(Professeur, null=True, on_delete=models.PROTECT)
	enseignant_td = models.ForeignKey(Professeur, null=True, on_delete=models.PROTECT, related_name='matiere_td')
	enseignant_tp a une moment precis et appartient forcement a 
	un module dans la gruille des matiere du departement
	"""
	libelle = models.CharField(max_length=200)
	code =  models.CharField(max_length=10, unique=True)
	credit = models.PositiveSmallIntegerField()
	heure_magistral = models.PositiveSmallIntegerField()
	heure_tpe = models.PositiveSmallIntegerField( default=0)
	heure_tp = models.PositiveSmallIntegerField( default=0)
	heure_td = models.PositiveSmallIntegerField(default=0)
	total_heure  = models.PositiveSmallIntegerField()
	professeur = models.ForeignKey(Professeur, null=True, on_delete=models.PROTECT)
	enseignant_td = models.ForeignKey(Professeur, null=True, on_delete=models.PROTECT, related_name='matiere_td')
	enseignant_tp = models.ForeignKey(Professeur, null=True, on_delete=models.PROTECT, related_name='matiere_tp')

	option = models.ForeignKey(Classe, null=True, on_delete=models.CASCADE)
	module = models.ForeignKey(Module, on_delete=models.CASCADE)


	def __str__(self):
		return self.libelle


class Statistique(models.Model):
	"""docstring for Statistique"""

	heure_magistral_effectuer = models.PositiveSmallIntegerField(default=0)
	heure_tp_effectuer = models.PositiveSmallIntegerField(default=0)
	heure_td_effectuer = models.PositiveSmallIntegerField(default=0)
	heure_total_effectuer = models.PositiveSmallIntegerField(default=0)
	
	semestre = models.ForeignKey(Semestre,  on_delete=models.PROTECT)
	matiere = models.ForeignKey(Matiere,  on_delete=models.PROTECT)
	classe = models.ForeignKey(Classe,  on_delete=models.PROTECT)
	
	def __str__(self):

		return str(self.heure_total_effectuer)+" / "+str(self.matiere.total_heure)

	def effectuer_statistique(self, heure):

		heure= DoubleHeure.objects.get(pk=heure)
		self.heure_total_effectuer= self.heure_total_effectuer + 2

		if heure.enseignant == heure.matiere.enseignant_td :
			self.heure_td_effectuer= self.heure_td_effectuer + 2

		elif heure.enseignant == heure.matiere.enseignant_tp:
			self.heure_tp_effectuer =self.heure_tp_effectuer + 2

		else :
			self.heure_magistral_effectuer=self.heure_magistral_effectuer + 2

		self.save()





class  PlanningSemaine(models.Model):
	"""
	un planning est composer de 6 jour de la semaine de lundi a samedi les different etat de celui ci sont :
	- 'non valider'
	- 'valider'
	- 'publier'
	"""
	date_debut = models.DateField(auto_now=False, auto_now_add=False)
	date_fin = models.DateField(auto_now=False, auto_now_add=False)
	numero = models.PositiveSmallIntegerField()
	etat = models.CharField(max_length=100)
	classe = models.ForeignKey(Classe, on_delete=models.CASCADE)
	responsable_niveau = models.ForeignKey(Professeur, on_delete= models.PROTECT)
	semestre = models.ForeignKey(Semestre, on_delete=models.CASCADE, null=True)

	def __str__(self):
		nom_semaine= 'emploi de temps :'+ str(self.date_debut) + ' à ' + str(self.date_fin) + ' Semaine No '+str(self.numero)
		return nom_semaine

	def affiche_jour(self):
		jours = Jour.objects.filter(planning=self.id)
		return jours

	def descrip_semaine(self):

		string = str(self.date_debut.day)+"/"+str(self.date_debut.month)+"/"+str(self.date_debut.year)+" au "+str(self.date_fin.day)+"/"+str(self.date_fin.month)+"/"+str(self.date_fin.year)
		
		
		return string

class  PlanningEnseignant(models.Model):
	"""
	un planning de l'enseignant est composer de 6 jour de la semaine de lundi a samedi 
	"""
	date_debut = models.DateField(auto_now=False, auto_now_add=False)
	date_fin = models.DateField(auto_now=False, auto_now_add=False)
	numero = models.PositiveSmallIntegerField()		
	enseignant = models.ForeignKey(Professeur, on_delete= models.PROTECT)
	semestre = models.ForeignKey(Semestre, on_delete=models.CASCADE)

	def __str__(self):
		nom_semaine= 'emploi de temps :'+ str(self.date_debut) + ' à ' + str(self.date_fin) + ' Semaine No '+str(self.numero)
		return nom_semaine

	def affiche_jour(self):
		jours = Jour.objects.filter(planning=self.id)
		
		
		return jours

	def semaine_planning_professeur(self):
		semaine= PlanningEnseignant.objects.get(date_debut=debut_semaine(), enseignant=self.enseignant)
		# planning = PlanningSemaine.objects.get(date_debut=debut_semaine())
		jours=Jour.objects.filter(planning_enseignant=semaine, )

		lundi=jours.filter(libelle='lundi')
		mardi=jours.filter(libelle='mardi')
		mercredi=jours.filter(libelle='mercredi')
		jeudi=jours.filter(libelle='jeudi')
		vendredi=jours.filter(libelle='vendredi')
		samedi=jours.filter(libelle='samedi')

		jour= {
			'lundi': lundi[0].les_heure_professeur(),
			'mardi': mardi[0].les_heure_professeur(),
			'mercredi': mercredi[0].les_heure_professeur(),
			'jeudi': jeudi[0].les_heure_professeur(),
			'vendredi': vendredi[0].les_heure_professeur(),
			'samedi': samedi[0].les_heure_professeur(),
		}

		return jour
		# jour__planning_enseignant=semaine

	def heure_planning_professeur(self):
		semaine= PlanningEnseignant.objects.get(date_debut=debut_semaine(), enseignant=self.enseignant)
		heures= HeureProfesseur.objects.filter(jour__planning_enseignant=semaine)
		if not heures.exists():
			return { 
			'lundi_h1': semaine.id, 
			'lundi_h2': '-----', 
			'lundi_h3': '-----', 
			'lundi_h4': '-----',

			'mardi_h1': '-----', 
			'mardi_h2': '-----', 
			'mardi_h3': '-----', 
			'mardi_h4': '-----',

			'mercredi_h1': '-----', 
			'mercredi_h2': '-----', 
			'mercredi_h3': '-----', 
			'mercredi_h4': '-----',

			'jeudi_h1': '-----', 
			'jeudi_h2': '-----', 
			'jeudi_h3': '-----', 
			'jeudi_h4': '-----',

			'vendredi_h1': '-----', 
			'vendredi_h2': '-----', 
			'vendredi_h3': '-----', 
			'vendredi_h4': '-----',

			'samedi_h1': '-----', 
			'samedi_h2': '-----', 
			'samedi_h3': '-----', 
			'samedi_h4': '-----',
			}

		h1l= heures.filter(heure_debut=datetime.time(7,30), jour__libelle='lundi')
		if not h1l.exists():
			h1l='-----'
		else :
			h1l= h1l[0]

		
		h2l= heures.filter(heure_debut=datetime.time(9,30), jour__libelle='lundi')
		if not h2l.exists():
			h2l='-----'
		else:
			h2l=h2l[0]

		h3l= heures.filter(heure_debut=datetime.time(12,00), jour__libelle='lundi')
		if not h3l.exists():
			h3l='-----'
		else :
			h3l=h3l[0]

		h4l= heures.filter(heure_debut=datetime.time(14,00), jour__libelle='lundi')
		if not h4l.exists():
			h4l='-----'
		else :
			h4l=h4l[0]



		h1m= heures.filter(heure_debut=datetime.time(7,30), jour__libelle='mardi')
		if not h1m.exists():
			h1m='-----'
		else :
			h1m= h1m[0].id

		h2m= heures.filter(heure_debut=datetime.time(9,30), jour__libelle='mardi')
		if not h2m.exists():
			h2m='-----'
		else:
			h2m=h2m[0]

		h3m= heures.filter(heure_debut=datetime.time(12,00), jour__libelle='mardi')
		if not h3m.exists():
			h3m='-----'
		else :
			h3m=h3m[0]

		h4m= heures.filter(heure_debut=datetime.time(14,00), jour__libelle='mardi')
		if not h4m.exists():
			h4m='-----'
		else :
			h4m=h4m[0]

		h1M= heures.filter(heure_debut=datetime.time(7,30), jour__libelle='mercredi')
		if not h1M.exists():
			h1M='-----'
		else :
			h1M= h1M[0]

		h2M= heures.filter(heure_debut=datetime.time(9,30), jour__libelle='mercredi')
		if not h2M.exists():
			h2M='-----'
		else:
			h2M=h2M[0]

		h3M= heures.filter(heure_debut=datetime.time(12,00), jour__libelle='mercredi')
		if not h3M.exists():
			h3M='-----'
		else :
			h3M=h3M[0]

		h4M= heures.filter(heure_debut=datetime.time(14,00), jour__libelle='mercredi')
		if not h4M.exists():
			h4M='-----'
		else :
			h4M=h4M[0]

		h1j= heures.filter(heure_debut=datetime.time(7,30), jour__libelle='jeudi')
		if not h1j.exists():
			h1j='-----'
		else :
			h1j= h1j[0]

		h2j= heures.filter(heure_debut=datetime.time(9,30), jour__libelle='jeudi')
		if not h2j.exists():
			h2j='-----'
		else:
			h2j=h2j[0]

		h3j= heures.filter(heure_debut=datetime.time(12,00), jour__libelle='jeudi')
		if not h3j.exists():
			h3j='-----'
		else :
			h3j=h3j[0]

		h4j= heures.filter(heure_debut=datetime.time(14,00), jour__libelle='jeudi')
		if not h4j.exists():
			h4j='-----'
		else :
			h4j=h4j[0]



		h1v= heures.filter(heure_debut=datetime.time(7,30), jour__libelle='vendredi')
		if not h1v.exists():
			h1v='-----'
		else :
			h1v= h1v[0]

		h2v= heures.filter(heure_debut=datetime.time(9,30), jour__libelle='vendredi')
		if not h2v.exists():
			h2v='-----'
		else:
			h2v=h2v[0]

		h3v= heures.filter(heure_debut=datetime.time(12,00), jour__libelle='vendredi')
		if not h3v.exists():
			h3v='-----'
		else :
			h3v=h3v[0]

		h4v= heures.filter(heure_debut=datetime.time(14,00), jour__libelle='vendredi')
		if not h4v.exists():
			h4v='-----'
		else :
			h4v=h4v[0]


		h1s= heures.filter(heure_debut=datetime.time(7,30), jour__libelle='samedi')
		if not h1s.exists():
			h1s='-----'
		else :
			h1s= h1s[0]

		h2s= heures.filter(heure_debut=datetime.time(9,30), jour__libelle='samedi')
		if not h2s.exists():
			h2s='-----'
		else:
			h2s=h2s[0]

		h3s= heures.filter(heure_debut=datetime.time(12,00), jour__libelle='samedi')
		if not h3s.exists():
			h3s='-----'
		else :
			h3s=h3s[0]

		h4s= heures.filter(heure_debut=datetime.time(14,00), jour__libelle='samedi')
		if not h4s.exists():
			h4s='-----'
		else :
			h4s=h4s[0]

		return { 
			'lundi_h1': h1l, 
			'lundi_h2': h2l, 
			'lundi_h3': h3l, 
			'lundi_h4': h4l,

			'mardi_h1': h1m, 
			'mardi_h2': h2m, 
			'mardi_h3': h3m, 
			'mardi_h4': h4m,

			'mercredi_h1': h1M, 
			'mercredi_h2': h2M, 
			'mercredi_h3': h3M, 
			'mercredi_h4': h4M,

			'jeudi_h1': h1j, 
			'jeudi_h2': h2j, 
			'jeudi_h3': h3j, 
			'jeudi_h4': h4j,

			'vendredi_h1': h1v, 
			'vendredi_h2': h2v, 
			'vendredi_h3': h3v, 
			'vendredi_h4': h4v,

			'samedi_h1': h1s, 
			'samedi_h2': h2s, 
			'samedi_h3': h3s, 
			'samedi_h4': h4s,
		}


class Jour(models.Model):
	"""
	"""
	libelle = models.CharField(max_length=50)
	date_jour = models.DateField()
	jour_ferier = models.BooleanField(default=False)
	planning = models.ForeignKey(PlanningSemaine, on_delete=models.CASCADE)
	planning_enseignant = models.ManyToManyField(PlanningEnseignant, blank=True, related_name='jour')

	def __str__(self):
		return self.libelle

	def heure_journe(self):
		heures=DoubleHeure.objects.filter(jour=self.id)
		return {'h1': heures.get(heure_debut=datetime.time(7,30)), 'h2': heures.get(heure_debut=datetime.time(9,30)), 'h3': heures.get(heure_debut=datetime.time(12)), 'h4': heures.get(heure_debut=datetime.time(14)) }

	def les_heure_professeur(self):
		heures= HeureProfesseur.objects.filter(jour=self.id)

		if not heures.exists():
			return { 'h1': '-----', 'h2': '-----', 'h3': '-----', 'h4': '-----' }

		h1= heures.filter(heure_debut=datetime.time(7,30))
		if not h1.exists():
			h1='-----'
		else :
			h1= h1[0]

		h2= heures.filter(heure_debut=datetime.time(9,30))
		if not h2.exists():
			h2='-----'
		else:
			h2=h2[0]

		h3= heures.filter(heure_debut=datetime.time(12,00))
		if not h3.exists():
			h3='-----'
		else :
			h3=h3[0]

		h4= heures.filter(heure_debut=datetime.time(14,00))
		if not h4.exists():
			h4='-----'
		else :
			h4=h4[0]

		return { 'h1': h1, 'h2': h2, 'h3': h3, 'h4': h4 }





class DoubleHeure(models.Model):
	"""
	la double heure a 4 etat 'non attribuer', 'en attende de validation', 'valider', 'attribuer', 'effectif'. la journee est diviser en 
	4 double heure le professeur sollicite les responsable de niveau attribut ret le chef de departement publie et les delegue
	approuve l'effectivite du cour a cet heure.
	"""
	heure_debut = models.TimeField(auto_now=False, auto_now_add=False)
	heure_fin = models.TimeField(auto_now=False, auto_now_add=False)
	etat = models.CharField(max_length=100)
	cour_effectif = models.BooleanField(default=False)	
	enseignant = models.ForeignKey(Professeur, on_delete= models.PROTECT, null=True)
	enseignants = models.ManyToManyField(Professeur, related_name='heure', blank=True)
	jour = models.ForeignKey(Jour, on_delete=models.CASCADE)
	matiere = models.ForeignKey(Matiere, on_delete= models.PROTECT, null=True)
	matieres = models.ManyToManyField(Matiere, related_name='heure', blank=True)
	salle = models.ForeignKey(SalleDeClasse, related_name='heure', on_delete= models.PROTECT, null=True)

	def __str__(self):
		
		if self.matiere:
			
			if self.enseignant == self.matiere.enseignant_td:
				nom_heure ="TD de "+str(self.matiere)+" : \n "+str(self.matiere.enseignant_td)
			elif self.enseignant == self.matiere.enseignant_tp:
				nom_heure ="TP de "+str(self.matiere)+" : \n "+str(self.matiere.enseignant_tp)
			else:
				nom_heure =str(self.matiere)+" : \n "+str(self.matiere.professeur)

			if self.salle:
				nom_heure = nom_heure+" : porte \n " + str(self.salle)

			if self.etat == 'effectif':
				nom_heure = nom_heure+" \n effectuer "
			
			return nom_heure

		else:
			return " --- "

	def affiche_enseignant(self):
		if self.enseignant:
			return self.enseignant
		else :
			return '-----'

	def affiche_matiere(self):

		if self.matiere:
			return self.matiere
		return '---'


	def affiche_matiere_dispo(self):
		

		return Matiere.objects.filter(option = self.jour.planning.classe.id).exclude(professeur__in = Professeur.objects.filter(matiere__doubleheure__etat='valider', matiere__doubleheure__jour__date_jour=self.jour.date_jour, matiere__doubleheure__heure_debut=self.heure_debut, ))


	def affiche_salle_dispo(self):
		return SalleDeClasse.objects.filter(departement= self.jour.planning.classe.filiere.departement)
		# .exclude(heure__in= DoubleHeure.objects.filter(etat= 'valider', jour__date_jour=self.jour.date_jour, heure_debut= self.heure_debut))


class HeureProfesseur(models.Model):
	heure_debut = models.TimeField(auto_now=False, auto_now_add=False)
	heure_fin = models.TimeField(auto_now=False, auto_now_add=False)	
	professeur = models.ForeignKey(Professeur, on_delete= models.PROTECT)
	matiere = models.ForeignKey(Matiere, on_delete= models.PROTECT)
	jour = models.ForeignKey(Jour, on_delete=models.CASCADE)
	option = models.ForeignKey(Classe, on_delete= models.PROTECT, null=True)
	salle = salle = models.ForeignKey(SalleDeClasse, on_delete= models.PROTECT, null=True)

	def __str__(self):
		nom_heure= str(self.matiere)
		if self.professeur == self.matiere.enseignant_td:
			nom_heure ="TD de "+str(self.matiere)
		elif self.professeur == self.matiere.enseignant_tp:
			nom_heure ="TP de "+str(self.matiere)
		else:
			nom_heure =str(self.matiere)

		if self.option:
			nom_heure= nom_heure +" en \n"+ str(self.option.abrege)
		if self.salle:
			nom_heure= nom_heure +" a la porte \n" + str(self.salle)

		return nom_heure

class emploie_de_temps(models.Model):
	jours = models.CharField(max_length=100)
	semaine = models.CharField(max_length=100)
	descrip_semaine = models.CharField(max_length=100)
	matiere1 = models.CharField(max_length=100)
	ens_matiere1 = models.CharField(max_length=100)
	matiere2 = models.CharField(max_length=100)
	ens_matiere2 = models.CharField(max_length=100)
	matiere3 = models.CharField(max_length=100)
	ens_matiere3 = models.CharField(max_length=100)
	matiere4 = models.CharField(max_length=100)
	ens_matiere4 = models.CharField(max_length=100)
	option = models.CharField(max_length=100)
	filiere = models.CharField(max_length=100)