import time
import datetime
from .models import *

def ajout_date_1(datte):
	d1=datte.day + 1
	m1=datte.month
	y1=datte.year
	if(m1%2==1 and m1<=7) or (m1%2==0 and m1>=8):
		if(d1>31):
			d1=1
			m1=m1+1
			if(m1>12):
				m1=1
				y1+=1
	else :
		if (m1==2):
			if annee_bissetille(y1):
				if(d1>29):
					d1=1
					m1+=1
			else:
				if(d1>28):
					d1=1
					m1+=1
		else:
			if(d1>30):
				d1=1
				m1+=1
	return datetime.date(y1,m1,d1)

def recul_jour(datte):
	d1=datte.day - 1
	m1=datte.month
	y1=datte.year
	if d1==0:
		if(m1%2==1 and m1<=7) or (m1%2==0 and m1>=8):
			if(m1==3):
				if annee_bissetille(y1):
					d1=29
				else:
					d1=28

			else :
				d1=30

		else :
			d1=31
		m1-=1
		if m1==0:
			m1=12
			y1-=1
	return datetime.date(y1,m1,d1)


def annee_bissetille(annee):
	if((annee%4) == 0):
		if ((annee%100)==0):
			if ((annee%400)==0):
				return True
			else:
				return False
		else:
			return True
	else:
		return False
		
def semaine(fin, debut):
	"""fonction qui prend en parametre une date de debut et une date de fin et renvoie le nombre de semaine ecouler 
	entre les deux date"""
	datte=debut
	njour=0
	while (datte<fin ):
		datte=ajout_date_1(datte)
		njour+=1
	sem=njour//7
	return sem

def ajout_semaine_1(debut):
	for i in range(5):
		debut=ajout_date_1(debut)
	return debut

def defaut_date(ans,mois,jour):
	return datetime.date(ans,mois,jour)


def debut_semaine():
	jour=datetime.date.today()
	t1=time.localtime()
	numero_jour=time.localtime().tm_wday
	while numero_jour != 0:
		numero_jour-=1
		jour=recul_jour(jour)
	return jour

def debut_semaine_prochaine():
	jour= debut_semaine()
	
	for i in range(1,8):		
		jour=ajout_date_1(jour)
	return jour

