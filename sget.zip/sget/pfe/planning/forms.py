from django.forms import ModelForm
from django.contrib.auth.forms import UserCreationForm
from .models import *
from django import forms


class SemestreForm(ModelForm):
	numero = forms.IntegerField(
        widget=forms.NumberInput(
            attrs={
                "placeholder" : "",                
                "class": "form-control"
            }
        ))
	lmd = forms.IntegerField(
        widget=forms.NumberInput(
            attrs={
                "placeholder" : "",                
                "class": "form-control"
            }
        ))
	date_debut = forms.DateField(
        widget=forms.DateInput(
            attrs={
                "placeholder" : "",                
                "class": "form-control"
            }
        ))
	date_fin = forms.DateField(
        widget=forms.DateInput(
            attrs={
                "placeholder" : "",                
                "class": "form-control"
            }
        ))
	annee = forms.ModelChoiceField(
		queryset=AnneeAcademique.objects.all(),
		widget=forms.Select(
            attrs={
                "placeholder" : "",                
                "class": "form-control"
            }
        ))
	class Meta:
		model = Semestre
		fields = '__all__'

   
class DepartementForm(ModelForm):
	class Meta:
		model = Departement
		fields = ('libelle',)





class ClasseForm(ModelForm):
	class Meta:
		model = Classe
		fields = ('libelle',)





class SignUpForm(UserCreationForm):
    username = forms.CharField(
        widget=forms.TextInput(
            attrs={
                "placeholder" : "Username",                
                "class": "form-control"
            }
        ))
    email = forms.EmailField(
        widget=forms.EmailInput(
            attrs={
                "placeholder" : "Email",                
                "class": "form-control"
            }
        ))
    password1 = forms.CharField(
        widget=forms.PasswordInput(
            attrs={
                "placeholder" : "Password",                
                "class": "form-control"
            }
        ))
    password2 = forms.CharField(
        widget=forms.PasswordInput(
            attrs={
                "placeholder" : "Password check",                
                "class": "form-control"
            }
        ))
    telephone = forms.CharField(
        widget=forms.NumberInput(
            attrs={
                "placeholder" : "Phone",                
                "class": "form-control"
            }
        ))

    class Meta:
        model = Parent
        fields = ('username', 'email', 'password1', 'password2', 'telephone')
