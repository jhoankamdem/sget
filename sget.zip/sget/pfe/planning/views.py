from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login
from django.shortcuts import render, get_object_or_404, redirect
from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from django.template import loader
from django import template
from .models import *
from django.contrib.auth.models import User, Group
from .forms import *
from .fonction import *
from django.db.models import Q

# Create your views here.


@login_required(login_url="/auth/login/")
def index(request):
	personne = Personne.objects.get(pk=request.user.id)
	if personne.is_etudiant():
		etudiant = Etudiant.objects.get(pk=request.user.id)
		personne='etudiant'
		dele = Delegue.objects.filter(pk=request.user.id)
		if dele.exists():
			personne= 'del'
		msg = None
		success = False
		niveau = ''
		if request.method == "POST":
			form = SignUpForm(request.POST)
			if form.is_valid():
				
				parent = Parent(username=form.cleaned_data.get("username") , password=form.cleaned_data.get("password1") , telephone=form.cleaned_data.get("telephone") , email=form.cleaned_data.get("email") )
				parent.save()
				groupe= Group.objects.get(name='Parent')
				parent.groups.add(groupe)
				parent.enfants.add(etudiant)
				parent.save()
				
				debut_semaine_prochaine()
			else :
				msg = 'Form is not valid'
		else:
			form = SignUpForm()

		context = {
			'personne': personne,
			'form': form,
			'msg' : msg,
			'success' : success,
			'niveau': niveau,
		}
	elif personne.is_parent():
		parent = Parent.objects.get(pk=request.user.id)

		context = {
			'personne': 'parent',
			'enfants': parent.enfants.all(),			
			
		}
	elif personne.is_professeur():
		prof = Professeur.objects.get(pk=request.user.id)
		personne= 'prof'
		planningprof=PlanningEnseignant.objects.get(date_debut=debut_semaine() , enseignant=prof)

		rn = ResponsableNiveau.objects.filter(pk=request.user.id)
		if rn.exists():
			personne= 'rn'

		ch = ChefDepartement.objects.filter(pk=request.user.id)
		if ch.exists():
			personne= 'chd'
		
		
		context = {
			'personne': personne,
			'filiere': '',
			'prof': prof,
			'planning': planningprof,
			'heure': planningprof.heure_planning_professeur(),
		}
	
	template = loader.get_template('index.html')
	return HttpResponse(template.render(context, request=request))


@login_required(login_url="/auth/login/")
def initialisation(request):
	pers=Personne.objects.get(pk=request.user.id)
	if pers.is_responsable_niveau():
		if request.method == 'POST':
			form = SemestreForm(request.POST)

			if form.is_valid():
				numero=form.cleaned_data['numero']
				

				
				annees=AnneeAcademique.objects.get(libelle=form.cleaned_data['annee'])

				semestre=Semestre(numero=numero, lmd=request.POST.get('lmd'), date_debut=form.cleaned_data['date_debut'], date_fin= form.cleaned_data['date_fin'])
				semestre.annee=annees
				semestre.save()



				responsable_niveau = ResponsableNiveau.objects.get(id=pers.id)
				

				h1 = datetime.time(7,30)
				h2 = datetime.time(9,30)
				h3 = datetime.time(11,30)
				h4 = datetime.time(12)
				h5 = datetime.time(14)
				h6 = datetime.time(16)
				today = semestre.date_debut
				nombre_semaine = semaine(semestre.date_fin, semestre.date_debut)
				
				panning_enseignant = PlanningEnseignant.objects.filter(semestre__date_debut=semestre.date_debut)
				profs= Professeur.objects.all()

				if not panning_enseignant.exists():
					
					for prof in profs:
						today = semestre.date_debut
						for sem in range(1,nombre_semaine+2):
							panning_enseignant = PlanningEnseignant(date_debut=today, date_fin=ajout_semaine_1(today), numero=sem)
							panning_enseignant.semestre = semestre
							panning_enseignant.enseignant = prof
							panning_enseignant.save()
							today=ajout_semaine_1(today)
							today= today=ajout_date_1(today)
							today= today=ajout_date_1(today)
				
				filiere = Filiere.objects.get(responsable_niveau= responsable_niveau.id)
				
				options = Classe.objects.filter(filiere= filiere.id)
				
				for opt in options:
					today = semestre.date_debut
					for sem in range(1,nombre_semaine+2):

						panning=PlanningSemaine(date_debut=today, date_fin=ajout_semaine_1(today), etat='non valider', numero=sem)
						panning.responsable_niveau= responsable_niveau
						panning.classe=opt
						panning.semestre=semestre
						panning.save()

						panning_es = PlanningEnseignant.objects.filter(semestre=semestre, numero=sem)

						lundi=Jour(libelle='lundi', date_jour=today)
						lundi.planning=panning
						lundi.save()

						heure1=DoubleHeure(heure_debut=h1,heure_fin=h2,etat='non attribuer')
						heure2=DoubleHeure(heure_debut=h2,heure_fin=h3,etat='non attribuer')
						heure3=DoubleHeure(heure_debut=h4,heure_fin=h5,etat='non attribuer')
						heure4=DoubleHeure(heure_debut=h5,heure_fin=h6,etat='non attribuer')
						heure1.jour=lundi
						heure1.save()
						heure2.jour=lundi
						heure2.save()
						heure3.jour=lundi
						heure3.save()
						heure4.jour=lundi
						heure4.save()
						today=ajout_date_1(today)

						mardi=Jour(libelle='mardi', date_jour=today)
						mardi.planning=panning
						
						mardi.save()

						heure1=DoubleHeure(heure_debut=h1,heure_fin=h2,etat='non attribuer')
						heure2=DoubleHeure(heure_debut=h2,heure_fin=h3,etat='non attribuer')
						heure3=DoubleHeure(heure_debut=h4,heure_fin=h5,etat='non attribuer')
						heure4=DoubleHeure(heure_debut=h5,heure_fin=h6,etat='non attribuer')
						heure1.jour=mardi
						heure1.save()
						heure2.jour=mardi
						heure2.save()
						heure3.jour=mardi
						heure3.save()
						heure4.jour=mardi
						heure4.save()
						today=ajout_date_1(today)

						mercredi=Jour(libelle='mercredi',date_jour=today)
						mercredi.planning=panning
						
						mercredi.save()

						heure1=DoubleHeure(heure_debut=h1,heure_fin=h2,etat='non attribuer')
						heure2=DoubleHeure(heure_debut=h2,heure_fin=h3,etat='non attribuer')
						heure3=DoubleHeure(heure_debut=h4,heure_fin=h5,etat='non attribuer')
						heure4=DoubleHeure(heure_debut=h5,heure_fin=h6,etat='non attribuer')
						heure1.jour=mercredi
						heure1.save()
						heure2.jour=mercredi
						heure2.save()
						heure3.jour=mercredi
						heure3.save()
						heure4.jour=mercredi
						heure4.save()
						today=ajout_date_1(today)


						jeudi=Jour(libelle='jeudi',date_jour=today)
						jeudi.planning=panning
						
						jeudi.save()

						heure1=DoubleHeure(heure_debut=h1,heure_fin=h2,etat='non attribuer')
						heure2=DoubleHeure(heure_debut=h2,heure_fin=h3,etat='non attribuer')
						heure3=DoubleHeure(heure_debut=h4,heure_fin=h5,etat='non attribuer')
						heure4=DoubleHeure(heure_debut=h5,heure_fin=h6,etat='non attribuer')
						heure1.jour=jeudi
						heure1.save()
						heure2.jour=jeudi
						heure2.save()
						heure3.jour=jeudi
						heure3.save()
						heure4.jour=jeudi
						heure4.save()
						today=ajout_date_1(today)

						vendredi=Jour(libelle='vendredi',date_jour=today)
						vendredi.planning=panning
						
						vendredi.save()

						heure1=DoubleHeure(heure_debut=h1,heure_fin=h2,etat='non attribuer')
						heure2=DoubleHeure(heure_debut=h2,heure_fin=h3,etat='non attribuer')
						heure3=DoubleHeure(heure_debut=h4,heure_fin=h5,etat='non attribuer')
						heure4=DoubleHeure(heure_debut=h5,heure_fin=h6,etat='non attribuer')
						heure1.jour=vendredi
						heure1.save()
						heure2.jour=vendredi
						heure2.save()
						heure3.jour=vendredi
						heure3.save()
						heure4.jour=vendredi
						heure4.save()
						today=ajout_date_1(today)


						samedi=Jour(libelle='samedi',date_jour=today)
						samedi.planning=panning
						
						samedi.save()

						heure1=DoubleHeure(heure_debut=h1,heure_fin=h2,etat='non attribuer')
						heure2=DoubleHeure(heure_debut=h2,heure_fin=h3,etat='non attribuer')
						heure3=DoubleHeure(heure_debut=h4,heure_fin=h5,etat='non attribuer')
						heure4=DoubleHeure(heure_debut=h5,heure_fin=h6,etat='non attribuer')
						heure1.jour=samedi
						heure1.save()
						heure2.jour=samedi
						heure2.save()
						heure3.jour=samedi
						heure3.save()
						heure4.jour=samedi
						heure4.save()
						today=ajout_date_1(today)


						for panning_e in panning_es:
							lundi.planning_enseignant.add(panning_e)
							lundi.save()
							mardi.planning_enseignant.add(panning_e)
							mardi.save()
							mercredi.planning_enseignant.add(panning_e)
							mercredi.save()
							jeudi.planning_enseignant.add(panning_e)
							jeudi.save()
							vendredi.planning_enseignant.add(panning_e)
							vendredi.save()
							samedi.planning_enseignant.add(panning_e)
							samedi.save()


						today=ajout_date_1(today)


				# return HttpResponse(nombre_semaine)

				return HttpResponseRedirect("/")

			else:
				return HttpResponse('ya un pb')
		else:
			form = SemestreForm()
			context = {
				'form': form,
				'user': request.user,
				'personne': 'prof',
			}
			template = loader.get_template('new_semestre.html')
			return HttpResponse(template.render(context,request=request))
	else:
		template=loader.get_template('page-404.html')
		return HttpResponse(template.render(request=request))





@login_required(login_url="/auth/login/")
def planning(request):
	template=loader.get_template('planning.html')
	pers=Personne.objects.get(pk=request.user.id)
	personne=''
	variable=''

	id_planning=request.GET.get('id_planning')
	
	if pers.is_etudiant():

		etudiant=Etudiant.objects.get(pk=request.user.id)
		personne='Etudiant'
		dele = Delegue.objects.filter(pk=request.user.id)
		if dele.exists():
			personne= 'del'
		if not id_planning:
			planning=PlanningSemaine.objects.get(classe=etudiant.option, date_debut=debut_semaine())
		else: 
			planning=PlanningSemaine.objects.get(pk=int(id_planning))
		classe=Classe.objects.get(pk=etudiant.option.id)
		filiere = Filiere.objects.get(pk=classe.filiere.id)
		semestre=Semestre.objects.get(pk=planning.semestre.id)
		annee=AnneeAcademique.objects.get(pk=semestre.annee.id)
		rn=Personne.objects.get(pk=planning.responsable_niveau.id)
		
		lundi=Jour.objects.get(planning=planning.id, libelle='lundi')
		mardi=Jour.objects.get(planning=planning.id, libelle= 'mardi')
		mercredi=Jour.objects.get(planning=planning.id, libelle='mercredi')
		jeudi=Jour.objects.get(planning=planning.id, libelle= 'jeudi')
		vendredi=Jour.objects.get(planning=planning.id, libelle= 'vendredi')
		samedi=Jour.objects.get(planning=planning.id, libelle= 'samedi')
		
		heures = {
			'lundi': lundi.heure_journe(),
			'mardi': mardi.heure_journe(),
			'mercredi': mercredi.heure_journe(),
			'jeudi': jeudi.heure_journe(),
			'vendredi': vendredi.heure_journe(),
			'samedi': samedi.heure_journe(),

		}
		
		
		
		
		

		context={
			'planning': planning,
			'annee': annee,
			'semestre': semestre,
			'classe': classe,
			'filiere': filiere,
			'rn': rn,
			'jours': 'jours',
			'personne': personne,
			'heure': heures,
			'planning_suivant': PlanningSemaine.objects.get(pk=(planning.id+1)),
			'planning_precedant': PlanningSemaine.objects.get(pk=(planning.id-1)),
			
		}

	elif pers.is_parent():
		personne='parent'
		
		planning=PlanningSemaine.objects.get(pk=int(id_planning))

		lundi=Jour.objects.get(planning=planning.id, libelle='lundi')
		mardi=Jour.objects.get(planning=planning.id, libelle= 'mardi')
		mercredi=Jour.objects.get(planning=planning.id, libelle='mercredi')
		jeudi=Jour.objects.get(planning=planning.id, libelle= 'jeudi')
		vendredi=Jour.objects.get(planning=planning.id, libelle= 'vendredi')
		samedi=Jour.objects.get(planning=planning.id, libelle= 'samedi')
		
		heures = {
			'lundi': lundi.heure_journe(),
			'mardi': mardi.heure_journe(),
			'mercredi': mercredi.heure_journe(),
			'jeudi': jeudi.heure_journe(),
			'vendredi': vendredi.heure_journe(),
			'samedi': samedi.heure_journe(),

		}

		context={
			'personn': 'parent',
			'planning': planning,
			'personne': personne,
			'heure': heures,
			'planning_suivant': PlanningSemaine.objects.get(pk=(planning.id+1)),
			'planning_precedant': PlanningSemaine.objects.get(pk=(planning.id-1)),
			
		}


	elif pers.is_professeur():
		
		personne= 'prof'
		rne = ResponsableNiveau.objects.filter(pk=request.user.id)
		if rne.exists():
			personne= 'rn'

		chefd = ChefDepartement.objects.filter(pk=request.user.id)
		if chefd.exists():
			personne= 'chd'

		professeur=Professeur.objects.get(pk=request.user.id)
		
		# 
		if id_planning:
			planning=PlanningSemaine.objects.get(pk=id_planning)
			option = Classe.objects.get(pk= planning.classe.id)
			filiere=Filiere.objects.get(pk=option.filiere.id)

			semestre=Semestre.objects.get(pk=planning.semestre.id)
			annee=AnneeAcademique.objects.get(pk=semestre.annee.id)
			rn=Personne.objects.get(pk=planning.responsable_niveau.id)
			matieres= Matiere.objects.filter(Q(professeur=professeur) | Q(enseignant_tp=professeur) | Q(enseignant_td=professeur) , option= option)
			
			lundi=Jour.objects.get(planning=planning.id, libelle='lundi')
			mardi=Jour.objects.get(planning=planning.id, libelle= 'mardi')
			mercredi=Jour.objects.get(planning=planning.id, libelle='mercredi')
			jeudi=Jour.objects.get(planning=planning.id, libelle= 'jeudi')
			vendredi=Jour.objects.get(planning=planning.id, libelle= 'vendredi')
			samedi=Jour.objects.get(planning=planning.id, libelle= 'samedi')
			
			heures = {
				'lundi': lundi.heure_journe(),
				'mardi': mardi.heure_journe(),
				'mercredi': mercredi.heure_journe(),
				'jeudi': jeudi.heure_journe(),
				'vendredi': vendredi.heure_journe(),
				'samedi': samedi.heure_journe(),

			}
			variable='true'
			context={
				'planning': planning,
				'annee': annee,
				'semestre': semestre,
				'classe': option,
				'filiere': filiere,
				'rn': rn,
				'jours': 'jours',
				'personne': personne,
				'heure': heures,
				'prog': variable,
				'matieres': matieres,
				'planning_suivant': PlanningSemaine.objects.get(pk=(planning.id+1)),
				'planning_precedant': PlanningSemaine.objects.get(pk=(planning.id-1)),
	
			}
					
		elif request.GET.get('libelle'):
			# form = ClasseForm(request.POST)
			form = ClasseForm(request.GET)

			if form.is_valid():
				query=form.cleaned_data['libelle']
				option = Classe.objects.filter(abrege__icontains=query)

				if not option.exists():
					option = Classe.objects.filter(libelle__icontains= query)

				if not option.exists():
					planning = "Misère de misère, nous n'avons trouvé aucun résultat !<a href='/planning/planning/'> accueil</a>"
					return HttpResponse(planning)

				else:
					planning = PlanningSemaine.objects.get(classe=option[0], date_debut=debut_semaine_prochaine())
					filiere = Filiere.objects.get(pk=option[0].filiere.id)
					semestre=Semestre.objects.get(pk=planning.semestre.id)
					annee=AnneeAcademique.objects.get(pk=semestre.annee.id)
					rn=Personne.objects.get(pk=planning.responsable_niveau.id)
					matieres= Matiere.objects.filter(Q(professeur=professeur) | Q(enseignant_tp=professeur) | Q(enseignant_td=professeur) , option= option[0])
					
					lundi=Jour.objects.get(planning=planning.id, libelle='lundi')
					mardi=Jour.objects.get(planning=planning.id, libelle= 'mardi')
					mercredi=Jour.objects.get(planning=planning.id, libelle='mercredi')
					jeudi=Jour.objects.get(planning=planning.id, libelle= 'jeudi')
					vendredi=Jour.objects.get(planning=planning.id, libelle= 'vendredi')
					samedi=Jour.objects.get(planning=planning.id, libelle= 'samedi')
					
					heures = {
						'lundi': lundi.heure_journe(),
						'mardi': mardi.heure_journe(),
						'mercredi': mercredi.heure_journe(),
						'jeudi': jeudi.heure_journe(),
						'vendredi': vendredi.heure_journe(),
						'samedi': samedi.heure_journe(),

					}
					variable='true'
					context={
						'planning': planning,
						'annee': annee,
						'semestre': semestre,
						'classe': option[0],
						'filiere': filiere,
						'rn': rn,
						'jours': 'jours',
						'personne': personne,
						'heure': heures,
						'prog': variable,
						'matieres': matieres,
						'planning_suivant': PlanningSemaine.objects.get(pk=(planning.id+1)),
						'planning_precedant': PlanningSemaine.objects.get(pk=(planning.id-1)),
			
					}
			else:
				form = ClasseForm()
				context = {
					'form': form,
					'user': request.user,
					'personne': personne,
				}
		
			

		elif request.method == 'POST':
			
			intit=int(request.POST.get('lundi_heure_1'))
			finale = int(request.POST.get('lundi_heure_4'))
			for heure in range(intit-1, finale+1):				
				if request.POST.get(str(heure)):
					hours= DoubleHeure.objects.get(pk=heure)
					
					if professeur.professeur_occuper(hours.jour.date_jour, hours.heure_debut):
		
						id_mat=int(request.POST.get(str(heure)))
						mat=Matiere.objects.get(pk=id_mat)
						hours.matieres.add(mat)
						hours.enseignants.add(professeur)
						hours.etat="en attente d'attribution"
						hours.save()

			intit=int(request.POST.get('mardi_heure_1'))
			finale = int(request.POST.get('mardi_heure_4'))
			for heure in range(intit-1, finale+1):				
				if request.POST.get(str(heure)):
					hours= DoubleHeure.objects.get(pk=heure)
					
					if professeur.professeur_occuper(hours.jour.date_jour, hours.heure_debut):
		
						id_mat=int(request.POST.get(str(heure)))
						mat=Matiere.objects.get(pk=id_mat)
						hours.matieres.add(mat)
						hours.etat="en attente d'attribution"
						hours.enseignants.add(professeur)
						hours.save()
			intit=int(request.POST.get('mercredi_heure_1'))
			finale = int(request.POST.get('mercredi_heure_4'))
			for heure in range(intit-1, finale+1):				
				if request.POST.get(str(heure)):
					hours= DoubleHeure.objects.get(pk=heure)
					
					if professeur.professeur_occuper(hours.jour.date_jour, hours.heure_debut):
		
						id_mat=int(request.POST.get(str(heure)))
						mat=Matiere.objects.get(pk=id_mat)
						hours.matieres.add(mat)
						hours.etat="en attente d'attribution"
						hours.enseignants.add(professeur)
						hours.save()
			intit=int(request.POST.get('jeudi_heure_1'))
			finale = int(request.POST.get('jeudi_heure_4'))
			for heure in range(intit-1, finale+1):				
				if request.POST.get(str(heure)):
					hours= DoubleHeure.objects.get(pk=heure)
					
					if professeur.professeur_occuper(hours.jour.date_jour, hours.heure_debut):
		
						id_mat=int(request.POST.get(str(heure)))
						mat=Matiere.objects.get(pk=id_mat)
						hours.matieres.add(mat)
						hours.etat="en attente d'attribution"
						hours.enseignants.add(professeur)
						hours.save()
			intit=int(request.POST.get('vendredi_heure_1'))
			finale = int(request.POST.get('vendredi_heure_4'))
			for heure in range(intit-1, finale+1):				
				if request.POST.get(str(heure)):
					hours= DoubleHeure.objects.get(pk=heure)
					
					if professeur.professeur_occuper(hours.jour.date_jour, hours.heure_debut):
		
						id_mat=int(request.POST.get(str(heure)))
						mat=Matiere.objects.get(pk=id_mat)
						hours.matieres.add(mat)
						hours.etat="en attente d'attribution"
						hours.enseignants.add(professeur)
						hours.save()
			intit=int(request.POST.get('samedi_heure_1'))
			finale = int(request.POST.get('samedi_heure_4'))
			for heure in range(intit-1, finale+1):				
				if request.POST.get(str(heure)):
					hours= DoubleHeure.objects.get(pk=heure)
					
					if professeur.professeur_occuper(hours.jour.date_jour, hours.heure_debut):
		
						id_mat=int(request.POST.get(str(heure)))
						mat=Matiere.objects.get(pk=id_mat)
						hours.matieres.add(mat)
						hours.etat="en attente d'attribution"
						hours.enseignants.add(professeur)
						hours.save()



			variable='terminer'

			context = {
				'personne': personne,
				'prog': variable,
				'h1': int(intit),
				'h2': int(finale),
				'mat': 'mat',
			}

		else:
			form = ClasseForm()
			context = {
				'form': form,
				'user': request.user,
				'personne': personne,
			}
	


	return HttpResponse(template.render(context,request=request))


@login_required(login_url="/auth/login/")
def profile(request):
			
	template=loader.get_template('page-user.html')
	etu=Etudiant.objects.filter(pk=request.user.id)
	if etu.exists():
		personne= 'etudiant'

	dele = Delegue.objects.filter(pk=request.user.id)
	if dele.exists():
		personne= 'del'

	pr=Professeur.objects.filter(pk=request.user.id)
	if pr.exists():
		personne= 'prof'

	rn = ResponsableNiveau.objects.filter(pk=request.user.id)
	if rn.exists():
		personne= 'rn'

	ch = ResponsableNiveau.objects.filter(pk=request.user.id)
	if ch.exists():
		personne= 'chd'
	context = {
			
			'personne': personne,
		}
	
	return HttpResponse(template.render(context, request=request))




@login_required(login_url="/auth/login/")
def valide(request):
	
	responsable_niveau= Personne.objects.get(pk=request.user.id)
	template = loader.get_template('valide.html')
	if responsable_niveau.is_responsable_niveau():

		filier=Filiere.objects.get(responsable_niveau=responsable_niveau.id)

		plannings=PlanningSemaine.objects.filter(classe__filiere=filier, date_debut=debut_semaine_prochaine())

		context = {
			'plannings': plannings,
			'filiere': filier,
			'personne': 'rn',
		}
		if request.method == 'POST':

			for planning in plannings:
				if request.POST.get(str(planning.id)):
					planning.etat='valider'
					planning.save()
					


		return HttpResponse(template.render(context,request=request))
	else:
		template=loader.get_template('page-404.html')
		return HttpResponse(template.render(request=request))




@login_required(login_url="/auth/login/")
def validation(request):

	pers=Personne.objects.get(pk=request.user.id)

	if pers.is_responsable_niveau():
		responsable_niveau=ResponsableNiveau.objects.get(pk=pers.id)
		template=loader.get_template('validation.html')
		id_planning=request.GET.get('id_planning')

		# if not id_planning:
		# 	planning=PlanningSemaine.objects.filter(responsable_niveau=responsable_niveau, date_debut=debut_semaine_prochaine())
		# 	planning=PlanningSemaine.objects.get(pk=planning[0].id)
		# else: 
		planning=PlanningSemaine.objects.get(pk=int(id_planning))
		
		
		classe=Classe.objects.get(pk=planning.classe.id)
		filiere = Filiere.objects.get(pk=classe.filiere.id)
		semestre=Semestre.objects.get(pk=planning.semestre.id)
		annee=AnneeAcademique.objects.get(pk=semestre.annee.id)
		# jours=Jour.objects.filter(planning=planning.id)
		matieres= Matiere.objects.filter(option=classe.id)
		

		if request.method == 'POST':
			
			
			if request.POST.get('plan'):
				
				planning.etat='valider' 
				planning.save()


			# lundi
			intit=int(request.POST.get('lundi_heure_1'))
			finale = int(request.POST.get('lundi_heure_4'))

			for heure in range(intit, finale+1):
				
				if request.POST.get(str(heure)):
					hours= DoubleHeure.objects.get(pk=heure)
					if hours.etat=='valider':
						id_salle=int(request.POST.get(str(heure)))
						sall= SalleDeClasse.objects.get(pk=id_salle)
						hours.salle=sall
						heur= HeureProfesseur.objects.get(heure_debut= hours.heure_debut, heure_fin= hours.heure_fin, jour=hours.jour, professeur= hours.enseignant, option= classe)
						heur.salle=sall

						hours.etat='attribuer'
						hours.save()
						heur.save()
						pass

					else :
						id_mat=int(request.POST.get(str(heure)))
						mat=Matiere.objects.get(pk=id_mat)
						hours.matiere=mat
						ens=hours.enseignants.all()
						for en in ens :
							if en == mat.professeur :
								hours.enseignant=en
								break
							elif en == mat.enseignant_td :
								hours.enseignant=en
								break
							elif en == mat.enseignant_tp :
								hours.enseignant=en
								break
						if hours.enseignant ==None:
							hours.enseignant= mat.professeur
						hours.etat='valider'
						hours.save()

						hours.enseignant.delete_profesor_heure(hours.jour.date_jour, hours.heure_debut)

						heure = HeureProfesseur(heure_debut= hours.heure_debut, heure_fin= hours.heure_fin)
						heure.jour = hours.jour
						heure.professeur=hours.enseignant
						heure.matiere=mat
						heure.option=classe
						heure.save()
						pass

			# mardi
			intit=int(request.POST.get('mardi_heure_1'))
			finale = int(request.POST.get('mardi_heure_4'))
			for heure in range(intit, finale+1):
				
				if request.POST.get(str(heure)):
					hours= DoubleHeure.objects.get(pk=heure)
					if hours.etat=='valider':
						id_salle=int(request.POST.get(str(heure)))
						sall= SalleDeClasse.objects.get(pk=id_salle)
						
						heur= HeureProfesseur.objects.get(heure_debut= hours.heure_debut, heure_fin= hours.heure_fin, jour=hours.jour, professeur= hours.enseignant, option= classe)
						heur.salle=sall

						hours.etat='attribuer'
						hours.save()
						heur.save()
						pass
					else :
						id_mat=int(request.POST.get(str(heure)))
						mat=Matiere.objects.get(pk=id_mat)
						hours.matiere=mat
						ens=hours.enseignants.all()
						for en in ens :
							if en == mat.professeur :
								hours.enseignant=en
								break
							elif en == mat.enseignant_td :
								hours.enseignant=en
								break
							elif en == mat.enseignant_tp :
								hours.enseignant=en
								break
						if hours.enseignant ==None:
							hours.enseignant= mat.professeur
						hours.etat='valider'
						hours.save()

						hours.enseignant.delete_profesor_heure(hours.jour.date_jour, hours.heure_debut)

						heure = HeureProfesseur(heure_debut= hours.heure_debut, heure_fin= hours.heure_fin)
						heure.jour = hours.jour
						heure.professeur=hours.enseignant
						heure.matiere=mat
						heure.option=classe
						heure.save()
						pass

			# mercredi
			intit=int(request.POST.get('mercredi_heure_1'))
			finale = int(request.POST.get('mercredi_heure_4'))
			for heure in range(intit, finale+1):
				
				if request.POST.get(str(heure)):
					hours= DoubleHeure.objects.get(pk=heure)
					if hours.etat=='valider':
						id_salle=int(request.POST.get(str(heure)))
						sall= SalleDeClasse.objects.get(pk=id_salle)
						hours.salle=sall
						heur= HeureProfesseur.objects.get(heure_debut= hours.heure_debut, heure_fin= hours.heure_fin, jour=hours.jour, professeur= hours.enseignant, option= classe)
						heur.salle=sall

						hours.etat='attribuer'
						hours.save()
						heur.save()
						pass

					else :
						id_mat=int(request.POST.get(str(heure)))
						mat=Matiere.objects.get(pk=id_mat)
						hours.matiere=mat
						ens=hours.enseignants.all()
						for en in ens :
							if en == mat.professeur :
								hours.enseignant=en
								break
							elif en == mat.enseignant_td :
								hours.enseignant=en
								break
							elif en == mat.enseignant_tp :
								hours.enseignant=en
								break
						if hours.enseignant ==None:
							hours.enseignant= mat.professeur
						hours.etat='valider'
						hours.save()

						
						hours.enseignant.delete_profesor_heure(hours.jour.date_jour, hours.heure_debut)

						heure = HeureProfesseur(heure_debut= hours.heure_debut, heure_fin= hours.heure_fin)
						heure.jour = hours.jour
						heure.professeur=hours.enseignant
						heure.matiere=mat
						heure.option=classe
						heure.save()
						pass
			# jeudi 
			intit=int(request.POST.get('jeudi_heure_1'))
			finale = int(request.POST.get('jeudi_heure_4'))
			for heure in range(intit, finale+1):
				
				if request.POST.get(str(heure)):
					hours= DoubleHeure.objects.get(pk=heure)
					if hours.etat=='valider':
						id_salle=int(request.POST.get(str(heure)))
						sall= SalleDeClasse.objects.get(pk=id_salle)
						hours.salle=sall
						heur= HeureProfesseur.objects.get(heure_debut= hours.heure_debut, heure_fin= hours.heure_fin, jour=hours.jour, professeur= hours.enseignant, option= classe)
						heur.salle=sall

						hours.etat='attribuer'
						hours.save()
						heur.save()
						pass

					else :
						id_mat=int(request.POST.get(str(heure)))
						mat=Matiere.objects.get(pk=id_mat)
						hours.matiere=mat
						ens=hours.enseignants.all()
						for en in ens :
							if en == mat.professeur :
								hours.enseignant=en
								break
							elif en == mat.enseignant_td :
								hours.enseignant=en
								break
							elif en == mat.enseignant_tp :
								hours.enseignant=en
								break
						if hours.enseignant ==None:
							hours.enseignant= mat.professeur
						hours.etat='valider'
						hours.save()

						
						hours.enseignant.delete_profesor_heure(hours.jour.date_jour, hours.heure_debut)

						heure = HeureProfesseur(heure_debut= hours.heure_debut, heure_fin= hours.heure_fin)
						heure.jour = hours.jour
						heure.professeur=hours.enseignant
						heure.matiere=mat
						heure.option=classe
						heure.save()
						pass

			# vendredi
			intit=int(request.POST.get('vendredi_heure_1'))
			finale = int(request.POST.get('vendredi_heure_4'))
			for heure in range(intit, finale+1):
				
				if request.POST.get(str(heure)):
					hours= DoubleHeure.objects.get(pk=heure)
					if hours.etat=='valider':
						id_salle=int(request.POST.get(str(heure)))
						sall= SalleDeClasse.objects.get(pk=id_salle)
						hours.salle=sall
						heur= HeureProfesseur.objects.get(heure_debut= hours.heure_debut, heure_fin= hours.heure_fin, jour=hours.jour, professeur= hours.enseignant, option= classe)
						heur.salle=sall

						hours.etat='attribuer'
						hours.save()
						heur.save()
						pass

					else :
						id_mat=int(request.POST.get(str(heure)))
						mat=Matiere.objects.get(pk=id_mat)
						hours.matiere=mat
						ens=hours.enseignants.all()
						for en in ens :
							if en == mat.professeur :
								hours.enseignant=en
								break
							elif en == mat.enseignant_td :
								hours.enseignant=en
								break
							elif en == mat.enseignant_tp :
								hours.enseignant=en
								break
						if hours.enseignant ==None:
							hours.enseignant= mat.professeur
						hours.etat='valider'
						hours.save()

						
						hours.enseignant.delete_profesor_heure(hours.jour.date_jour, hours.heure_debut)

						heure = HeureProfesseur(heure_debut= hours.heure_debut, heure_fin= hours.heure_fin)
						heure.jour = hours.jour
						heure.professeur=hours.enseignant
						heure.matiere=mat
						heure.option=classe
						heure.save()
						pass

			# samedi
			intit=int(request.POST.get('samedi_heure_1'))
			finale = int(request.POST.get('samedi_heure_4'))
			for heure in range(intit, finale+1):
				
				if request.POST.get(str(heure)):
					hours= DoubleHeure.objects.get(pk=heure)
					if hours.etat=='valider':
						id_salle=int(request.POST.get(str(heure)))
						sall= SalleDeClasse.objects.get(pk=id_salle)
						hours.salle=sall
						heur= HeureProfesseur.objects.get(heure_debut= hours.heure_debut, heure_fin= hours.heure_fin, jour=hours.jour, professeur= hours.enseignant, option= classe)
						heur.salle=sall

						hours.etat='attribuer'
						hours.save()
						heur.save()
						pass

					else :
						id_mat=int(request.POST.get(str(heure)))
						mat=Matiere.objects.get(pk=id_mat)
						hours.matiere=mat
						ens=hours.enseignants.all()
						for en in ens :
							if en == mat.professeur :
								hours.enseignant=en
								break
							elif en == mat.enseignant_td :
								hours.enseignant=en
								break
							elif en == mat.enseignant_tp :
								hours.enseignant=en
								break
						if hours.enseignant ==None:
							hours.enseignant= mat.professeur
						hours.etat='valider'
						hours.save()

						
						hours.enseignant.delete_profesor_heure(hours.jour.date_jour, hours.heure_debut)

						heure = HeureProfesseur(heure_debut= hours.heure_debut, heure_fin= hours.heure_fin)
						heure.jour = hours.jour
						heure.professeur=hours.enseignant
						heure.matiere=mat
						heure.option=classe
						heure.save()
						pass
					

			# variable='terminer' 

			# context = {
			# 	'personne': personne,
			# 	'prog': variable,
			# 	'h1': int(intit),
			# 	'h2': int(finale),
			# 	'mat': mat,
			# }


	
		
		lundi=Jour.objects.get(planning=planning.id, libelle='lundi')
		mardi=Jour.objects.get(planning=planning.id, libelle= 'mardi')
		mercredi=Jour.objects.get(planning=planning.id, libelle='mercredi')
		jeudi=Jour.objects.get(planning=planning.id, libelle= 'jeudi')
		vendredi=Jour.objects.get(planning=planning.id, libelle= 'vendredi')
		samedi=Jour.objects.get(planning=planning.id, libelle= 'samedi')
		
		heures = {
			'lundi': lundi.heure_journe(),
			'mardi': mardi.heure_journe(),
			'mercredi': mercredi.heure_journe(),
			'jeudi': jeudi.heure_journe(),
			'vendredi': vendredi.heure_journe(),
			'samedi': samedi.heure_journe(),

		}
		
		# matieres= Matiere.objects.filter()
		
		
		
		

		context={
			'planning': planning,
			'annee': annee,
			'semestre': semestre,
			'classe': classe,
			'filiere': filiere,
			'rn': responsable_niveau,
			'jours': 'jours',
			'heure': heures,
			'matieres': matieres,
			'planning_suivant': PlanningSemaine.objects.get(pk=(planning.id+1)),
			'planning_precedant': PlanningSemaine.objects.get(pk=(planning.id-1)),
			'personne': 'rn',

		}

			 

		return HttpResponse(template.render(context, request=request))
	else:
		template=loader.get_template('page-404.html')
		return HttpResponse(template.render(request=request))


@login_required(login_url="/auth/login/")
def publication(request):

	chefd= Personne.objects.get(pk=request.user.id)
	template = loader.get_template('publication.html')
	if chefd.is_chef_departement():

		depart=Departement.objects.get(chef_departement=chefd.id)

		plannings=PlanningSemaine.objects.filter(etat='valider', classe__filiere__departement=depart)

		context = {
			'plannings': plannings,
			'departement': depart,
			'chef': chefd,
			'personne': 'chd',
		}
		if request.method == 'POST':

			for planning in plannings:
				if request.POST.get(str(planning.id)):
					planning.etat='publier'
					planning.save()

					lundi=Jour.objects.get(planning=planning.id, libelle='lundi')
					mardi=Jour.objects.get(planning=planning.id, libelle= 'mardi')
					mercredi=Jour.objects.get(planning=planning.id, libelle='mercredi')
					jeudi=Jour.objects.get(planning=planning.id, libelle= 'jeudi')
					vendredi=Jour.objects.get(planning=planning.id, libelle= 'vendredi')
					samedi=Jour.objects.get(planning=planning.id, libelle= 'samedi')
					
					lundiheure=heures=DoubleHeure.objects.filter(jour=lundi)
					mardiheure=heures=DoubleHeure.objects.filter(jour=mardi)
					mercrediheure=heures=DoubleHeure.objects.filter(jour=mercredi)
					jeudiheure=heures=DoubleHeure.objects.filter(jour=jeudi)
					vendrediheure=heures=DoubleHeure.objects.filter(jour=vendredi)
					samediheure=heures=DoubleHeure.objects.filter(jour=samedi)

					emploi = emploie_de_temps(
						jours ='lundi', 
						semaine =str(planning.numero) , 
						descrip_semaine =planning.descrip_semaine(), 
						matiere1 =lundiheure[0].affiche_matiere(),
						ens_matiere1 = lundiheure[0].affiche_enseignant(), 
						matiere2 = lundiheure[1].affiche_matiere(), 
						ens_matiere2 =lundiheure[1].affiche_enseignant(), 
						matiere3 =lundiheure[2].affiche_matiere(), 
						ens_matiere3 =lundiheure[2].affiche_enseignant() ,
						matiere4 =lundiheure[3].affiche_matiere() ,
						ens_matiere4 =lundiheure[3].affiche_enseignant() ,
						option =planning.classe.abrege ,
						filiere = planning.classe.filiere.affiche_abrege()
						)
					emploi.save(using='online')

					emploi = emploie_de_temps(
						jours ='mardi', 
						semaine =str(planning.numero) , 
						descrip_semaine =planning.descrip_semaine(), 
						matiere1 =mardiheure[0].affiche_matiere(), 
						ens_matiere1 = mardiheure[0].affiche_enseignant(), 
						matiere2 = mardiheure[1].affiche_matiere(), 
						ens_matiere2 =mardiheure[1].affiche_enseignant(), 
						matiere3 =mardiheure[2].affiche_matiere(), 
						ens_matiere3 =mardiheure[2].affiche_enseignant() ,
						matiere4 =mardiheure[3].affiche_matiere() ,
						ens_matiere4 =mardiheure[3].affiche_enseignant() ,
						option =planning.classe.abrege ,
						filiere = planning.classe.filiere.affiche_abrege()
						)
					emploi.save(using='online')

					emploi = emploie_de_temps(
						jours ='mercredi', 
						semaine =str(planning.numero) , 
						descrip_semaine =planning.descrip_semaine(), 
						matiere1 =mercrediheure[0].affiche_matiere(), 
						ens_matiere1 = mercrediheure[0].affiche_enseignant(), 
						matiere2 = mercrediheure[1].affiche_matiere(), 
						ens_matiere2 =mercrediheure[1].affiche_enseignant(), 
						matiere3 =mercrediheure[2].affiche_matiere(), 
						ens_matiere3 =mercrediheure[2].affiche_enseignant() ,
						matiere4 =mercrediheure[3].affiche_matiere() ,
						ens_matiere4 =mercrediheure[3].affiche_enseignant() ,
						option =planning.classe.abrege ,
						filiere = planning.classe.filiere.affiche_abrege()
						)
					emploi.save(using='online')

					emploi = emploie_de_temps(
						jours ='jeudi', 
						semaine =str(planning.numero) , 
						descrip_semaine =planning.descrip_semaine(), 
						matiere1 =jeudiheure[0].affiche_matiere(), 
						ens_matiere1 = jeudiheure[0].affiche_enseignant(), 
						matiere2 = jeudiheure[1].affiche_matiere(), 
						ens_matiere2 =jeudiheure[1].affiche_enseignant(), 
						matiere3 =jeudiheure[2].affiche_matiere(), 
						ens_matiere3 =jeudiheure[2].affiche_enseignant() ,
						matiere4 =jeudiheure[3].affiche_matiere() ,
						ens_matiere4 =jeudiheure[3].affiche_enseignant() ,
						option =planning.classe.abrege ,
						filiere = planning.classe.filiere.affiche_abrege()
						)
					emploi.save(using='online')
					emploi = emploie_de_temps(
						jours ='vendredi', 
						semaine =str(planning.numero) , 
						descrip_semaine =planning.descrip_semaine(), 
						matiere1 =vendrediheure[0].affiche_matiere(), 
						ens_matiere1 = vendrediheure[0].affiche_enseignant(), 
						matiere2 = vendrediheure[1].affiche_matiere(), 
						ens_matiere2 =vendrediheure[1].affiche_enseignant(), 
						matiere3 =vendrediheure[2].affiche_matiere(), 
						ens_matiere3 =vendrediheure[2].affiche_enseignant() ,
						matiere4 =vendrediheure[3].affiche_matiere() ,
						ens_matiere4 =vendrediheure[3].affiche_enseignant() ,
						option =planning.classe.abrege ,
						filiere = planning.classe.filiere.affiche_abrege()
						)
					emploi.save(using='online')

					emploi = emploie_de_temps(
						jours ='samedi', 
						semaine =str(planning.numero) , 
						descrip_semaine =planning.descrip_semaine(), 
						matiere1 =samediheure[0].affiche_matiere(), 
						ens_matiere1 = samediheure[0].affiche_enseignant(), 
						matiere2 = samediheure[1].affiche_matiere(), 
						ens_matiere2 =samediheure[1].affiche_enseignant(), 
						matiere3 =samediheure[2].affiche_matiere(), 
						ens_matiere3 =samediheure[2].affiche_enseignant() ,
						matiere4 =samediheure[3].affiche_matiere() ,
						ens_matiere4 =samediheure[3].affiche_enseignant() ,
						option =planning.classe.abrege ,
						filiere = planning.classe.filiere.affiche_abrege()
						)
					emploi.save(using='online')


		return HttpResponse(template.render(context,request=request))
	else:
		template=loader.get_template('page-404.html')
		return HttpResponse(template.render(request=request))

@login_required(login_url="/auth/login/")
def iut(request):

	template=loader.get_template('page-404.html')
	return HttpResponse(template.render(request=request))



@login_required(login_url="/auth/login/")
def statistique(request):
	template=loader.get_template('statistique.html')

	pers=Personne.objects.get(pk=request.user)
	# if pers.is_etudiant():

	# if pers.is_professeur:

	if pers.is_responsable_niveau():

		rn=ResponsableNiveau.objects.get(pk=pers.id)
		
	
		plannings=PlanningSemaine.objects.filter(responsable_niveau=rn, date_debut=debut_semaine())
		
		# matiere=Matiere.objects.filter(professeur=rn, module__numero_semestre=planning.semestre.numero)

		personne='rn'

		stats= Statistique.objects.filter(classe__filiere=plannings[0].classe.filiere, semestre=plannings[0].semestre)


	elif pers.is_chef_departement():

		chefd=ChefDepartement.objects.get(pk=pers.id)
		
	
		plannings=PlanningSemaine.objects.filter(classe__filiere__departement=chefd.chefdepartement, date_debut=debut_semaine())
		
		# matiere=Matiere.objects.filter(professeur=rn, module__numero_semestre=planning.semestre.numero)

		personne='chd'

		stats= Statistique.objects.filter(semestre=plannings[0].semestre, classe__filiere__departements=planning[0].classe.filiere.departement)

	context = {
		'plannings': plannings,
		'stats': stats,
		'chef': 'chefd',
		'personne': personne,
	}
	return HttpResponse(template.render(context, request=request))



@login_required(login_url="/auth/login/")
def confirme(request):
	pers=Personne.objects.get(pk=request.user)
	if pers.is_delegue():

		delegue = Delegue.objects.get(pk=request.user)
		template=loader.get_template('confirme.html')
		id_planning=request.GET.get('id_planning')
		if not id_planning:
			planning=PlanningSemaine.objects.get(classe=delegue.option, date_debut=debut_semaine())
		else: 
			planning=PlanningSemaine.objects.get(pk=int(id_planning))
		
		

		lundi=Jour.objects.get(planning=planning.id, libelle='lundi')
		mardi=Jour.objects.get(planning=planning.id, libelle= 'mardi')
		mercredi=Jour.objects.get(planning=planning.id, libelle='mercredi')
		jeudi=Jour.objects.get(planning=planning.id, libelle= 'jeudi')
		vendredi=Jour.objects.get(planning=planning.id, libelle= 'vendredi')
		samedi=Jour.objects.get(planning=planning.id, libelle= 'samedi')
		
		heures = {
			'lundi': lundi.heure_journe(),
			'mardi': mardi.heure_journe(),
			'mercredi': mercredi.heure_journe(),
			'jeudi': jeudi.heure_journe(),
			'vendredi': vendredi.heure_journe(),
			'samedi': samedi.heure_journe(),

		}

		if request.method == 'POST':

			intit=int(request.POST.get('lundi_heure_1'))
			finale = int(request.POST.get('lundi_heure_4'))
			for heure in range(intit, finale+1):				
				if request.POST.get(str(heure)):
					hours= DoubleHeure.objects.get(pk=heure)
				
					hours.etat="effectif"
					hours.save()

					stats=Statistique.objects.filter(matiere=hours.matiere, semestre=hours.jour.planning.semestre)
					if not stats.exists():
						stat= Statistique()
						stat.matiere= hours.matiere
						stat.semestre=hours.jour.planning.semestre
						stat.classe=hours.jour.planning.classe
						stat.save()
					else :
						stat=stats[0]
					stat.effectuer_statistique(heure)


			intit=int(request.POST.get('mardi_heure_1'))
			finale = int(request.POST.get('mardi_heure_4'))
			for heure in range(intit, finale+1):				
				if request.POST.get(str(heure)):
					hours= DoubleHeure.objects.get(pk=heure)
				
					hours.etat="effectif"
					hours.save()

					stats=Statistique.objects.filter(matiere=hours.matiere, semestre=hours.jour.planning.semestre)
					if not stats.exists():
						stat= Statistique()
						stat.matiere= hours.matiere
						stat.semestre=hours.jour.planning.semestre
						stat.classe=hours.jour.planning.classe
						stat.save()


					else :
						stat=stats[0]
					stat.effectuer_statistique(heure)

			intit=int(request.POST.get('mercredi_heure_1'))
			finale = int(request.POST.get('mercredi_heure_4'))
			for heure in range(intit, finale+1):				
				if request.POST.get(str(heure)):
					hours= DoubleHeure.objects.get(pk=heure)
				
					hours.etat="effectif"
					hours.save()

					stats=Statistique.objects.filter(matiere=hours.matiere, semestre=hours.jour.planning.semestre)
					if not stats.exists():
						stat= Statistique()
						stat.matiere= hours.matiere
						stat.semestre=hours.jour.planning.semestre
						stat.classe=hours.jour.planning.classe
						stat.save()

					else :
						stat=stats[0]
					stat.effectuer_statistique(heure)

			intit=int(request.POST.get('jeudi_heure_1'))
			finale = int(request.POST.get('jeudi_heure_4'))
			for heure in range(intit, finale+1):				
				if request.POST.get(str(heure)):
					hours= DoubleHeure.objects.get(pk=heure)
				
					hours.etat="effectif"
					hours.save()

					stats=Statistique.objects.filter(matiere=hours.matiere, semestre=hours.jour.planning.semestre)
					if not stats.exists():
						stat= Statistique()
						stat.matiere= hours.matiere
						stat.semestre=hours.jour.planning.semestre
						stat.classe=hours.jour.planning.classe
						stat.save()

					else :
						stat=stats[0]
					stat.effectuer_statistique(heure)

			intit=int(request.POST.get('vendredi_heure_1'))
			finale = int(request.POST.get('vendredi_heure_4'))
			for heure in range(intit, finale+1):				
				if request.POST.get(str(heure)):
					hours= DoubleHeure.objects.get(pk=heure)
				
					hours.etat="effectif"
					hours.save()

					stats=Statistique.objects.filter(matiere=hours.matiere, semestre=hours.jour.planning.semestre)
					if not stats.exists():
						stat= Statistique()
						stat.matiere= hours.matiere
						stat.semestre=hours.jour.planning.semestre
						stat.classe=hours.jour.planning.classe
						stat.save()

					else :
						stat=stats[0]
					stat.effectuer_statistique(heure)

			intit=int(request.POST.get('samedi_heure_1'))
			finale = int(request.POST.get('samedi_heure_4'))
			for heure in range(intit, finale+1):				
				if request.POST.get(str(heure)):
					hours= DoubleHeure.objects.get(pk=heure)
				
					hours.etat="effectif"
					hours.save()

					stats=Statistique.objects.filter(matiere=hours.matiere, semestre=hours.jour.planning.semestre)
					if not stats.exists():
						stat= Statistique()
						stat.matiere= hours.matiere
						stat.semestre=hours.jour.planning.semestre
						stat.classe=hours.jour.planning.classe
						stat.save()

					else :
						stat=stats[0]
					stat.effectuer_statistique(heure)

		context = {
			'planning': planning,
			'heure': heures,
			'chef': 'chefd',
			'personne': 'del',
		}


		return HttpResponse(template.render(context, request=request))
	else :
		template=loader.get_template('page-404.html')
		return HttpResponse(template.render(request=request))
