from django.contrib import admin
from .models import *

# Register your models here.



@admin.register(Departement)
class DepartementAdmin(admin.ModelAdmin):
	pass
class DepartementInline(admin.TabularInline):
	model = Departement
	fieldsets = [(
		None, {'fields': ['chef_departement', 'libelle']})]
	extra = 0
# class DepartementProfesseurInline(admin.TabularInline):
# 	model = Departement.professeur.through
# 	extra = 0




@admin.register(Filiere)
class FiliereAdmin(admin.ModelAdmin):
	pass
class FiliereInline(admin.TabularInline):
	model = Filiere
	fieldsets = [(
		None, {'fields': ['responsable_niveau', 'libelle', 'departement']})]
	extra = 0




@admin.register(Classe)
class ClasseAdmin(admin.ModelAdmin):
	pass
class ClasseInline(admin.TabularInline):
	model = Classe
	fieldsets = [(
		None, {'fields': ['delegue', 'libelle', 'filiere']})]
	extra = 0
# class ClassePersonneInline(admin.TabularInline):
# 	model = Classe.etudiant.through
# 	extra = 0




@admin.register(Ressource)
class RessourceAdmin(admin.ModelAdmin):
	pass


@admin.register(AnneeAcademique)
class AnneeAcademiqueAdmin(admin.ModelAdmin):
	pass


# @admin.register(Personne)
# class PersonneAdmin(admin.ModelAdmin):
# 	pass
# 	inlines = [DepartementInline, FiliereInline, ClasseInline, DepartementProfesseurInline]

@admin.register(Semestre)
class SemestreAdmin(admin.ModelAdmin):
	pass


@admin.register(Module)
class ModuleAdmin(admin.ModelAdmin):
	pass


@admin.register(Matiere)
class MatiereAdmin(admin.ModelAdmin):
	pass


@admin.register(PlanningSemaine)
class PlanningSemaineAdmin(admin.ModelAdmin):
	pass


@admin.register(PlanningEnseignant)
class PlanningEnseignantAdmin(admin.ModelAdmin):
	pass

@admin.register(Jour)
class JourAdmin(admin.ModelAdmin):
	pass


@admin.register(DoubleHeure)
class DoubleHeureAdmin(admin.ModelAdmin):
	pass


@admin.register(Etudiant)
class EtudiantAdmin(admin.ModelAdmin):
	pass


@admin.register(Professeur)
class ProfeseurAdmin(admin.ModelAdmin):
	pass

@admin.register(Parent)
class ParentAdmin(admin.ModelAdmin):
	pass

@admin.register(ResponsableNiveau)
class ResponsableNiveauAdmin(admin.ModelAdmin):
	pass

@admin.register(Delegue)
class DelegueAdmin(admin.ModelAdmin):
	pass

@admin.register(ChefDepartement)
class ChefDepartementAdmin(admin.ModelAdmin):
	pass

@admin.register(SalleDeClasse)
class SalleDeClasseAdmin(admin.ModelAdmin):
	pass

@admin.register(HeureProfesseur)
class HeureProfesseurAdmin(admin.ModelAdmin):
	pass

@admin.register(Statistique)
class StatistiqueAdmin(admin.ModelAdmin):
	pass

	


@admin.register(emploie_de_temps)
class emploie_de_tempsAdmin(admin.ModelAdmin):
	pass
# Register your models here.
