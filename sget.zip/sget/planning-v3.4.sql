--
-- PostgreSQL database dump
--

-- Dumped from database version 12.2 (Debian 12.2-1)
-- Dumped by pg_dump version 12.4 (Debian 12.4-3)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: leprince
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO leprince;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: leprince
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO leprince;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: leprince
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: leprince
--

CREATE TABLE public.auth_group_permissions (
    id bigint NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO leprince;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: leprince
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO leprince;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: leprince
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: leprince
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO leprince;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: leprince
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO leprince;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: leprince
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: leprince
--

CREATE TABLE public.auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(150) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO leprince;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: leprince
--

CREATE TABLE public.auth_user_groups (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO leprince;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: leprince
--

CREATE SEQUENCE public.auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_groups_id_seq OWNER TO leprince;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: leprince
--

ALTER SEQUENCE public.auth_user_groups_id_seq OWNED BY public.auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: leprince
--

CREATE SEQUENCE public.auth_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_id_seq OWNER TO leprince;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: leprince
--

ALTER SEQUENCE public.auth_user_id_seq OWNED BY public.auth_user.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: leprince
--

CREATE TABLE public.auth_user_user_permissions (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO leprince;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: leprince
--

CREATE SEQUENCE public.auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_user_permissions_id_seq OWNER TO leprince;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: leprince
--

ALTER SEQUENCE public.auth_user_user_permissions_id_seq OWNED BY public.auth_user_user_permissions.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: leprince
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO leprince;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: leprince
--

CREATE SEQUENCE public.django_admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO leprince;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: leprince
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: leprince
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO leprince;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: leprince
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO leprince;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: leprince
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: leprince
--

CREATE TABLE public.django_migrations (
    id bigint NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO leprince;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: leprince
--

CREATE SEQUENCE public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO leprince;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: leprince
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: leprince
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO leprince;

--
-- Name: planning_anneeacademique; Type: TABLE; Schema: public; Owner: leprince
--

CREATE TABLE public.planning_anneeacademique (
    id bigint NOT NULL,
    libelle character varying(25) NOT NULL
);


ALTER TABLE public.planning_anneeacademique OWNER TO leprince;

--
-- Name: planning_anneeacademique_id_seq; Type: SEQUENCE; Schema: public; Owner: leprince
--

CREATE SEQUENCE public.planning_anneeacademique_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.planning_anneeacademique_id_seq OWNER TO leprince;

--
-- Name: planning_anneeacademique_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: leprince
--

ALTER SEQUENCE public.planning_anneeacademique_id_seq OWNED BY public.planning_anneeacademique.id;


--
-- Name: planning_chefdepartement; Type: TABLE; Schema: public; Owner: leprince
--

CREATE TABLE public.planning_chefdepartement (
    professeur_ptr_id integer NOT NULL
);


ALTER TABLE public.planning_chefdepartement OWNER TO leprince;

--
-- Name: planning_classe; Type: TABLE; Schema: public; Owner: leprince
--

CREATE TABLE public.planning_classe (
    id bigint NOT NULL,
    libelle character varying(200) NOT NULL,
    nbre_etudiant smallint NOT NULL,
    filiere_id bigint NOT NULL,
    delegue_id integer NOT NULL,
    abrege character varying(10),
    CONSTRAINT planning_classe_nbre_etudiant_check CHECK ((nbre_etudiant >= 0))
);


ALTER TABLE public.planning_classe OWNER TO leprince;

--
-- Name: planning_classe_id_seq; Type: SEQUENCE; Schema: public; Owner: leprince
--

CREATE SEQUENCE public.planning_classe_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.planning_classe_id_seq OWNER TO leprince;

--
-- Name: planning_classe_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: leprince
--

ALTER SEQUENCE public.planning_classe_id_seq OWNED BY public.planning_classe.id;


--
-- Name: planning_delegue; Type: TABLE; Schema: public; Owner: leprince
--

CREATE TABLE public.planning_delegue (
    personne_ptr_id integer NOT NULL
);


ALTER TABLE public.planning_delegue OWNER TO leprince;

--
-- Name: planning_departement; Type: TABLE; Schema: public; Owner: leprince
--

CREATE TABLE public.planning_departement (
    id bigint NOT NULL,
    libelle character varying(200) NOT NULL,
    description text,
    nbre_filiere smallint,
    chef_departement_id integer,
    CONSTRAINT planning_departement_nbre_filiere_check CHECK ((nbre_filiere >= 0))
);


ALTER TABLE public.planning_departement OWNER TO leprince;

--
-- Name: planning_departement_id_seq; Type: SEQUENCE; Schema: public; Owner: leprince
--

CREATE SEQUENCE public.planning_departement_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.planning_departement_id_seq OWNER TO leprince;

--
-- Name: planning_departement_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: leprince
--

ALTER SEQUENCE public.planning_departement_id_seq OWNED BY public.planning_departement.id;


--
-- Name: planning_departement_professeurs; Type: TABLE; Schema: public; Owner: leprince
--

CREATE TABLE public.planning_departement_professeurs (
    id bigint NOT NULL,
    departement_id bigint NOT NULL,
    professeur_id integer NOT NULL
);


ALTER TABLE public.planning_departement_professeurs OWNER TO leprince;

--
-- Name: planning_departement_professeurs_id_seq; Type: SEQUENCE; Schema: public; Owner: leprince
--

CREATE SEQUENCE public.planning_departement_professeurs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.planning_departement_professeurs_id_seq OWNER TO leprince;

--
-- Name: planning_departement_professeurs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: leprince
--

ALTER SEQUENCE public.planning_departement_professeurs_id_seq OWNED BY public.planning_departement_professeurs.id;


--
-- Name: planning_doubleheure; Type: TABLE; Schema: public; Owner: leprince
--

CREATE TABLE public.planning_doubleheure (
    id bigint NOT NULL,
    heure_debut time without time zone NOT NULL,
    heure_fin time without time zone NOT NULL,
    etat character varying(100) NOT NULL,
    cour_effectif boolean NOT NULL,
    jour_id bigint NOT NULL,
    matiere_id bigint
);


ALTER TABLE public.planning_doubleheure OWNER TO leprince;

--
-- Name: planning_doubleheure_id_seq; Type: SEQUENCE; Schema: public; Owner: leprince
--

CREATE SEQUENCE public.planning_doubleheure_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.planning_doubleheure_id_seq OWNER TO leprince;

--
-- Name: planning_doubleheure_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: leprince
--

ALTER SEQUENCE public.planning_doubleheure_id_seq OWNED BY public.planning_doubleheure.id;


--
-- Name: planning_doubleheure_matieres; Type: TABLE; Schema: public; Owner: leprince
--

CREATE TABLE public.planning_doubleheure_matieres (
    id bigint NOT NULL,
    doubleheure_id bigint NOT NULL,
    matiere_id bigint NOT NULL
);


ALTER TABLE public.planning_doubleheure_matieres OWNER TO leprince;

--
-- Name: planning_doubleheure_matieres_id_seq; Type: SEQUENCE; Schema: public; Owner: leprince
--

CREATE SEQUENCE public.planning_doubleheure_matieres_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.planning_doubleheure_matieres_id_seq OWNER TO leprince;

--
-- Name: planning_doubleheure_matieres_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: leprince
--

ALTER SEQUENCE public.planning_doubleheure_matieres_id_seq OWNED BY public.planning_doubleheure_matieres.id;


--
-- Name: planning_etudiant; Type: TABLE; Schema: public; Owner: leprince
--

CREATE TABLE public.planning_etudiant (
    personne_ptr_id integer NOT NULL,
    option_id bigint NOT NULL
);


ALTER TABLE public.planning_etudiant OWNER TO leprince;

--
-- Name: planning_filiere; Type: TABLE; Schema: public; Owner: leprince
--

CREATE TABLE public.planning_filiere (
    id bigint NOT NULL,
    libelle character varying(200) NOT NULL,
    description text,
    nbre_etudiant smallint,
    niveau smallint NOT NULL,
    departement_id bigint NOT NULL,
    responsable_niveau_id integer NOT NULL,
    CONSTRAINT planning_filiere_nbre_etudiant_check CHECK ((nbre_etudiant >= 0)),
    CONSTRAINT planning_filiere_niveau_check CHECK ((niveau >= 0))
);


ALTER TABLE public.planning_filiere OWNER TO leprince;

--
-- Name: planning_filiere_id_seq; Type: SEQUENCE; Schema: public; Owner: leprince
--

CREATE SEQUENCE public.planning_filiere_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.planning_filiere_id_seq OWNER TO leprince;

--
-- Name: planning_filiere_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: leprince
--

ALTER SEQUENCE public.planning_filiere_id_seq OWNED BY public.planning_filiere.id;


--
-- Name: planning_jour; Type: TABLE; Schema: public; Owner: leprince
--

CREATE TABLE public.planning_jour (
    id bigint NOT NULL,
    libelle character varying(50) NOT NULL,
    date_jour date NOT NULL,
    jour_ferier boolean NOT NULL,
    planning_id bigint NOT NULL
);


ALTER TABLE public.planning_jour OWNER TO leprince;

--
-- Name: planning_jour_id_seq; Type: SEQUENCE; Schema: public; Owner: leprince
--

CREATE SEQUENCE public.planning_jour_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.planning_jour_id_seq OWNER TO leprince;

--
-- Name: planning_jour_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: leprince
--

ALTER SEQUENCE public.planning_jour_id_seq OWNED BY public.planning_jour.id;


--
-- Name: planning_matiere; Type: TABLE; Schema: public; Owner: leprince
--

CREATE TABLE public.planning_matiere (
    id bigint NOT NULL,
    libelle character varying(200) NOT NULL,
    code character varying(10) NOT NULL,
    credit smallint NOT NULL,
    heure_magistral smallint NOT NULL,
    heure_tpe smallint NOT NULL,
    heure_td smallint NOT NULL,
    total_heure smallint NOT NULL,
    module_id bigint NOT NULL,
    heure_tp smallint NOT NULL,
    option_id bigint,
    professeur_id integer,
    CONSTRAINT planning_matiere_credit_check CHECK ((credit >= 0)),
    CONSTRAINT planning_matiere_heure_magistral_check CHECK ((heure_magistral >= 0)),
    CONSTRAINT planning_matiere_heure_td_check CHECK ((heure_td >= 0)),
    CONSTRAINT planning_matiere_heure_tp_check CHECK ((heure_tp >= 0)),
    CONSTRAINT planning_matiere_heure_tpe_check CHECK ((heure_tpe >= 0)),
    CONSTRAINT planning_matiere_total_heure_check CHECK ((total_heure >= 0))
);


ALTER TABLE public.planning_matiere OWNER TO leprince;

--
-- Name: planning_matiere_id_seq; Type: SEQUENCE; Schema: public; Owner: leprince
--

CREATE SEQUENCE public.planning_matiere_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.planning_matiere_id_seq OWNER TO leprince;

--
-- Name: planning_matiere_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: leprince
--

ALTER SEQUENCE public.planning_matiere_id_seq OWNED BY public.planning_matiere.id;


--
-- Name: planning_module; Type: TABLE; Schema: public; Owner: leprince
--

CREATE TABLE public.planning_module (
    id bigint NOT NULL,
    libelle character varying(200),
    code character varying(10) NOT NULL,
    type_module character varying(25) NOT NULL,
    nbre_credit smallint NOT NULL,
    nbre_heure smallint NOT NULL,
    tpe smallint,
    numero_semestre smallint NOT NULL,
    departement_id bigint NOT NULL,
    CONSTRAINT planning_module_nbre_credit_check CHECK ((nbre_credit >= 0)),
    CONSTRAINT planning_module_nbre_heure_check CHECK ((nbre_heure >= 0)),
    CONSTRAINT planning_module_numero_semestre_check CHECK ((numero_semestre >= 0)),
    CONSTRAINT planning_module_tpe_check CHECK ((tpe >= 0))
);


ALTER TABLE public.planning_module OWNER TO leprince;

--
-- Name: planning_module_id_seq; Type: SEQUENCE; Schema: public; Owner: leprince
--

CREATE SEQUENCE public.planning_module_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.planning_module_id_seq OWNER TO leprince;

--
-- Name: planning_module_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: leprince
--

ALTER SEQUENCE public.planning_module_id_seq OWNED BY public.planning_module.id;


--
-- Name: planning_parent; Type: TABLE; Schema: public; Owner: leprince
--

CREATE TABLE public.planning_parent (
    personne_ptr_id integer NOT NULL
);


ALTER TABLE public.planning_parent OWNER TO leprince;

--
-- Name: planning_parent_enfants; Type: TABLE; Schema: public; Owner: leprince
--

CREATE TABLE public.planning_parent_enfants (
    id bigint NOT NULL,
    parent_id integer NOT NULL,
    etudiant_id integer NOT NULL
);


ALTER TABLE public.planning_parent_enfants OWNER TO leprince;

--
-- Name: planning_parent_enfants_id_seq; Type: SEQUENCE; Schema: public; Owner: leprince
--

CREATE SEQUENCE public.planning_parent_enfants_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.planning_parent_enfants_id_seq OWNER TO leprince;

--
-- Name: planning_parent_enfants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: leprince
--

ALTER SEQUENCE public.planning_parent_enfants_id_seq OWNED BY public.planning_parent_enfants.id;


--
-- Name: planning_personne; Type: TABLE; Schema: public; Owner: leprince
--

CREATE TABLE public.planning_personne (
    user_ptr_id integer NOT NULL,
    telephone character varying(25) NOT NULL
);


ALTER TABLE public.planning_personne OWNER TO leprince;

--
-- Name: planning_planningsemaine; Type: TABLE; Schema: public; Owner: leprince
--

CREATE TABLE public.planning_planningsemaine (
    id bigint NOT NULL,
    date_debut date NOT NULL,
    date_fin date NOT NULL,
    numero smallint NOT NULL,
    etat character varying(100) NOT NULL,
    classe_id bigint NOT NULL,
    responsable_niveau_id integer NOT NULL,
    semestre_id bigint,
    CONSTRAINT planning_planningsemaine_numero_check CHECK ((numero >= 0))
);


ALTER TABLE public.planning_planningsemaine OWNER TO leprince;

--
-- Name: planning_planningsemaine_id_seq; Type: SEQUENCE; Schema: public; Owner: leprince
--

CREATE SEQUENCE public.planning_planningsemaine_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.planning_planningsemaine_id_seq OWNER TO leprince;

--
-- Name: planning_planningsemaine_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: leprince
--

ALTER SEQUENCE public.planning_planningsemaine_id_seq OWNED BY public.planning_planningsemaine.id;


--
-- Name: planning_professeur; Type: TABLE; Schema: public; Owner: leprince
--

CREATE TABLE public.planning_professeur (
    personne_ptr_id integer NOT NULL,
    titre character varying(25) NOT NULL
);


ALTER TABLE public.planning_professeur OWNER TO leprince;

--
-- Name: planning_responsableniveau; Type: TABLE; Schema: public; Owner: leprince
--

CREATE TABLE public.planning_responsableniveau (
    professeur_ptr_id integer NOT NULL
);


ALTER TABLE public.planning_responsableniveau OWNER TO leprince;

--
-- Name: planning_ressource; Type: TABLE; Schema: public; Owner: leprince
--

CREATE TABLE public.planning_ressource (
    id bigint NOT NULL,
    libelle character varying(200) NOT NULL,
    description text NOT NULL,
    etat character varying(100) NOT NULL,
    "typeR" character varying(100) NOT NULL,
    classe_id bigint NOT NULL,
    departement_id bigint NOT NULL
);


ALTER TABLE public.planning_ressource OWNER TO leprince;

--
-- Name: planning_ressource_id_seq; Type: SEQUENCE; Schema: public; Owner: leprince
--

CREATE SEQUENCE public.planning_ressource_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.planning_ressource_id_seq OWNER TO leprince;

--
-- Name: planning_ressource_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: leprince
--

ALTER SEQUENCE public.planning_ressource_id_seq OWNED BY public.planning_ressource.id;


--
-- Name: planning_semestre; Type: TABLE; Schema: public; Owner: leprince
--

CREATE TABLE public.planning_semestre (
    id bigint NOT NULL,
    numero smallint NOT NULL,
    lmd smallint NOT NULL,
    date_debut date NOT NULL,
    date_fin date NOT NULL,
    annee_id bigint NOT NULL,
    CONSTRAINT planning_semestre_lmd_check CHECK ((lmd >= 0)),
    CONSTRAINT planning_semestre_numero_check CHECK ((numero >= 0))
);


ALTER TABLE public.planning_semestre OWNER TO leprince;

--
-- Name: planning_semestre_id_seq; Type: SEQUENCE; Schema: public; Owner: leprince
--

CREATE SEQUENCE public.planning_semestre_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.planning_semestre_id_seq OWNER TO leprince;

--
-- Name: planning_semestre_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: leprince
--

ALTER SEQUENCE public.planning_semestre_id_seq OWNED BY public.planning_semestre.id;


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: auth_user id; Type: DEFAULT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.auth_user ALTER COLUMN id SET DEFAULT nextval('public.auth_user_id_seq'::regclass);


--
-- Name: auth_user_groups id; Type: DEFAULT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.auth_user_groups ALTER COLUMN id SET DEFAULT nextval('public.auth_user_groups_id_seq'::regclass);


--
-- Name: auth_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_user_user_permissions_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: planning_anneeacademique id; Type: DEFAULT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_anneeacademique ALTER COLUMN id SET DEFAULT nextval('public.planning_anneeacademique_id_seq'::regclass);


--
-- Name: planning_classe id; Type: DEFAULT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_classe ALTER COLUMN id SET DEFAULT nextval('public.planning_classe_id_seq'::regclass);


--
-- Name: planning_departement id; Type: DEFAULT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_departement ALTER COLUMN id SET DEFAULT nextval('public.planning_departement_id_seq'::regclass);


--
-- Name: planning_departement_professeurs id; Type: DEFAULT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_departement_professeurs ALTER COLUMN id SET DEFAULT nextval('public.planning_departement_professeurs_id_seq'::regclass);


--
-- Name: planning_doubleheure id; Type: DEFAULT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_doubleheure ALTER COLUMN id SET DEFAULT nextval('public.planning_doubleheure_id_seq'::regclass);


--
-- Name: planning_doubleheure_matieres id; Type: DEFAULT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_doubleheure_matieres ALTER COLUMN id SET DEFAULT nextval('public.planning_doubleheure_matieres_id_seq'::regclass);


--
-- Name: planning_filiere id; Type: DEFAULT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_filiere ALTER COLUMN id SET DEFAULT nextval('public.planning_filiere_id_seq'::regclass);


--
-- Name: planning_jour id; Type: DEFAULT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_jour ALTER COLUMN id SET DEFAULT nextval('public.planning_jour_id_seq'::regclass);


--
-- Name: planning_matiere id; Type: DEFAULT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_matiere ALTER COLUMN id SET DEFAULT nextval('public.planning_matiere_id_seq'::regclass);


--
-- Name: planning_module id; Type: DEFAULT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_module ALTER COLUMN id SET DEFAULT nextval('public.planning_module_id_seq'::regclass);


--
-- Name: planning_parent_enfants id; Type: DEFAULT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_parent_enfants ALTER COLUMN id SET DEFAULT nextval('public.planning_parent_enfants_id_seq'::regclass);


--
-- Name: planning_planningsemaine id; Type: DEFAULT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_planningsemaine ALTER COLUMN id SET DEFAULT nextval('public.planning_planningsemaine_id_seq'::regclass);


--
-- Name: planning_ressource id; Type: DEFAULT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_ressource ALTER COLUMN id SET DEFAULT nextval('public.planning_ressource_id_seq'::regclass);


--
-- Name: planning_semestre id; Type: DEFAULT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_semestre ALTER COLUMN id SET DEFAULT nextval('public.planning_semestre_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: leprince
--

COPY public.auth_group (id, name) FROM stdin;
1	Parent
2	Etudiant
3	Delegue
4	Professeur
5	Responsable de Niveau
6	Chef de Departement
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: leprince
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
1	1	64
2	1	32
3	1	96
4	1	36
5	1	68
6	1	40
7	1	72
8	1	44
9	1	76
10	1	60
11	1	92
12	1	80
13	1	48
14	1	84
15	1	52
16	1	56
17	1	88
18	1	28
19	2	12
20	2	16
21	2	20
22	2	28
23	2	32
24	2	36
25	2	40
26	2	44
27	2	48
28	2	52
29	2	56
30	2	60
31	2	64
32	2	68
33	2	72
34	2	76
35	2	80
36	2	84
37	2	88
38	2	92
39	2	96
40	3	12
41	3	16
42	3	20
43	3	28
44	3	32
45	3	34
46	3	36
47	3	40
48	3	44
49	3	48
50	3	52
51	3	56
52	3	60
53	3	62
54	3	64
55	3	68
56	3	72
57	3	76
58	3	80
59	3	84
60	3	88
61	3	92
62	3	96
63	4	12
64	4	14
65	4	16
66	4	20
67	4	28
68	4	32
69	4	34
70	4	36
71	4	40
72	4	44
73	4	48
74	4	52
75	4	56
76	4	60
77	4	62
78	4	64
79	4	68
80	4	72
81	4	76
82	4	80
83	4	84
84	4	88
85	4	92
86	4	96
87	6	12
88	6	14
89	6	16
90	6	20
91	6	24
92	6	28
93	6	32
94	6	33
95	6	34
96	6	35
97	6	36
98	6	37
99	6	38
100	6	39
101	6	40
102	6	41
103	6	42
104	6	44
105	6	46
106	6	48
107	6	49
108	6	50
109	6	51
110	6	52
111	6	54
112	6	56
113	6	58
114	6	60
115	6	62
116	6	64
117	6	68
118	6	72
119	6	76
120	6	80
121	6	84
122	6	88
123	6	92
124	6	96
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: leprince
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	1	add_logentry
2	Can change log entry	1	change_logentry
3	Can delete log entry	1	delete_logentry
4	Can view log entry	1	view_logentry
5	Can add permission	2	add_permission
6	Can change permission	2	change_permission
7	Can delete permission	2	delete_permission
8	Can view permission	2	view_permission
9	Can add group	3	add_group
10	Can change group	3	change_group
11	Can delete group	3	delete_group
12	Can view group	3	view_group
13	Can add user	4	add_user
14	Can change user	4	change_user
15	Can delete user	4	delete_user
16	Can view user	4	view_user
17	Can add content type	5	add_contenttype
18	Can change content type	5	change_contenttype
19	Can delete content type	5	delete_contenttype
20	Can view content type	5	view_contenttype
21	Can add session	6	add_session
22	Can change session	6	change_session
23	Can delete session	6	delete_session
24	Can view session	6	view_session
25	Can add annee academique	7	add_anneeacademique
26	Can change annee academique	7	change_anneeacademique
27	Can delete annee academique	7	delete_anneeacademique
28	Can view annee academique	7	view_anneeacademique
29	Can add jour	8	add_jour
30	Can change jour	8	change_jour
31	Can delete jour	8	delete_jour
32	Can view jour	8	view_jour
33	Can add ressource	9	add_ressource
34	Can change ressource	9	change_ressource
35	Can delete ressource	9	delete_ressource
36	Can view ressource	9	view_ressource
37	Can add matiere	10	add_matiere
38	Can change matiere	10	change_matiere
39	Can delete matiere	10	delete_matiere
40	Can view matiere	10	view_matiere
41	Can add classe	11	add_classe
42	Can change classe	11	change_classe
43	Can delete classe	11	delete_classe
44	Can view classe	11	view_classe
45	Can add planning semaine	12	add_planningsemaine
46	Can change planning semaine	12	change_planningsemaine
47	Can delete planning semaine	12	delete_planningsemaine
48	Can view planning semaine	12	view_planningsemaine
49	Can add module	13	add_module
50	Can change module	13	change_module
51	Can delete module	13	delete_module
52	Can view module	13	view_module
53	Can add departement	14	add_departement
54	Can change departement	14	change_departement
55	Can delete departement	14	delete_departement
56	Can view departement	14	view_departement
57	Can add filiere	15	add_filiere
58	Can change filiere	15	change_filiere
59	Can delete filiere	15	delete_filiere
60	Can view filiere	15	view_filiere
61	Can add double heure	16	add_doubleheure
62	Can change double heure	16	change_doubleheure
63	Can delete double heure	16	delete_doubleheure
64	Can view double heure	16	view_doubleheure
65	Can add semestre	17	add_semestre
66	Can change semestre	17	change_semestre
67	Can delete semestre	17	delete_semestre
68	Can view semestre	17	view_semestre
69	Can add user	18	add_personne
70	Can change user	18	change_personne
71	Can delete user	18	delete_personne
72	Can view user	18	view_personne
73	Can add user	19	add_etudiant
74	Can change user	19	change_etudiant
75	Can delete user	19	delete_etudiant
76	Can view user	19	view_etudiant
77	Can add user	20	add_parent
78	Can change user	20	change_parent
79	Can delete user	20	delete_parent
80	Can view user	20	view_parent
81	Can add user	21	add_delegue
82	Can change user	21	change_delegue
83	Can delete user	21	delete_delegue
84	Can view user	21	view_delegue
85	Can add user	22	add_professeur
86	Can change user	22	change_professeur
87	Can delete user	22	delete_professeur
88	Can view user	22	view_professeur
89	Can add user	23	add_chefdepartement
90	Can change user	23	change_chefdepartement
91	Can delete user	23	delete_chefdepartement
92	Can view user	23	view_chefdepartement
93	Can add user	24	add_responsableniveau
94	Can change user	24	change_responsableniveau
95	Can delete user	24	delete_responsableniveau
96	Can view user	24	view_responsableniveau
\.


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: leprince
--

COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
9	pbkdf2_sha256$260000$JduZr4QLu5oTOCtIxOsQwh$7/n8t1jySeU7aSbc2t3NqwYhBnOSVsB73sMvKwxFEJY=	2021-05-18 18:08:22.648921+01	f	jho	jhoan	kamdem	jhoanprince@yahoo.fr	f	t	2021-05-16 19:26:05+01
6	pbkdf2_sha256$260000$aWlPKFW4UHUehfpYO5IF1b$pPpJLQ990fFK+QjZ89l9wwlBxuHkQBPRCUhHDBfK06I=	\N	f	armelsegue@gmail.com	armel	nsegue	armelsegue@gmail.com	f	t	2021-05-16 18:31:54+01
5	pbkdf2_sha256$260000$fqkyjkarDECCGlsKioleku$XzlMpqaoLkgj4k0VBJNJKoksoS27qtUTaW6yvNZ2HLs=	\N	f	tayouclementin@gmail.com	clementine	tayou	tayouclementin@gmail.com	f	t	2021-05-16 18:30:22+01
4	pbkdf2_sha256$260000$CHMYfqvi9ZByaniGtP19wv$/QPYjOiJQtJPhU9B6GqfRFdcEVEVlgympNXWlFN0A6Y=	2021-05-24 12:24:44.085613+01	f	leprince	jho	kamdem kamdem	jhoankamdem@gmail.com	f	t	2021-05-16 18:27:51+01
10	pbkdf2_sha256$260000$yPvUXLDBSTiKBco9ZjSdS1$6Ci6HMhqm4T6TYSQgRAFzpCSOukgYbafGJE5QqJDktY=	\N	f	noa	etoga	NHOA	noaetago@gmail.com	f	t	2021-05-24 14:08:26+01
7	pbkdf2_sha256$260000$tETDy6DmSh6bwZZmLOSBBE$uRnBNhI8NAQKIw9o0xYog3VChGNRrkSmRQ+2x3vo7XA=	2021-05-24 21:10:46.983199+01	f	noulamothiere@gmail.com	thierry	noulamo	noulamothiere@gmail.com	f	t	2021-05-16 18:34:16+01
8	pbkdf2_sha256$260000$jK7lvyDK2qw4ysgGyvpJ9n$GUhoqiK1qIaZgwaubjVaIUegyMEnxo24HrCPGfXPD6w=	2021-05-24 21:12:56.809865+01	f	foko	mikel	foko	fokomikel@gmail.com	f	t	2021-05-16 18:35:30+01
1	pbkdf2_sha256$260000$MTYpy0dgT7wR8pJEpjNE9N$Y+xK0VuCoMek4lD0LmInqq5uSddULjMnnbhaTW5ABIM=	2021-06-01 10:21:08.575892+01	t	admin			groupe16@iut.cm	t	t	2021-05-16 02:02:45.028507+01
\.


--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: leprince
--

COPY public.auth_user_groups (id, user_id, group_id) FROM stdin;
3	4	4
4	5	6
5	6	3
6	7	5
7	8	5
8	9	2
9	7	4
10	8	4
11	10	3
\.


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: leprince
--

COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: leprince
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
1	2021-05-16 18:05:08.120494+01	1	Parent	1	[{"added": {}}]	3	1
2	2021-05-16 18:09:18.80897+01	2	Etudiant	1	[{"added": {}}]	3	1
3	2021-05-16 18:11:54.03323+01	3	Delegue	1	[{"added": {}}]	3	1
4	2021-05-16 18:17:59.280334+01	4	Professeur	1	[{"added": {}}]	3	1
5	2021-05-16 18:18:05.977661+01	5	Responsable de Niveau	1	[{"added": {}}]	3	1
6	2021-05-16 18:18:14.629742+01	6	Chef de Departement	1	[{"added": {}}]	3	1
7	2021-05-16 18:27:00.178823+01	2	tayouclementin@gmail.com	1	[{"added": {}}]	22	1
8	2021-05-16 18:27:49.528647+01	3	djongo	1	[{"added": {}}]	22	1
9	2021-05-16 18:28:36.981879+01	4	leprince	1	[{"added": {}}]	22	1
10	2021-05-16 18:29:24.003998+01	3	djongo	3		22	1
11	2021-05-16 18:29:24.032771+01	2	tayouclementin@gmail.com	3		22	1
12	2021-05-16 18:29:40.779026+01	4	leprince	2	[{"changed": {"fields": ["Groups"]}}]	22	1
13	2021-05-16 18:31:39.213446+01	5	tayouclementin@gmail.com	1	[{"added": {}}]	23	1
14	2021-05-16 18:33:43.204441+01	6	armelsegue@gmail.com	1	[{"added": {}}]	21	1
15	2021-05-16 18:35:29.070209+01	7	noulamothiere@gmail.com	1	[{"added": {}}]	24	1
16	2021-05-16 18:36:32.054489+01	8	foko	1	[{"added": {}}]	24	1
17	2021-05-16 18:40:19.425888+01	5	Responsable de Niveau	2	[]	3	1
18	2021-05-16 18:43:59.960102+01	6	Chef de Departement	2	[{"changed": {"fields": ["Permissions"]}}]	3	1
19	2021-05-16 18:46:34.787985+01	1	Genie Informatique	1	[{"added": {}}]	14	1
20	2021-05-16 18:47:30.148349+01	1	genie informatique 1	1	[{"added": {}}]	15	1
21	2021-05-16 18:48:41.25087+01	2	genie informatique 2	1	[{"added": {}}]	15	1
22	2021-05-16 18:56:02.775901+01	1	genie logiciel	1	[{"added": {}}]	11	1
23	2021-05-16 18:56:29.197133+01	1	2012/2013	1	[{"added": {}}]	7	1
24	2021-05-16 18:56:34.51412+01	2	2020/2021	1	[{"added": {}}]	7	1
25	2021-05-16 18:56:39.572309+01	3	2013/2014	1	[{"added": {}}]	7	1
26	2021-05-16 19:02:20.066166+01	7	noulamothiere@gmail.com	2	[{"changed": {"fields": ["password"]}}]	4	1
27	2021-05-16 19:02:34.818747+01	7	noulamothiere@gmail.com	2	[]	4	1
28	2021-05-16 19:02:54.196579+01	6	armelsegue@gmail.com	2	[{"changed": {"fields": ["password"]}}]	4	1
29	2021-05-16 19:02:58.719608+01	6	armelsegue@gmail.com	2	[]	4	1
30	2021-05-16 19:06:56.593281+01	8	foko	2	[{"changed": {"fields": ["password"]}}]	4	1
31	2021-05-16 19:07:26.752419+01	8	foko	2	[]	4	1
32	2021-05-16 19:07:41.183991+01	4	leprince	2	[{"changed": {"fields": ["password"]}}]	4	1
33	2021-05-16 19:07:47.700509+01	4	leprince	2	[]	4	1
34	2021-05-16 19:08:25.659576+01	5	tayouclementin@gmail.com	2	[{"changed": {"fields": ["password"]}}]	4	1
35	2021-05-16 19:08:32.307254+01	5	tayouclementin@gmail.com	2	[]	4	1
36	2021-05-16 19:30:35.155596+01	9	Etudiant	1	[{"added": {}}]	19	1
37	2021-05-16 19:30:53.753031+01	9	jho	2	[{"changed": {"fields": ["password"]}}]	4	1
38	2021-05-16 19:31:00.611487+01	9	jho	2	[]	4	1
39	2021-05-17 21:17:11.088218+01	1	genie logiciel	2	[{"changed": {"fields": ["Abrege"]}}]	11	1
40	2021-05-17 21:33:32.784182+01	2	Mathematique et Cryptographie	1	[{"added": {}}]	13	1
41	2021-05-17 21:36:17.695618+01	1	Analyse Fontionnelle	1	[{"added": {}}]	10	1
42	2021-05-17 21:43:08.137016+01	2	Cryptographie	1	[{"added": {}}]	10	1
43	2021-05-17 21:43:34.00583+01	1	Analyse Fontionnelle	2	[{"changed": {"fields": ["Heure tpe"]}}]	10	1
44	2021-05-18 20:29:49.447868+01	7	noulamothiere@gmail.com	2	[{"changed": {"fields": ["Groups"]}}]	24	1
45	2021-05-18 20:30:03.354301+01	8	foko	2	[{"changed": {"fields": ["Groups"]}}]	24	1
46	2021-05-21 12:08:35.865598+01	3	base de donnee	1	[{"added": {}}]	10	1
47	2021-05-21 13:28:28.721828+01	3	base de donnee	2	[{"changed": {"fields": ["Professeur", "Option"]}}]	10	1
48	2021-05-21 13:28:50.206267+01	2	Cryptographie	2	[{"changed": {"fields": ["Professeur", "Option"]}}]	10	1
49	2021-05-21 13:29:11.405842+01	1	Analyse Fontionnelle	2	[{"changed": {"fields": ["Professeur", "Option"]}}]	10	1
50	2021-05-21 16:46:50.809563+01	2	S4/lmd6	3		17	1
51	2021-05-21 16:46:50.868557+01	1	S3/lmd3	3		17	1
52	2021-05-21 17:04:14.390214+01	11	S4/lmd6	3		17	1
53	2021-05-21 17:04:14.546689+01	10	S4/lmd6	3		17	1
54	2021-05-21 17:04:14.572122+01	9	S4/lmd6	3		17	1
55	2021-05-21 17:04:14.59508+01	8	S4/lmd6	3		17	1
56	2021-05-21 17:04:14.620249+01	7	S4/lmd6	3		17	1
57	2021-05-21 17:04:14.676403+01	6	S4/lmd6	3		17	1
58	2021-05-21 17:04:14.694021+01	5	S4/lmd6	3		17	1
59	2021-05-21 17:04:14.718417+01	4	S4/lmd6	3		17	1
60	2021-05-21 17:04:14.741141+01	3	S4/lmd6	3		17	1
61	2021-05-24 14:07:49.038806+01	1	genie logiciel	2	[]	11	1
62	2021-05-24 14:10:06.428062+01	10	noa	1	[{"added": {}}]	21	1
63	2021-05-24 14:10:33.451732+01	10	noa	2	[{"changed": {"fields": ["password"]}}]	4	1
64	2021-05-24 14:11:13.413342+01	2	genie informatique 1	1	[{"added": {}}]	11	1
65	2021-05-24 14:25:34.831102+01	3	LANGUE	1	[{"added": {}}]	13	1
66	2021-05-24 14:26:04.863231+01	4	Anglais Techique	1	[{"added": {}}]	10	1
67	2021-05-24 14:27:55.299679+01	4	Anglais Techique	2	[{"changed": {"fields": ["Module"]}}]	10	1
68	2021-06-01 10:22:40.470808+01	5	linux et programmation  systeme	1	[{"added": {}}]	10	1
69	2021-06-01 10:23:32.444449+01	6	tse	1	[{"added": {}}]	10	1
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: leprince
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	admin	logentry
2	auth	permission
3	auth	group
4	auth	user
5	contenttypes	contenttype
6	sessions	session
7	planning	anneeacademique
8	planning	jour
9	planning	ressource
10	planning	matiere
11	planning	classe
12	planning	planningsemaine
13	planning	module
14	planning	departement
15	planning	filiere
16	planning	doubleheure
17	planning	semestre
18	planning	personne
19	planning	etudiant
20	planning	parent
21	planning	delegue
22	planning	professeur
23	planning	chefdepartement
24	planning	responsableniveau
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: leprince
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2021-05-16 01:49:49.694533+01
2	auth	0001_initial	2021-05-16 01:49:50.814255+01
3	admin	0001_initial	2021-05-16 01:49:51.169483+01
4	admin	0002_logentry_remove_auto_add	2021-05-16 01:49:51.19716+01
5	admin	0003_logentry_add_action_flag_choices	2021-05-16 01:49:51.220979+01
6	contenttypes	0002_remove_content_type_name	2021-05-16 01:49:51.258447+01
7	auth	0002_alter_permission_name_max_length	2021-05-16 01:49:51.276857+01
8	auth	0003_alter_user_email_max_length	2021-05-16 01:49:51.300633+01
9	auth	0004_alter_user_username_opts	2021-05-16 01:49:51.323023+01
10	auth	0005_alter_user_last_login_null	2021-05-16 01:49:51.345402+01
11	auth	0006_require_contenttypes_0002	2021-05-16 01:49:51.357244+01
12	auth	0007_alter_validators_add_error_messages	2021-05-16 01:49:51.384577+01
13	auth	0008_alter_user_username_max_length	2021-05-16 01:49:51.463316+01
14	auth	0009_alter_user_last_name_max_length	2021-05-16 01:49:51.496217+01
15	auth	0010_alter_group_name_max_length	2021-05-16 01:49:51.529285+01
16	auth	0011_update_proxy_permissions	2021-05-16 01:49:51.555171+01
17	auth	0012_alter_user_first_name_max_length	2021-05-16 01:49:51.581169+01
18	sessions	0001_initial	2021-05-16 01:49:51.813576+01
19	planning	0001_initial	2021-05-16 01:58:20.24998+01
20	planning	0002_alter_planningsemaine_responsable_niveau	2021-05-16 02:12:26.38217+01
21	planning	0003_auto_20210516_0030	2021-05-16 02:12:26.516551+01
22	planning	0004_auto_20210516_0123	2021-05-16 02:24:00.237388+01
23	planning	0005_classe_abrege	2021-05-17 21:15:57.710861+01
24	planning	0006_rename_intitule_module_libelle	2021-05-17 21:31:54.129669+01
25	planning	0007_auto_20210517_2040	2021-05-17 21:40:44.39657+01
26	planning	0008_auto_20210521_1225	2021-05-21 13:27:51.501718+01
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: leprince
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
alpqltwtnco3k0qirr5pdx70tna3ad4d	.eJxVjMEOwiAQRP-FsyFsKd3i0bvfQGBZpGogKe3J-O9K0oMeZ96beQnn9y27vfHqlijOAsTptwueHlw6iHdfblVSLdu6BNkVedAmrzXy83K4fwfZt_xdY4qD0hrZ4KAtpTiPqgf0iQl1xAAmQTATgMWkeVTkKYFlZYgmnMX7A90oN-Q:1lk2rO:6tB7ZMlRXmWbcPfqlBJLwilhk-MTdmQhhCpV5SVn98o	2021-06-04 11:58:30.451802+01
1z0ustlpahtmlgpipzoxpveolno5qv5v	.eJxVjMEOwiAQRP-FsyFsKd3i0bvfQGBZpGogKe3J-O9K0oMeZ96beQnn9y27vfHqlijOAsTptwueHlw6iHdfblVSLdu6BNkVedAmrzXy83K4fwfZt_xdY4qD0hrZ4KAtpTiPqgf0iQl1xAAmQTATgMWkeVTkKYFlZYgmnMX7A90oN-Q:1llALp:ZoJf8K6xCc9yC6LW8BILAvqwqjlAozgRCcIVsJUFvPA	2021-06-07 14:10:33.6408+01
j8xnut9o3k4p21cc8pe36s38wxzp2vl9	.eJxVjEEOwiAQRe_C2pCBUqAu3fcMZJgBqRqalHZlvLtt0oVu33v_v0XAbS1ha2kJE4ur8OLyyyLSM9VD8APrfZY013WZojwSedomx5nT63a2fwcFW9nX2XrsM2btIKNjyz7CYHzsVceQDESnBzBWYwfWK8rkKCm1YyIN4FB8vuxVN8A:1llGwa:tknmEdZOnOP3jZFdP0pAp4rdVGcDD6SvsBwqgQ78oH4	2021-06-07 21:12:56.890042+01
coq5h8zyuo9wwtdr8yrugs6hisbbzyo9	.eJxVjMEOwiAQRP-FsyFsKd3i0bvfQGBZpGogKe3J-O9K0oMeZ96beQnn9y27vfHqlijOAsTptwueHlw6iHdfblVSLdu6BNkVedAmrzXy83K4fwfZt_xdY4qD0hrZ4KAtpTiPqgf0iQl1xAAmQTATgMWkeVTkKYFlZYgmnMX7A90oN-Q:1lo0aC:9QW8VF-9kyLbeHfZ7jHTC5Ro2ofKvcvqPnYKscIfh5Y	2021-06-15 10:21:08.707081+01
ip9samu02h14x2e6yyfb2t91u82plk1c	.eJxVjMEOwiAQRP-FsyFsKd3i0bvfQGBZpGogKe3J-O9K0oMeZ96beQnn9y27vfHqlijOAsTptwueHlw6iHdfblVSLdu6BNkVedAmrzXy83K4fwfZt_xdY4qD0hrZ4KAtpTiPqgf0iQl1xAAmQTATgMWkeVTkKYFlZYgmnMX7A90oN-Q:1lisWI:dTk1aVbsr2afxv9EzXLkQgWZfqDZr7VYX8PxKefSZM8	2021-06-01 06:43:54.132925+01
\.


--
-- Data for Name: planning_anneeacademique; Type: TABLE DATA; Schema: public; Owner: leprince
--

COPY public.planning_anneeacademique (id, libelle) FROM stdin;
1	2012/2013
2	2020/2021
3	2013/2014
\.


--
-- Data for Name: planning_chefdepartement; Type: TABLE DATA; Schema: public; Owner: leprince
--

COPY public.planning_chefdepartement (professeur_ptr_id) FROM stdin;
5
\.


--
-- Data for Name: planning_classe; Type: TABLE DATA; Schema: public; Owner: leprince
--

COPY public.planning_classe (id, libelle, nbre_etudiant, filiere_id, delegue_id, abrege) FROM stdin;
1	genie logiciel	80	2	6	GL
2	genie informatique 1	120	1	10	GI1
\.


--
-- Data for Name: planning_delegue; Type: TABLE DATA; Schema: public; Owner: leprince
--

COPY public.planning_delegue (personne_ptr_id) FROM stdin;
6
10
\.


--
-- Data for Name: planning_departement; Type: TABLE DATA; Schema: public; Owner: leprince
--

COPY public.planning_departement (id, libelle, description, nbre_filiere, chef_departement_id) FROM stdin;
1	Genie Informatique	le meilleur departement de liut	3	5
\.


--
-- Data for Name: planning_departement_professeurs; Type: TABLE DATA; Schema: public; Owner: leprince
--

COPY public.planning_departement_professeurs (id, departement_id, professeur_id) FROM stdin;
1	1	8
2	1	4
3	1	5
4	1	7
\.


--
-- Data for Name: planning_doubleheure; Type: TABLE DATA; Schema: public; Owner: leprince
--

COPY public.planning_doubleheure (id, heure_debut, heure_fin, etat, cour_effectif, jour_id, matiere_id) FROM stdin;
1489	07:30:00	09:30:00	non attribuer	f	373	\N
1490	09:30:00	11:30:00	non attribuer	f	373	\N
1491	12:00:00	14:00:00	non attribuer	f	373	\N
1492	14:00:00	16:00:00	non attribuer	f	373	\N
1493	07:30:00	09:30:00	non attribuer	f	374	\N
1494	09:30:00	11:30:00	non attribuer	f	374	\N
1495	12:00:00	14:00:00	non attribuer	f	374	\N
1496	14:00:00	16:00:00	non attribuer	f	374	\N
1497	07:30:00	09:30:00	non attribuer	f	375	\N
1498	09:30:00	11:30:00	non attribuer	f	375	\N
1499	12:00:00	14:00:00	non attribuer	f	375	\N
1500	14:00:00	16:00:00	non attribuer	f	375	\N
1501	07:30:00	09:30:00	non attribuer	f	376	\N
1502	09:30:00	11:30:00	non attribuer	f	376	\N
1503	12:00:00	14:00:00	non attribuer	f	376	\N
1504	14:00:00	16:00:00	non attribuer	f	376	\N
1505	07:30:00	09:30:00	non attribuer	f	377	\N
1506	09:30:00	11:30:00	non attribuer	f	377	\N
1507	12:00:00	14:00:00	non attribuer	f	377	\N
1508	14:00:00	16:00:00	non attribuer	f	377	\N
1509	07:30:00	09:30:00	non attribuer	f	378	\N
1510	09:30:00	11:30:00	non attribuer	f	378	\N
1511	12:00:00	14:00:00	non attribuer	f	378	\N
1512	14:00:00	16:00:00	non attribuer	f	378	\N
1513	07:30:00	09:30:00	non attribuer	f	379	\N
1514	09:30:00	11:30:00	non attribuer	f	379	\N
1515	12:00:00	14:00:00	non attribuer	f	379	\N
1516	14:00:00	16:00:00	non attribuer	f	379	\N
1517	07:30:00	09:30:00	non attribuer	f	380	\N
1518	09:30:00	11:30:00	non attribuer	f	380	\N
1519	12:00:00	14:00:00	non attribuer	f	380	\N
1520	14:00:00	16:00:00	non attribuer	f	380	\N
1521	07:30:00	09:30:00	non attribuer	f	381	\N
1522	09:30:00	11:30:00	non attribuer	f	381	\N
1523	12:00:00	14:00:00	non attribuer	f	381	\N
1524	14:00:00	16:00:00	non attribuer	f	381	\N
1525	07:30:00	09:30:00	non attribuer	f	382	\N
1526	09:30:00	11:30:00	non attribuer	f	382	\N
1527	12:00:00	14:00:00	non attribuer	f	382	\N
1528	14:00:00	16:00:00	non attribuer	f	382	\N
1529	07:30:00	09:30:00	non attribuer	f	383	\N
1530	09:30:00	11:30:00	non attribuer	f	383	\N
1531	12:00:00	14:00:00	non attribuer	f	383	\N
1532	14:00:00	16:00:00	non attribuer	f	383	\N
1533	07:30:00	09:30:00	non attribuer	f	384	\N
1534	09:30:00	11:30:00	non attribuer	f	384	\N
1535	12:00:00	14:00:00	non attribuer	f	384	\N
1536	14:00:00	16:00:00	non attribuer	f	384	\N
1537	07:30:00	09:30:00	non attribuer	f	385	\N
1538	09:30:00	11:30:00	non attribuer	f	385	\N
1539	12:00:00	14:00:00	non attribuer	f	385	\N
1540	14:00:00	16:00:00	non attribuer	f	385	\N
1541	07:30:00	09:30:00	non attribuer	f	386	\N
1542	09:30:00	11:30:00	non attribuer	f	386	\N
1543	12:00:00	14:00:00	non attribuer	f	386	\N
1544	14:00:00	16:00:00	non attribuer	f	386	\N
1545	07:30:00	09:30:00	non attribuer	f	387	\N
1546	09:30:00	11:30:00	non attribuer	f	387	\N
1547	12:00:00	14:00:00	non attribuer	f	387	\N
1548	14:00:00	16:00:00	non attribuer	f	387	\N
1549	07:30:00	09:30:00	non attribuer	f	388	\N
1550	09:30:00	11:30:00	non attribuer	f	388	\N
1551	12:00:00	14:00:00	non attribuer	f	388	\N
1552	14:00:00	16:00:00	non attribuer	f	388	\N
1553	07:30:00	09:30:00	non attribuer	f	389	\N
1554	09:30:00	11:30:00	non attribuer	f	389	\N
1555	12:00:00	14:00:00	non attribuer	f	389	\N
1556	14:00:00	16:00:00	non attribuer	f	389	\N
1557	07:30:00	09:30:00	non attribuer	f	390	\N
1558	09:30:00	11:30:00	non attribuer	f	390	\N
1559	12:00:00	14:00:00	non attribuer	f	390	\N
1560	14:00:00	16:00:00	non attribuer	f	390	\N
1561	07:30:00	09:30:00	non attribuer	f	391	\N
1562	09:30:00	11:30:00	non attribuer	f	391	\N
1563	12:00:00	14:00:00	non attribuer	f	391	\N
1564	14:00:00	16:00:00	non attribuer	f	391	\N
1565	07:30:00	09:30:00	non attribuer	f	392	\N
1566	09:30:00	11:30:00	non attribuer	f	392	\N
1567	12:00:00	14:00:00	non attribuer	f	392	\N
1568	14:00:00	16:00:00	non attribuer	f	392	\N
1569	07:30:00	09:30:00	non attribuer	f	393	\N
1570	09:30:00	11:30:00	non attribuer	f	393	\N
1571	12:00:00	14:00:00	non attribuer	f	393	\N
1572	14:00:00	16:00:00	non attribuer	f	393	\N
1573	07:30:00	09:30:00	non attribuer	f	394	\N
1574	09:30:00	11:30:00	non attribuer	f	394	\N
1575	12:00:00	14:00:00	non attribuer	f	394	\N
1576	14:00:00	16:00:00	non attribuer	f	394	\N
1577	07:30:00	09:30:00	non attribuer	f	395	\N
1578	09:30:00	11:30:00	non attribuer	f	395	\N
1579	12:00:00	14:00:00	non attribuer	f	395	\N
1580	14:00:00	16:00:00	non attribuer	f	395	\N
1581	07:30:00	09:30:00	non attribuer	f	396	\N
1582	09:30:00	11:30:00	non attribuer	f	396	\N
1583	12:00:00	14:00:00	non attribuer	f	396	\N
1584	14:00:00	16:00:00	non attribuer	f	396	\N
1585	07:30:00	09:30:00	non attribuer	f	397	\N
1586	09:30:00	11:30:00	non attribuer	f	397	\N
1587	12:00:00	14:00:00	non attribuer	f	397	\N
1588	14:00:00	16:00:00	non attribuer	f	397	\N
1589	07:30:00	09:30:00	non attribuer	f	398	\N
1590	09:30:00	11:30:00	non attribuer	f	398	\N
1591	12:00:00	14:00:00	non attribuer	f	398	\N
1592	14:00:00	16:00:00	non attribuer	f	398	\N
1593	07:30:00	09:30:00	non attribuer	f	399	\N
1594	09:30:00	11:30:00	non attribuer	f	399	\N
1595	12:00:00	14:00:00	non attribuer	f	399	\N
1596	14:00:00	16:00:00	non attribuer	f	399	\N
1597	07:30:00	09:30:00	non attribuer	f	400	\N
1598	09:30:00	11:30:00	non attribuer	f	400	\N
1599	12:00:00	14:00:00	non attribuer	f	400	\N
1600	14:00:00	16:00:00	non attribuer	f	400	\N
1601	07:30:00	09:30:00	non attribuer	f	401	\N
1602	09:30:00	11:30:00	non attribuer	f	401	\N
1603	12:00:00	14:00:00	non attribuer	f	401	\N
1604	14:00:00	16:00:00	non attribuer	f	401	\N
1605	07:30:00	09:30:00	non attribuer	f	402	\N
1606	09:30:00	11:30:00	non attribuer	f	402	\N
1607	12:00:00	14:00:00	non attribuer	f	402	\N
1608	14:00:00	16:00:00	non attribuer	f	402	\N
1609	07:30:00	09:30:00	non attribuer	f	403	\N
1610	09:30:00	11:30:00	non attribuer	f	403	\N
1611	12:00:00	14:00:00	non attribuer	f	403	\N
1612	14:00:00	16:00:00	non attribuer	f	403	\N
1613	07:30:00	09:30:00	non attribuer	f	404	\N
1614	09:30:00	11:30:00	non attribuer	f	404	\N
1615	12:00:00	14:00:00	non attribuer	f	404	\N
1616	14:00:00	16:00:00	non attribuer	f	404	\N
1617	07:30:00	09:30:00	non attribuer	f	405	\N
1618	09:30:00	11:30:00	non attribuer	f	405	\N
1619	12:00:00	14:00:00	non attribuer	f	405	\N
1620	14:00:00	16:00:00	non attribuer	f	405	\N
1621	07:30:00	09:30:00	non attribuer	f	406	\N
1622	09:30:00	11:30:00	non attribuer	f	406	\N
1623	12:00:00	14:00:00	non attribuer	f	406	\N
1624	14:00:00	16:00:00	non attribuer	f	406	\N
1625	07:30:00	09:30:00	non attribuer	f	407	\N
1626	09:30:00	11:30:00	non attribuer	f	407	\N
1627	12:00:00	14:00:00	non attribuer	f	407	\N
1628	14:00:00	16:00:00	non attribuer	f	407	\N
1629	07:30:00	09:30:00	non attribuer	f	408	\N
1630	09:30:00	11:30:00	non attribuer	f	408	\N
1631	12:00:00	14:00:00	non attribuer	f	408	\N
1632	14:00:00	16:00:00	non attribuer	f	408	\N
1633	07:30:00	09:30:00	non attribuer	f	409	\N
1634	09:30:00	11:30:00	non attribuer	f	409	\N
1635	12:00:00	14:00:00	non attribuer	f	409	\N
1636	14:00:00	16:00:00	non attribuer	f	409	\N
1637	07:30:00	09:30:00	non attribuer	f	410	\N
1638	09:30:00	11:30:00	non attribuer	f	410	\N
1639	12:00:00	14:00:00	non attribuer	f	410	\N
1640	14:00:00	16:00:00	non attribuer	f	410	\N
1641	07:30:00	09:30:00	non attribuer	f	411	\N
1642	09:30:00	11:30:00	non attribuer	f	411	\N
1643	12:00:00	14:00:00	non attribuer	f	411	\N
1644	14:00:00	16:00:00	non attribuer	f	411	\N
1645	07:30:00	09:30:00	non attribuer	f	412	\N
1646	09:30:00	11:30:00	non attribuer	f	412	\N
1647	12:00:00	14:00:00	non attribuer	f	412	\N
1648	14:00:00	16:00:00	non attribuer	f	412	\N
1649	07:30:00	09:30:00	non attribuer	f	413	\N
1650	09:30:00	11:30:00	non attribuer	f	413	\N
1651	12:00:00	14:00:00	non attribuer	f	413	\N
1652	14:00:00	16:00:00	non attribuer	f	413	\N
1653	07:30:00	09:30:00	non attribuer	f	414	\N
1654	09:30:00	11:30:00	non attribuer	f	414	\N
1655	12:00:00	14:00:00	non attribuer	f	414	\N
1656	14:00:00	16:00:00	non attribuer	f	414	\N
1657	07:30:00	09:30:00	non attribuer	f	415	\N
1658	09:30:00	11:30:00	non attribuer	f	415	\N
1659	12:00:00	14:00:00	non attribuer	f	415	\N
1660	14:00:00	16:00:00	non attribuer	f	415	\N
1661	07:30:00	09:30:00	non attribuer	f	416	\N
1662	09:30:00	11:30:00	non attribuer	f	416	\N
1663	12:00:00	14:00:00	non attribuer	f	416	\N
1664	14:00:00	16:00:00	non attribuer	f	416	\N
1665	07:30:00	09:30:00	non attribuer	f	417	\N
1666	09:30:00	11:30:00	non attribuer	f	417	\N
1667	12:00:00	14:00:00	non attribuer	f	417	\N
1668	14:00:00	16:00:00	non attribuer	f	417	\N
1669	07:30:00	09:30:00	non attribuer	f	418	\N
1670	09:30:00	11:30:00	non attribuer	f	418	\N
1671	12:00:00	14:00:00	non attribuer	f	418	\N
1672	14:00:00	16:00:00	non attribuer	f	418	\N
1673	07:30:00	09:30:00	non attribuer	f	419	\N
1674	09:30:00	11:30:00	non attribuer	f	419	\N
1675	12:00:00	14:00:00	non attribuer	f	419	\N
1676	14:00:00	16:00:00	non attribuer	f	419	\N
1677	07:30:00	09:30:00	non attribuer	f	420	\N
1678	09:30:00	11:30:00	non attribuer	f	420	\N
1679	12:00:00	14:00:00	non attribuer	f	420	\N
1680	14:00:00	16:00:00	non attribuer	f	420	\N
1686	09:30:00	11:30:00	non attribuer	f	422	\N
1688	14:00:00	16:00:00	non attribuer	f	422	\N
1689	07:30:00	09:30:00	non attribuer	f	423	\N
1692	14:00:00	16:00:00	non attribuer	f	423	\N
1693	07:30:00	09:30:00	non attribuer	f	424	\N
1695	12:00:00	14:00:00	non attribuer	f	424	\N
1696	14:00:00	16:00:00	non attribuer	f	424	\N
1697	07:30:00	09:30:00	non attribuer	f	425	\N
1698	09:30:00	11:30:00	non attribuer	f	425	\N
1699	12:00:00	14:00:00	non attribuer	f	425	\N
1700	14:00:00	16:00:00	non attribuer	f	425	\N
1683	12:00:00	14:00:00	valider	f	421	3
1687	12:00:00	14:00:00	valider	f	422	3
1682	09:30:00	11:30:00	valider	f	421	3
1691	12:00:00	14:00:00	valider	f	423	3
1694	09:30:00	11:30:00	valider	f	424	3
1690	09:30:00	11:30:00	valider	f	423	2
1701	07:30:00	09:30:00	valider	f	426	2
1685	07:30:00	09:30:00	valider	f	422	1
1703	12:00:00	14:00:00	non attribuer	f	426	\N
1704	14:00:00	16:00:00	non attribuer	f	426	\N
1717	07:30:00	09:30:00	non attribuer	f	430	\N
1718	09:30:00	11:30:00	non attribuer	f	430	\N
1719	12:00:00	14:00:00	non attribuer	f	430	\N
1720	14:00:00	16:00:00	non attribuer	f	430	\N
1721	07:30:00	09:30:00	non attribuer	f	431	\N
1722	09:30:00	11:30:00	non attribuer	f	431	\N
1723	12:00:00	14:00:00	non attribuer	f	431	\N
1724	14:00:00	16:00:00	non attribuer	f	431	\N
1725	07:30:00	09:30:00	non attribuer	f	432	\N
1726	09:30:00	11:30:00	non attribuer	f	432	\N
1727	12:00:00	14:00:00	non attribuer	f	432	\N
1728	14:00:00	16:00:00	non attribuer	f	432	\N
1729	07:30:00	09:30:00	non attribuer	f	433	\N
1730	09:30:00	11:30:00	non attribuer	f	433	\N
1731	12:00:00	14:00:00	non attribuer	f	433	\N
1732	14:00:00	16:00:00	non attribuer	f	433	\N
1733	07:30:00	09:30:00	non attribuer	f	434	\N
1734	09:30:00	11:30:00	non attribuer	f	434	\N
1735	12:00:00	14:00:00	non attribuer	f	434	\N
1736	14:00:00	16:00:00	non attribuer	f	434	\N
1737	07:30:00	09:30:00	non attribuer	f	435	\N
1738	09:30:00	11:30:00	non attribuer	f	435	\N
1739	12:00:00	14:00:00	non attribuer	f	435	\N
1740	14:00:00	16:00:00	non attribuer	f	435	\N
1741	07:30:00	09:30:00	non attribuer	f	436	\N
1742	09:30:00	11:30:00	non attribuer	f	436	\N
1743	12:00:00	14:00:00	non attribuer	f	436	\N
1744	14:00:00	16:00:00	non attribuer	f	436	\N
1745	07:30:00	09:30:00	non attribuer	f	437	\N
1746	09:30:00	11:30:00	non attribuer	f	437	\N
1747	12:00:00	14:00:00	non attribuer	f	437	\N
1748	14:00:00	16:00:00	non attribuer	f	437	\N
1749	07:30:00	09:30:00	non attribuer	f	438	\N
1750	09:30:00	11:30:00	non attribuer	f	438	\N
1751	12:00:00	14:00:00	non attribuer	f	438	\N
1752	14:00:00	16:00:00	non attribuer	f	438	\N
1753	07:30:00	09:30:00	non attribuer	f	439	\N
1754	09:30:00	11:30:00	non attribuer	f	439	\N
1755	12:00:00	14:00:00	non attribuer	f	439	\N
1756	14:00:00	16:00:00	non attribuer	f	439	\N
1757	07:30:00	09:30:00	non attribuer	f	440	\N
1758	09:30:00	11:30:00	non attribuer	f	440	\N
1759	12:00:00	14:00:00	non attribuer	f	440	\N
1760	14:00:00	16:00:00	non attribuer	f	440	\N
1761	07:30:00	09:30:00	non attribuer	f	441	\N
1762	09:30:00	11:30:00	non attribuer	f	441	\N
1763	12:00:00	14:00:00	non attribuer	f	441	\N
1764	14:00:00	16:00:00	non attribuer	f	441	\N
1765	07:30:00	09:30:00	non attribuer	f	442	\N
1766	09:30:00	11:30:00	non attribuer	f	442	\N
1767	12:00:00	14:00:00	non attribuer	f	442	\N
1768	14:00:00	16:00:00	non attribuer	f	442	\N
1769	07:30:00	09:30:00	non attribuer	f	443	\N
1770	09:30:00	11:30:00	non attribuer	f	443	\N
1771	12:00:00	14:00:00	non attribuer	f	443	\N
1772	14:00:00	16:00:00	non attribuer	f	443	\N
1773	07:30:00	09:30:00	non attribuer	f	444	\N
1774	09:30:00	11:30:00	non attribuer	f	444	\N
1775	12:00:00	14:00:00	non attribuer	f	444	\N
1776	14:00:00	16:00:00	non attribuer	f	444	\N
1777	07:30:00	09:30:00	non attribuer	f	445	\N
1778	09:30:00	11:30:00	non attribuer	f	445	\N
1779	12:00:00	14:00:00	non attribuer	f	445	\N
1780	14:00:00	16:00:00	non attribuer	f	445	\N
1781	07:30:00	09:30:00	non attribuer	f	446	\N
1782	09:30:00	11:30:00	non attribuer	f	446	\N
1783	12:00:00	14:00:00	non attribuer	f	446	\N
1784	14:00:00	16:00:00	non attribuer	f	446	\N
1785	07:30:00	09:30:00	non attribuer	f	447	\N
1786	09:30:00	11:30:00	non attribuer	f	447	\N
1787	12:00:00	14:00:00	non attribuer	f	447	\N
1788	14:00:00	16:00:00	non attribuer	f	447	\N
1789	07:30:00	09:30:00	non attribuer	f	448	\N
1790	09:30:00	11:30:00	non attribuer	f	448	\N
1791	12:00:00	14:00:00	non attribuer	f	448	\N
1792	14:00:00	16:00:00	non attribuer	f	448	\N
1793	07:30:00	09:30:00	non attribuer	f	449	\N
1794	09:30:00	11:30:00	non attribuer	f	449	\N
1795	12:00:00	14:00:00	non attribuer	f	449	\N
1796	14:00:00	16:00:00	non attribuer	f	449	\N
1797	07:30:00	09:30:00	non attribuer	f	450	\N
1798	09:30:00	11:30:00	non attribuer	f	450	\N
1799	12:00:00	14:00:00	non attribuer	f	450	\N
1800	14:00:00	16:00:00	non attribuer	f	450	\N
1801	07:30:00	09:30:00	non attribuer	f	451	\N
1802	09:30:00	11:30:00	non attribuer	f	451	\N
1803	12:00:00	14:00:00	non attribuer	f	451	\N
1804	14:00:00	16:00:00	non attribuer	f	451	\N
1805	07:30:00	09:30:00	non attribuer	f	452	\N
1806	09:30:00	11:30:00	non attribuer	f	452	\N
1807	12:00:00	14:00:00	non attribuer	f	452	\N
1808	14:00:00	16:00:00	non attribuer	f	452	\N
1809	07:30:00	09:30:00	non attribuer	f	453	\N
1706	09:30:00	11:30:00	valider	f	427	3
1707	12:00:00	14:00:00	valider	f	427	3
1708	14:00:00	16:00:00	valider	f	427	3
1710	09:30:00	11:30:00	valider	f	428	3
1711	12:00:00	14:00:00	valider	f	428	3
1712	14:00:00	16:00:00	valider	f	428	3
1713	07:30:00	09:30:00	valider	f	429	2
1714	09:30:00	11:30:00	valider	f	429	2
1715	12:00:00	14:00:00	valider	f	429	2
1810	09:30:00	11:30:00	non attribuer	f	453	\N
1811	12:00:00	14:00:00	non attribuer	f	453	\N
1812	14:00:00	16:00:00	non attribuer	f	453	\N
1813	07:30:00	09:30:00	non attribuer	f	454	\N
1814	09:30:00	11:30:00	non attribuer	f	454	\N
1815	12:00:00	14:00:00	non attribuer	f	454	\N
1816	14:00:00	16:00:00	non attribuer	f	454	\N
1817	07:30:00	09:30:00	non attribuer	f	455	\N
1818	09:30:00	11:30:00	non attribuer	f	455	\N
1819	12:00:00	14:00:00	non attribuer	f	455	\N
1820	14:00:00	16:00:00	non attribuer	f	455	\N
1821	07:30:00	09:30:00	non attribuer	f	456	\N
1822	09:30:00	11:30:00	non attribuer	f	456	\N
1823	12:00:00	14:00:00	non attribuer	f	456	\N
1824	14:00:00	16:00:00	non attribuer	f	456	\N
1825	07:30:00	09:30:00	non attribuer	f	457	\N
1826	09:30:00	11:30:00	non attribuer	f	457	\N
1827	12:00:00	14:00:00	non attribuer	f	457	\N
1828	14:00:00	16:00:00	non attribuer	f	457	\N
1829	07:30:00	09:30:00	non attribuer	f	458	\N
1830	09:30:00	11:30:00	non attribuer	f	458	\N
1831	12:00:00	14:00:00	non attribuer	f	458	\N
1832	14:00:00	16:00:00	non attribuer	f	458	\N
1833	07:30:00	09:30:00	non attribuer	f	459	\N
1834	09:30:00	11:30:00	non attribuer	f	459	\N
1835	12:00:00	14:00:00	non attribuer	f	459	\N
1836	14:00:00	16:00:00	non attribuer	f	459	\N
1837	07:30:00	09:30:00	non attribuer	f	460	\N
1838	09:30:00	11:30:00	non attribuer	f	460	\N
1839	12:00:00	14:00:00	non attribuer	f	460	\N
1840	14:00:00	16:00:00	non attribuer	f	460	\N
1841	07:30:00	09:30:00	non attribuer	f	461	\N
1842	09:30:00	11:30:00	non attribuer	f	461	\N
1843	12:00:00	14:00:00	non attribuer	f	461	\N
1844	14:00:00	16:00:00	non attribuer	f	461	\N
1845	07:30:00	09:30:00	non attribuer	f	462	\N
1846	09:30:00	11:30:00	non attribuer	f	462	\N
1847	12:00:00	14:00:00	non attribuer	f	462	\N
1848	14:00:00	16:00:00	non attribuer	f	462	\N
1849	07:30:00	09:30:00	non attribuer	f	463	\N
1850	09:30:00	11:30:00	non attribuer	f	463	\N
1851	12:00:00	14:00:00	non attribuer	f	463	\N
1852	14:00:00	16:00:00	non attribuer	f	463	\N
1853	07:30:00	09:30:00	non attribuer	f	464	\N
1854	09:30:00	11:30:00	non attribuer	f	464	\N
1855	12:00:00	14:00:00	non attribuer	f	464	\N
1856	14:00:00	16:00:00	non attribuer	f	464	\N
1857	07:30:00	09:30:00	non attribuer	f	465	\N
1858	09:30:00	11:30:00	non attribuer	f	465	\N
1859	12:00:00	14:00:00	non attribuer	f	465	\N
1860	14:00:00	16:00:00	non attribuer	f	465	\N
1861	07:30:00	09:30:00	non attribuer	f	466	\N
1862	09:30:00	11:30:00	non attribuer	f	466	\N
1863	12:00:00	14:00:00	non attribuer	f	466	\N
1864	14:00:00	16:00:00	non attribuer	f	466	\N
1865	07:30:00	09:30:00	non attribuer	f	467	\N
1866	09:30:00	11:30:00	non attribuer	f	467	\N
1867	12:00:00	14:00:00	non attribuer	f	467	\N
1868	14:00:00	16:00:00	non attribuer	f	467	\N
1869	07:30:00	09:30:00	non attribuer	f	468	\N
1870	09:30:00	11:30:00	non attribuer	f	468	\N
1871	12:00:00	14:00:00	non attribuer	f	468	\N
1872	14:00:00	16:00:00	non attribuer	f	468	\N
1873	07:30:00	09:30:00	non attribuer	f	469	\N
1874	09:30:00	11:30:00	non attribuer	f	469	\N
1875	12:00:00	14:00:00	non attribuer	f	469	\N
1876	14:00:00	16:00:00	non attribuer	f	469	\N
1877	07:30:00	09:30:00	non attribuer	f	470	\N
1878	09:30:00	11:30:00	non attribuer	f	470	\N
1879	12:00:00	14:00:00	non attribuer	f	470	\N
1880	14:00:00	16:00:00	non attribuer	f	470	\N
1881	07:30:00	09:30:00	non attribuer	f	471	\N
1882	09:30:00	11:30:00	non attribuer	f	471	\N
1883	12:00:00	14:00:00	non attribuer	f	471	\N
1884	14:00:00	16:00:00	non attribuer	f	471	\N
1885	07:30:00	09:30:00	non attribuer	f	472	\N
1886	09:30:00	11:30:00	non attribuer	f	472	\N
1887	12:00:00	14:00:00	non attribuer	f	472	\N
1888	14:00:00	16:00:00	non attribuer	f	472	\N
1889	07:30:00	09:30:00	non attribuer	f	473	\N
1890	09:30:00	11:30:00	non attribuer	f	473	\N
1891	12:00:00	14:00:00	non attribuer	f	473	\N
1892	14:00:00	16:00:00	non attribuer	f	473	\N
1893	07:30:00	09:30:00	non attribuer	f	474	\N
1894	09:30:00	11:30:00	non attribuer	f	474	\N
1895	12:00:00	14:00:00	non attribuer	f	474	\N
1896	14:00:00	16:00:00	non attribuer	f	474	\N
1897	07:30:00	09:30:00	non attribuer	f	475	\N
1898	09:30:00	11:30:00	non attribuer	f	475	\N
1899	12:00:00	14:00:00	non attribuer	f	475	\N
1900	14:00:00	16:00:00	non attribuer	f	475	\N
1901	07:30:00	09:30:00	non attribuer	f	476	\N
1902	09:30:00	11:30:00	non attribuer	f	476	\N
1903	12:00:00	14:00:00	non attribuer	f	476	\N
1904	14:00:00	16:00:00	non attribuer	f	476	\N
1905	07:30:00	09:30:00	non attribuer	f	477	\N
1906	09:30:00	11:30:00	non attribuer	f	477	\N
1907	12:00:00	14:00:00	non attribuer	f	477	\N
1908	14:00:00	16:00:00	non attribuer	f	477	\N
1909	07:30:00	09:30:00	non attribuer	f	478	\N
1910	09:30:00	11:30:00	non attribuer	f	478	\N
1911	12:00:00	14:00:00	non attribuer	f	478	\N
1912	14:00:00	16:00:00	non attribuer	f	478	\N
1913	07:30:00	09:30:00	non attribuer	f	479	\N
1914	09:30:00	11:30:00	non attribuer	f	479	\N
1915	12:00:00	14:00:00	non attribuer	f	479	\N
1916	14:00:00	16:00:00	non attribuer	f	479	\N
1917	07:30:00	09:30:00	non attribuer	f	480	\N
1918	09:30:00	11:30:00	non attribuer	f	480	\N
1919	12:00:00	14:00:00	non attribuer	f	480	\N
1920	14:00:00	16:00:00	non attribuer	f	480	\N
1681	07:30:00	09:30:00	non attribuer	f	421	\N
1684	14:00:00	16:00:00	valider	f	421	3
1702	09:30:00	11:30:00	valider	f	426	1
1705	07:30:00	09:30:00	valider	f	427	3
1709	07:30:00	09:30:00	valider	f	428	3
1716	14:00:00	16:00:00	valider	f	429	2
1921	07:30:00	09:30:00	non attribuer	f	481	\N
1922	09:30:00	11:30:00	non attribuer	f	481	\N
1923	12:00:00	14:00:00	non attribuer	f	481	\N
1924	14:00:00	16:00:00	non attribuer	f	481	\N
1925	07:30:00	09:30:00	non attribuer	f	482	\N
1926	09:30:00	11:30:00	non attribuer	f	482	\N
1927	12:00:00	14:00:00	non attribuer	f	482	\N
1928	14:00:00	16:00:00	non attribuer	f	482	\N
1929	07:30:00	09:30:00	non attribuer	f	483	\N
1930	09:30:00	11:30:00	non attribuer	f	483	\N
1931	12:00:00	14:00:00	non attribuer	f	483	\N
1932	14:00:00	16:00:00	non attribuer	f	483	\N
1933	07:30:00	09:30:00	non attribuer	f	484	\N
1934	09:30:00	11:30:00	non attribuer	f	484	\N
1935	12:00:00	14:00:00	non attribuer	f	484	\N
1936	14:00:00	16:00:00	non attribuer	f	484	\N
1937	07:30:00	09:30:00	non attribuer	f	485	\N
1938	09:30:00	11:30:00	non attribuer	f	485	\N
1939	12:00:00	14:00:00	non attribuer	f	485	\N
1940	14:00:00	16:00:00	non attribuer	f	485	\N
1941	07:30:00	09:30:00	non attribuer	f	486	\N
1942	09:30:00	11:30:00	non attribuer	f	486	\N
1943	12:00:00	14:00:00	non attribuer	f	486	\N
1944	14:00:00	16:00:00	non attribuer	f	486	\N
1945	07:30:00	09:30:00	non attribuer	f	487	\N
1946	09:30:00	11:30:00	non attribuer	f	487	\N
1947	12:00:00	14:00:00	non attribuer	f	487	\N
1948	14:00:00	16:00:00	non attribuer	f	487	\N
1949	07:30:00	09:30:00	non attribuer	f	488	\N
1950	09:30:00	11:30:00	non attribuer	f	488	\N
1951	12:00:00	14:00:00	non attribuer	f	488	\N
1952	14:00:00	16:00:00	non attribuer	f	488	\N
1953	07:30:00	09:30:00	non attribuer	f	489	\N
1954	09:30:00	11:30:00	non attribuer	f	489	\N
1955	12:00:00	14:00:00	non attribuer	f	489	\N
1956	14:00:00	16:00:00	non attribuer	f	489	\N
1957	07:30:00	09:30:00	non attribuer	f	490	\N
1958	09:30:00	11:30:00	non attribuer	f	490	\N
1959	12:00:00	14:00:00	non attribuer	f	490	\N
1960	14:00:00	16:00:00	non attribuer	f	490	\N
1961	07:30:00	09:30:00	non attribuer	f	491	\N
1962	09:30:00	11:30:00	non attribuer	f	491	\N
1963	12:00:00	14:00:00	non attribuer	f	491	\N
1964	14:00:00	16:00:00	non attribuer	f	491	\N
1965	07:30:00	09:30:00	non attribuer	f	492	\N
1966	09:30:00	11:30:00	non attribuer	f	492	\N
1967	12:00:00	14:00:00	non attribuer	f	492	\N
1968	14:00:00	16:00:00	non attribuer	f	492	\N
1969	07:30:00	09:30:00	non attribuer	f	493	\N
1970	09:30:00	11:30:00	non attribuer	f	493	\N
1971	12:00:00	14:00:00	non attribuer	f	493	\N
1972	14:00:00	16:00:00	non attribuer	f	493	\N
1973	07:30:00	09:30:00	non attribuer	f	494	\N
1974	09:30:00	11:30:00	non attribuer	f	494	\N
1975	12:00:00	14:00:00	non attribuer	f	494	\N
1976	14:00:00	16:00:00	non attribuer	f	494	\N
1977	07:30:00	09:30:00	non attribuer	f	495	\N
1978	09:30:00	11:30:00	non attribuer	f	495	\N
1979	12:00:00	14:00:00	non attribuer	f	495	\N
1980	14:00:00	16:00:00	non attribuer	f	495	\N
1981	07:30:00	09:30:00	non attribuer	f	496	\N
1982	09:30:00	11:30:00	non attribuer	f	496	\N
1983	12:00:00	14:00:00	non attribuer	f	496	\N
1984	14:00:00	16:00:00	non attribuer	f	496	\N
1985	07:30:00	09:30:00	non attribuer	f	497	\N
1986	09:30:00	11:30:00	non attribuer	f	497	\N
1987	12:00:00	14:00:00	non attribuer	f	497	\N
1988	14:00:00	16:00:00	non attribuer	f	497	\N
1989	07:30:00	09:30:00	non attribuer	f	498	\N
1990	09:30:00	11:30:00	non attribuer	f	498	\N
1991	12:00:00	14:00:00	non attribuer	f	498	\N
1992	14:00:00	16:00:00	non attribuer	f	498	\N
1993	07:30:00	09:30:00	non attribuer	f	499	\N
1994	09:30:00	11:30:00	non attribuer	f	499	\N
1995	12:00:00	14:00:00	non attribuer	f	499	\N
1996	14:00:00	16:00:00	non attribuer	f	499	\N
1997	07:30:00	09:30:00	non attribuer	f	500	\N
1998	09:30:00	11:30:00	non attribuer	f	500	\N
1999	12:00:00	14:00:00	non attribuer	f	500	\N
2000	14:00:00	16:00:00	non attribuer	f	500	\N
2001	07:30:00	09:30:00	non attribuer	f	501	\N
2002	09:30:00	11:30:00	non attribuer	f	501	\N
2003	12:00:00	14:00:00	non attribuer	f	501	\N
2004	14:00:00	16:00:00	non attribuer	f	501	\N
2005	07:30:00	09:30:00	non attribuer	f	502	\N
2006	09:30:00	11:30:00	non attribuer	f	502	\N
2007	12:00:00	14:00:00	non attribuer	f	502	\N
2008	14:00:00	16:00:00	non attribuer	f	502	\N
2009	07:30:00	09:30:00	non attribuer	f	503	\N
2010	09:30:00	11:30:00	non attribuer	f	503	\N
2011	12:00:00	14:00:00	non attribuer	f	503	\N
2012	14:00:00	16:00:00	non attribuer	f	503	\N
2013	07:30:00	09:30:00	non attribuer	f	504	\N
2014	09:30:00	11:30:00	non attribuer	f	504	\N
2015	12:00:00	14:00:00	non attribuer	f	504	\N
2016	14:00:00	16:00:00	non attribuer	f	504	\N
2017	07:30:00	09:30:00	non attribuer	f	505	\N
2018	09:30:00	11:30:00	non attribuer	f	505	\N
2019	12:00:00	14:00:00	non attribuer	f	505	\N
2020	14:00:00	16:00:00	non attribuer	f	505	\N
2021	07:30:00	09:30:00	non attribuer	f	506	\N
2022	09:30:00	11:30:00	non attribuer	f	506	\N
2023	12:00:00	14:00:00	non attribuer	f	506	\N
2024	14:00:00	16:00:00	non attribuer	f	506	\N
2025	07:30:00	09:30:00	non attribuer	f	507	\N
2026	09:30:00	11:30:00	non attribuer	f	507	\N
2027	12:00:00	14:00:00	non attribuer	f	507	\N
2028	14:00:00	16:00:00	non attribuer	f	507	\N
2029	07:30:00	09:30:00	non attribuer	f	508	\N
2030	09:30:00	11:30:00	non attribuer	f	508	\N
2031	12:00:00	14:00:00	non attribuer	f	508	\N
2032	14:00:00	16:00:00	non attribuer	f	508	\N
2033	07:30:00	09:30:00	non attribuer	f	509	\N
2034	09:30:00	11:30:00	non attribuer	f	509	\N
2035	12:00:00	14:00:00	non attribuer	f	509	\N
2036	14:00:00	16:00:00	non attribuer	f	509	\N
2037	07:30:00	09:30:00	non attribuer	f	510	\N
2038	09:30:00	11:30:00	non attribuer	f	510	\N
2039	12:00:00	14:00:00	non attribuer	f	510	\N
2040	14:00:00	16:00:00	non attribuer	f	510	\N
2041	07:30:00	09:30:00	non attribuer	f	511	\N
2042	09:30:00	11:30:00	non attribuer	f	511	\N
2043	12:00:00	14:00:00	non attribuer	f	511	\N
2044	14:00:00	16:00:00	non attribuer	f	511	\N
2045	07:30:00	09:30:00	non attribuer	f	512	\N
2046	09:30:00	11:30:00	non attribuer	f	512	\N
2047	12:00:00	14:00:00	non attribuer	f	512	\N
2048	14:00:00	16:00:00	non attribuer	f	512	\N
2049	07:30:00	09:30:00	non attribuer	f	513	\N
2050	09:30:00	11:30:00	non attribuer	f	513	\N
2051	12:00:00	14:00:00	non attribuer	f	513	\N
2052	14:00:00	16:00:00	non attribuer	f	513	\N
2053	07:30:00	09:30:00	non attribuer	f	514	\N
2054	09:30:00	11:30:00	non attribuer	f	514	\N
2055	12:00:00	14:00:00	non attribuer	f	514	\N
2056	14:00:00	16:00:00	non attribuer	f	514	\N
2057	07:30:00	09:30:00	non attribuer	f	515	\N
2058	09:30:00	11:30:00	non attribuer	f	515	\N
2059	12:00:00	14:00:00	non attribuer	f	515	\N
2060	14:00:00	16:00:00	non attribuer	f	515	\N
2061	07:30:00	09:30:00	non attribuer	f	516	\N
2062	09:30:00	11:30:00	non attribuer	f	516	\N
2063	12:00:00	14:00:00	non attribuer	f	516	\N
2064	14:00:00	16:00:00	non attribuer	f	516	\N
2065	07:30:00	09:30:00	non attribuer	f	517	\N
2066	09:30:00	11:30:00	non attribuer	f	517	\N
2067	12:00:00	14:00:00	non attribuer	f	517	\N
2068	14:00:00	16:00:00	non attribuer	f	517	\N
2069	07:30:00	09:30:00	non attribuer	f	518	\N
2070	09:30:00	11:30:00	non attribuer	f	518	\N
2071	12:00:00	14:00:00	non attribuer	f	518	\N
2072	14:00:00	16:00:00	non attribuer	f	518	\N
2073	07:30:00	09:30:00	non attribuer	f	519	\N
2074	09:30:00	11:30:00	non attribuer	f	519	\N
2075	12:00:00	14:00:00	non attribuer	f	519	\N
2076	14:00:00	16:00:00	non attribuer	f	519	\N
2077	07:30:00	09:30:00	non attribuer	f	520	\N
2078	09:30:00	11:30:00	non attribuer	f	520	\N
2079	12:00:00	14:00:00	non attribuer	f	520	\N
2080	14:00:00	16:00:00	non attribuer	f	520	\N
2081	07:30:00	09:30:00	non attribuer	f	521	\N
2082	09:30:00	11:30:00	non attribuer	f	521	\N
2083	12:00:00	14:00:00	non attribuer	f	521	\N
2084	14:00:00	16:00:00	non attribuer	f	521	\N
2085	07:30:00	09:30:00	non attribuer	f	522	\N
2086	09:30:00	11:30:00	non attribuer	f	522	\N
2087	12:00:00	14:00:00	non attribuer	f	522	\N
2088	14:00:00	16:00:00	non attribuer	f	522	\N
2089	07:30:00	09:30:00	non attribuer	f	523	\N
2090	09:30:00	11:30:00	non attribuer	f	523	\N
2091	12:00:00	14:00:00	non attribuer	f	523	\N
2092	14:00:00	16:00:00	non attribuer	f	523	\N
2093	07:30:00	09:30:00	non attribuer	f	524	\N
2094	09:30:00	11:30:00	non attribuer	f	524	\N
2095	12:00:00	14:00:00	non attribuer	f	524	\N
2096	14:00:00	16:00:00	non attribuer	f	524	\N
2097	07:30:00	09:30:00	non attribuer	f	525	\N
2098	09:30:00	11:30:00	non attribuer	f	525	\N
2099	12:00:00	14:00:00	non attribuer	f	525	\N
2100	14:00:00	16:00:00	non attribuer	f	525	\N
2101	07:30:00	09:30:00	non attribuer	f	526	\N
2102	09:30:00	11:30:00	non attribuer	f	526	\N
2103	12:00:00	14:00:00	non attribuer	f	526	\N
2104	14:00:00	16:00:00	non attribuer	f	526	\N
2105	07:30:00	09:30:00	non attribuer	f	527	\N
2106	09:30:00	11:30:00	non attribuer	f	527	\N
2107	12:00:00	14:00:00	non attribuer	f	527	\N
2108	14:00:00	16:00:00	non attribuer	f	527	\N
2109	07:30:00	09:30:00	non attribuer	f	528	\N
2110	09:30:00	11:30:00	non attribuer	f	528	\N
2111	12:00:00	14:00:00	non attribuer	f	528	\N
2112	14:00:00	16:00:00	non attribuer	f	528	\N
2113	07:30:00	09:30:00	non attribuer	f	529	\N
2114	09:30:00	11:30:00	non attribuer	f	529	\N
2115	12:00:00	14:00:00	non attribuer	f	529	\N
2116	14:00:00	16:00:00	non attribuer	f	529	\N
2117	07:30:00	09:30:00	non attribuer	f	530	\N
2118	09:30:00	11:30:00	non attribuer	f	530	\N
2119	12:00:00	14:00:00	non attribuer	f	530	\N
2120	14:00:00	16:00:00	non attribuer	f	530	\N
2121	07:30:00	09:30:00	non attribuer	f	531	\N
2122	09:30:00	11:30:00	non attribuer	f	531	\N
2123	12:00:00	14:00:00	non attribuer	f	531	\N
2124	14:00:00	16:00:00	non attribuer	f	531	\N
2125	07:30:00	09:30:00	non attribuer	f	532	\N
2126	09:30:00	11:30:00	non attribuer	f	532	\N
2127	12:00:00	14:00:00	non attribuer	f	532	\N
2128	14:00:00	16:00:00	non attribuer	f	532	\N
2129	07:30:00	09:30:00	non attribuer	f	533	\N
2130	09:30:00	11:30:00	non attribuer	f	533	\N
2131	12:00:00	14:00:00	non attribuer	f	533	\N
2132	14:00:00	16:00:00	non attribuer	f	533	\N
2133	07:30:00	09:30:00	non attribuer	f	534	\N
2134	09:30:00	11:30:00	non attribuer	f	534	\N
2135	12:00:00	14:00:00	non attribuer	f	534	\N
2136	14:00:00	16:00:00	non attribuer	f	534	\N
2141	07:30:00	09:30:00	non attribuer	f	536	\N
2142	09:30:00	11:30:00	non attribuer	f	536	\N
2143	12:00:00	14:00:00	non attribuer	f	536	\N
2144	14:00:00	16:00:00	non attribuer	f	536	\N
2145	07:30:00	09:30:00	non attribuer	f	537	\N
2146	09:30:00	11:30:00	non attribuer	f	537	\N
2147	12:00:00	14:00:00	non attribuer	f	537	\N
2148	14:00:00	16:00:00	non attribuer	f	537	\N
2149	07:30:00	09:30:00	non attribuer	f	538	\N
2150	09:30:00	11:30:00	non attribuer	f	538	\N
2151	12:00:00	14:00:00	non attribuer	f	538	\N
2152	14:00:00	16:00:00	non attribuer	f	538	\N
2153	07:30:00	09:30:00	non attribuer	f	539	\N
2154	09:30:00	11:30:00	non attribuer	f	539	\N
2155	12:00:00	14:00:00	non attribuer	f	539	\N
2156	14:00:00	16:00:00	non attribuer	f	539	\N
2157	07:30:00	09:30:00	non attribuer	f	540	\N
2158	09:30:00	11:30:00	non attribuer	f	540	\N
2159	12:00:00	14:00:00	non attribuer	f	540	\N
2160	14:00:00	16:00:00	non attribuer	f	540	\N
2161	07:30:00	09:30:00	non attribuer	f	541	\N
2162	09:30:00	11:30:00	non attribuer	f	541	\N
2163	12:00:00	14:00:00	non attribuer	f	541	\N
2164	14:00:00	16:00:00	non attribuer	f	541	\N
2165	07:30:00	09:30:00	non attribuer	f	542	\N
2166	09:30:00	11:30:00	non attribuer	f	542	\N
2167	12:00:00	14:00:00	non attribuer	f	542	\N
2168	14:00:00	16:00:00	non attribuer	f	542	\N
2169	07:30:00	09:30:00	non attribuer	f	543	\N
2170	09:30:00	11:30:00	non attribuer	f	543	\N
2171	12:00:00	14:00:00	non attribuer	f	543	\N
2172	14:00:00	16:00:00	non attribuer	f	543	\N
2173	07:30:00	09:30:00	non attribuer	f	544	\N
2174	09:30:00	11:30:00	non attribuer	f	544	\N
2175	12:00:00	14:00:00	non attribuer	f	544	\N
2176	14:00:00	16:00:00	non attribuer	f	544	\N
2177	07:30:00	09:30:00	non attribuer	f	545	\N
2178	09:30:00	11:30:00	non attribuer	f	545	\N
2179	12:00:00	14:00:00	non attribuer	f	545	\N
2180	14:00:00	16:00:00	non attribuer	f	545	\N
2181	07:30:00	09:30:00	non attribuer	f	546	\N
2182	09:30:00	11:30:00	non attribuer	f	546	\N
2183	12:00:00	14:00:00	non attribuer	f	546	\N
2184	14:00:00	16:00:00	non attribuer	f	546	\N
2185	07:30:00	09:30:00	non attribuer	f	547	\N
2186	09:30:00	11:30:00	non attribuer	f	547	\N
2187	12:00:00	14:00:00	non attribuer	f	547	\N
2188	14:00:00	16:00:00	non attribuer	f	547	\N
2189	07:30:00	09:30:00	non attribuer	f	548	\N
2190	09:30:00	11:30:00	non attribuer	f	548	\N
2191	12:00:00	14:00:00	non attribuer	f	548	\N
2192	14:00:00	16:00:00	non attribuer	f	548	\N
2193	07:30:00	09:30:00	non attribuer	f	549	\N
2194	09:30:00	11:30:00	non attribuer	f	549	\N
2195	12:00:00	14:00:00	non attribuer	f	549	\N
2196	14:00:00	16:00:00	non attribuer	f	549	\N
2197	07:30:00	09:30:00	non attribuer	f	550	\N
2198	09:30:00	11:30:00	non attribuer	f	550	\N
2199	12:00:00	14:00:00	non attribuer	f	550	\N
2200	14:00:00	16:00:00	non attribuer	f	550	\N
2201	07:30:00	09:30:00	non attribuer	f	551	\N
2202	09:30:00	11:30:00	non attribuer	f	551	\N
2203	12:00:00	14:00:00	non attribuer	f	551	\N
2204	14:00:00	16:00:00	non attribuer	f	551	\N
2205	07:30:00	09:30:00	non attribuer	f	552	\N
2206	09:30:00	11:30:00	non attribuer	f	552	\N
2207	12:00:00	14:00:00	non attribuer	f	552	\N
2208	14:00:00	16:00:00	non attribuer	f	552	\N
2209	07:30:00	09:30:00	non attribuer	f	553	\N
2210	09:30:00	11:30:00	non attribuer	f	553	\N
2211	12:00:00	14:00:00	non attribuer	f	553	\N
2212	14:00:00	16:00:00	non attribuer	f	553	\N
2213	07:30:00	09:30:00	non attribuer	f	554	\N
2214	09:30:00	11:30:00	non attribuer	f	554	\N
2215	12:00:00	14:00:00	non attribuer	f	554	\N
2216	14:00:00	16:00:00	non attribuer	f	554	\N
2217	07:30:00	09:30:00	non attribuer	f	555	\N
2218	09:30:00	11:30:00	non attribuer	f	555	\N
2219	12:00:00	14:00:00	non attribuer	f	555	\N
2220	14:00:00	16:00:00	non attribuer	f	555	\N
2221	07:30:00	09:30:00	non attribuer	f	556	\N
2222	09:30:00	11:30:00	non attribuer	f	556	\N
2223	12:00:00	14:00:00	non attribuer	f	556	\N
2224	14:00:00	16:00:00	non attribuer	f	556	\N
2225	07:30:00	09:30:00	non attribuer	f	557	\N
2226	09:30:00	11:30:00	non attribuer	f	557	\N
2227	12:00:00	14:00:00	non attribuer	f	557	\N
2138	09:30:00	11:30:00	non attribuer	f	535	\N
2139	12:00:00	14:00:00	non attribuer	f	535	\N
2140	14:00:00	16:00:00	non attribuer	f	535	\N
2228	14:00:00	16:00:00	non attribuer	f	557	\N
2229	07:30:00	09:30:00	non attribuer	f	558	\N
2230	09:30:00	11:30:00	non attribuer	f	558	\N
2231	12:00:00	14:00:00	non attribuer	f	558	\N
2232	14:00:00	16:00:00	non attribuer	f	558	\N
2233	07:30:00	09:30:00	non attribuer	f	559	\N
2234	09:30:00	11:30:00	non attribuer	f	559	\N
2235	12:00:00	14:00:00	non attribuer	f	559	\N
2236	14:00:00	16:00:00	non attribuer	f	559	\N
2237	07:30:00	09:30:00	non attribuer	f	560	\N
2238	09:30:00	11:30:00	non attribuer	f	560	\N
2239	12:00:00	14:00:00	non attribuer	f	560	\N
2240	14:00:00	16:00:00	non attribuer	f	560	\N
2241	07:30:00	09:30:00	non attribuer	f	561	\N
2242	09:30:00	11:30:00	non attribuer	f	561	\N
2243	12:00:00	14:00:00	non attribuer	f	561	\N
2244	14:00:00	16:00:00	non attribuer	f	561	\N
2245	07:30:00	09:30:00	non attribuer	f	562	\N
2246	09:30:00	11:30:00	non attribuer	f	562	\N
2247	12:00:00	14:00:00	non attribuer	f	562	\N
2248	14:00:00	16:00:00	non attribuer	f	562	\N
2249	07:30:00	09:30:00	non attribuer	f	563	\N
2250	09:30:00	11:30:00	non attribuer	f	563	\N
2251	12:00:00	14:00:00	non attribuer	f	563	\N
2252	14:00:00	16:00:00	non attribuer	f	563	\N
2253	07:30:00	09:30:00	non attribuer	f	564	\N
2254	09:30:00	11:30:00	non attribuer	f	564	\N
2255	12:00:00	14:00:00	non attribuer	f	564	\N
2256	14:00:00	16:00:00	non attribuer	f	564	\N
2257	07:30:00	09:30:00	non attribuer	f	565	\N
2258	09:30:00	11:30:00	non attribuer	f	565	\N
2259	12:00:00	14:00:00	non attribuer	f	565	\N
2260	14:00:00	16:00:00	non attribuer	f	565	\N
2261	07:30:00	09:30:00	non attribuer	f	566	\N
2262	09:30:00	11:30:00	non attribuer	f	566	\N
2263	12:00:00	14:00:00	non attribuer	f	566	\N
2264	14:00:00	16:00:00	non attribuer	f	566	\N
2265	07:30:00	09:30:00	non attribuer	f	567	\N
2266	09:30:00	11:30:00	non attribuer	f	567	\N
2267	12:00:00	14:00:00	non attribuer	f	567	\N
2268	14:00:00	16:00:00	non attribuer	f	567	\N
2269	07:30:00	09:30:00	non attribuer	f	568	\N
2270	09:30:00	11:30:00	non attribuer	f	568	\N
2271	12:00:00	14:00:00	non attribuer	f	568	\N
2272	14:00:00	16:00:00	non attribuer	f	568	\N
2273	07:30:00	09:30:00	non attribuer	f	569	\N
2274	09:30:00	11:30:00	non attribuer	f	569	\N
2275	12:00:00	14:00:00	non attribuer	f	569	\N
2276	14:00:00	16:00:00	non attribuer	f	569	\N
2277	07:30:00	09:30:00	non attribuer	f	570	\N
2278	09:30:00	11:30:00	non attribuer	f	570	\N
2279	12:00:00	14:00:00	non attribuer	f	570	\N
2280	14:00:00	16:00:00	non attribuer	f	570	\N
2281	07:30:00	09:30:00	non attribuer	f	571	\N
2282	09:30:00	11:30:00	non attribuer	f	571	\N
2283	12:00:00	14:00:00	non attribuer	f	571	\N
2284	14:00:00	16:00:00	non attribuer	f	571	\N
2285	07:30:00	09:30:00	non attribuer	f	572	\N
2286	09:30:00	11:30:00	non attribuer	f	572	\N
2287	12:00:00	14:00:00	non attribuer	f	572	\N
2288	14:00:00	16:00:00	non attribuer	f	572	\N
2289	07:30:00	09:30:00	non attribuer	f	573	\N
2290	09:30:00	11:30:00	non attribuer	f	573	\N
2291	12:00:00	14:00:00	non attribuer	f	573	\N
2292	14:00:00	16:00:00	non attribuer	f	573	\N
2293	07:30:00	09:30:00	non attribuer	f	574	\N
2294	09:30:00	11:30:00	non attribuer	f	574	\N
2295	12:00:00	14:00:00	non attribuer	f	574	\N
2296	14:00:00	16:00:00	non attribuer	f	574	\N
2297	07:30:00	09:30:00	non attribuer	f	575	\N
2298	09:30:00	11:30:00	non attribuer	f	575	\N
2299	12:00:00	14:00:00	non attribuer	f	575	\N
2300	14:00:00	16:00:00	non attribuer	f	575	\N
2301	07:30:00	09:30:00	non attribuer	f	576	\N
2302	09:30:00	11:30:00	non attribuer	f	576	\N
2303	12:00:00	14:00:00	non attribuer	f	576	\N
2304	14:00:00	16:00:00	non attribuer	f	576	\N
2305	07:30:00	09:30:00	non attribuer	f	577	\N
2306	09:30:00	11:30:00	non attribuer	f	577	\N
2307	12:00:00	14:00:00	non attribuer	f	577	\N
2308	14:00:00	16:00:00	non attribuer	f	577	\N
2309	07:30:00	09:30:00	non attribuer	f	578	\N
2310	09:30:00	11:30:00	non attribuer	f	578	\N
2311	12:00:00	14:00:00	non attribuer	f	578	\N
2312	14:00:00	16:00:00	non attribuer	f	578	\N
2313	07:30:00	09:30:00	non attribuer	f	579	\N
2314	09:30:00	11:30:00	non attribuer	f	579	\N
2315	12:00:00	14:00:00	non attribuer	f	579	\N
2316	14:00:00	16:00:00	non attribuer	f	579	\N
2317	07:30:00	09:30:00	non attribuer	f	580	\N
2318	09:30:00	11:30:00	non attribuer	f	580	\N
2319	12:00:00	14:00:00	non attribuer	f	580	\N
2320	14:00:00	16:00:00	non attribuer	f	580	\N
2321	07:30:00	09:30:00	non attribuer	f	581	\N
2322	09:30:00	11:30:00	non attribuer	f	581	\N
2323	12:00:00	14:00:00	non attribuer	f	581	\N
2324	14:00:00	16:00:00	non attribuer	f	581	\N
2325	07:30:00	09:30:00	non attribuer	f	582	\N
2326	09:30:00	11:30:00	non attribuer	f	582	\N
2327	12:00:00	14:00:00	non attribuer	f	582	\N
2328	14:00:00	16:00:00	non attribuer	f	582	\N
2329	07:30:00	09:30:00	non attribuer	f	583	\N
2330	09:30:00	11:30:00	non attribuer	f	583	\N
2331	12:00:00	14:00:00	non attribuer	f	583	\N
2332	14:00:00	16:00:00	non attribuer	f	583	\N
2333	07:30:00	09:30:00	non attribuer	f	584	\N
2334	09:30:00	11:30:00	non attribuer	f	584	\N
2335	12:00:00	14:00:00	non attribuer	f	584	\N
2336	14:00:00	16:00:00	non attribuer	f	584	\N
2337	07:30:00	09:30:00	non attribuer	f	585	\N
2338	09:30:00	11:30:00	non attribuer	f	585	\N
2339	12:00:00	14:00:00	non attribuer	f	585	\N
2340	14:00:00	16:00:00	non attribuer	f	585	\N
2341	07:30:00	09:30:00	non attribuer	f	586	\N
2342	09:30:00	11:30:00	non attribuer	f	586	\N
2343	12:00:00	14:00:00	non attribuer	f	586	\N
2344	14:00:00	16:00:00	non attribuer	f	586	\N
2345	07:30:00	09:30:00	non attribuer	f	587	\N
2346	09:30:00	11:30:00	non attribuer	f	587	\N
2347	12:00:00	14:00:00	non attribuer	f	587	\N
2348	14:00:00	16:00:00	non attribuer	f	587	\N
2349	07:30:00	09:30:00	non attribuer	f	588	\N
2350	09:30:00	11:30:00	non attribuer	f	588	\N
2351	12:00:00	14:00:00	non attribuer	f	588	\N
2352	14:00:00	16:00:00	non attribuer	f	588	\N
2137	07:30:00	09:30:00	non attribuer	f	535	\N
\.


--
-- Data for Name: planning_doubleheure_matieres; Type: TABLE DATA; Schema: public; Owner: leprince
--

COPY public.planning_doubleheure_matieres (id, doubleheure_id, matiere_id) FROM stdin;
23	1681	3
24	1682	3
25	1683	3
26	1684	3
27	2137	4
28	2138	4
29	2139	4
30	2140	4
\.


--
-- Data for Name: planning_etudiant; Type: TABLE DATA; Schema: public; Owner: leprince
--

COPY public.planning_etudiant (personne_ptr_id, option_id) FROM stdin;
9	1
\.


--
-- Data for Name: planning_filiere; Type: TABLE DATA; Schema: public; Owner: leprince
--

COPY public.planning_filiere (id, libelle, description, nbre_etudiant, niveau, departement_id, responsable_niveau_id) FROM stdin;
1	genie informatique 1	niveau 1 tronc commun genie info	120	1	1	8
2	genie informatique 2	niveau deux ayant genie logiciel et isr	110	2	1	7
\.


--
-- Data for Name: planning_jour; Type: TABLE DATA; Schema: public; Owner: leprince
--

COPY public.planning_jour (id, libelle, date_jour, jour_ferier, planning_id) FROM stdin;
373	lundi	2021-03-22	f	63
374	mardi	2021-03-23	f	63
375	mercredi	2021-03-24	f	63
376	jeudi	2021-03-25	f	63
377	vendredi	2021-03-26	f	63
378	samedi	2021-03-27	f	63
379	lundi	2021-03-29	f	64
380	mardi	2021-03-30	f	64
381	mercredi	2021-03-31	f	64
382	jeudi	2021-04-01	f	64
383	vendredi	2021-04-02	f	64
384	samedi	2021-04-03	f	64
385	lundi	2021-04-05	f	65
386	mardi	2021-04-06	f	65
387	mercredi	2021-04-07	f	65
388	jeudi	2021-04-08	f	65
389	vendredi	2021-04-09	f	65
390	samedi	2021-04-10	f	65
391	lundi	2021-04-12	f	66
392	mardi	2021-04-13	f	66
393	mercredi	2021-04-14	f	66
394	jeudi	2021-04-15	f	66
395	vendredi	2021-04-16	f	66
396	samedi	2021-04-17	f	66
397	lundi	2021-04-19	f	67
398	mardi	2021-04-20	f	67
399	mercredi	2021-04-21	f	67
400	jeudi	2021-04-22	f	67
401	vendredi	2021-04-23	f	67
402	samedi	2021-04-24	f	67
403	lundi	2021-04-26	f	68
404	mardi	2021-04-27	f	68
405	mercredi	2021-04-28	f	68
406	jeudi	2021-04-29	f	68
407	vendredi	2021-04-30	f	68
408	samedi	2021-05-01	f	68
409	lundi	2021-05-03	f	69
410	mardi	2021-05-04	f	69
411	mercredi	2021-05-05	f	69
412	jeudi	2021-05-06	f	69
413	vendredi	2021-05-07	f	69
414	samedi	2021-05-08	f	69
415	lundi	2021-05-10	f	70
416	mardi	2021-05-11	f	70
417	mercredi	2021-05-12	f	70
418	jeudi	2021-05-13	f	70
419	vendredi	2021-05-14	f	70
420	samedi	2021-05-15	f	70
421	lundi	2021-05-17	f	71
422	mardi	2021-05-18	f	71
423	mercredi	2021-05-19	f	71
424	jeudi	2021-05-20	f	71
425	vendredi	2021-05-21	f	71
426	samedi	2021-05-22	f	71
427	lundi	2021-05-24	f	72
428	mardi	2021-05-25	f	72
429	mercredi	2021-05-26	f	72
430	jeudi	2021-05-27	f	72
431	vendredi	2021-05-28	f	72
432	samedi	2021-05-29	f	72
433	lundi	2021-05-31	f	73
434	mardi	2021-06-01	f	73
435	mercredi	2021-06-02	f	73
436	jeudi	2021-06-03	f	73
437	vendredi	2021-06-04	f	73
438	samedi	2021-06-05	f	73
439	lundi	2021-06-07	f	74
440	mardi	2021-06-08	f	74
441	mercredi	2021-06-09	f	74
442	jeudi	2021-06-10	f	74
443	vendredi	2021-06-11	f	74
444	samedi	2021-06-12	f	74
445	lundi	2021-06-14	f	75
446	mardi	2021-06-15	f	75
447	mercredi	2021-06-16	f	75
448	jeudi	2021-06-17	f	75
449	vendredi	2021-06-18	f	75
450	samedi	2021-06-19	f	75
451	lundi	2021-06-21	f	76
452	mardi	2021-06-22	f	76
453	mercredi	2021-06-23	f	76
454	jeudi	2021-06-24	f	76
455	vendredi	2021-06-25	f	76
456	samedi	2021-06-26	f	76
457	lundi	2021-06-28	f	77
458	mardi	2021-06-29	f	77
459	mercredi	2021-06-30	f	77
460	jeudi	2021-07-01	f	77
461	vendredi	2021-07-02	f	77
462	samedi	2021-07-03	f	77
463	lundi	2021-07-05	f	78
464	mardi	2021-07-06	f	78
465	mercredi	2021-07-07	f	78
466	jeudi	2021-07-08	f	78
467	vendredi	2021-07-09	f	78
468	samedi	2021-07-10	f	78
469	lundi	2021-07-12	f	79
470	mardi	2021-07-13	f	79
471	mercredi	2021-07-14	f	79
472	jeudi	2021-07-15	f	79
473	vendredi	2021-07-16	f	79
474	samedi	2021-07-17	f	79
475	lundi	2021-07-19	f	80
476	mardi	2021-07-20	f	80
477	mercredi	2021-07-21	f	80
478	jeudi	2021-07-22	f	80
479	vendredi	2021-07-23	f	80
480	samedi	2021-07-24	f	80
481	lundi	2021-03-22	f	81
482	mardi	2021-03-23	f	81
483	mercredi	2021-03-24	f	81
484	jeudi	2021-03-25	f	81
485	vendredi	2021-03-26	f	81
486	samedi	2021-03-27	f	81
487	lundi	2021-03-29	f	82
488	mardi	2021-03-30	f	82
489	mercredi	2021-03-31	f	82
490	jeudi	2021-04-01	f	82
491	vendredi	2021-04-02	f	82
492	samedi	2021-04-03	f	82
493	lundi	2021-04-05	f	83
494	mardi	2021-04-06	f	83
495	mercredi	2021-04-07	f	83
496	jeudi	2021-04-08	f	83
497	vendredi	2021-04-09	f	83
498	samedi	2021-04-10	f	83
499	lundi	2021-04-12	f	84
500	mardi	2021-04-13	f	84
501	mercredi	2021-04-14	f	84
502	jeudi	2021-04-15	f	84
503	vendredi	2021-04-16	f	84
504	samedi	2021-04-17	f	84
505	lundi	2021-04-19	f	85
506	mardi	2021-04-20	f	85
507	mercredi	2021-04-21	f	85
508	jeudi	2021-04-22	f	85
509	vendredi	2021-04-23	f	85
510	samedi	2021-04-24	f	85
511	lundi	2021-04-26	f	86
512	mardi	2021-04-27	f	86
513	mercredi	2021-04-28	f	86
514	jeudi	2021-04-29	f	86
515	vendredi	2021-04-30	f	86
516	samedi	2021-05-01	f	86
517	lundi	2021-05-03	f	87
518	mardi	2021-05-04	f	87
519	mercredi	2021-05-05	f	87
520	jeudi	2021-05-06	f	87
521	vendredi	2021-05-07	f	87
522	samedi	2021-05-08	f	87
523	lundi	2021-05-10	f	88
524	mardi	2021-05-11	f	88
525	mercredi	2021-05-12	f	88
526	jeudi	2021-05-13	f	88
527	vendredi	2021-05-14	f	88
528	samedi	2021-05-15	f	88
529	lundi	2021-05-17	f	89
530	mardi	2021-05-18	f	89
531	mercredi	2021-05-19	f	89
532	jeudi	2021-05-20	f	89
533	vendredi	2021-05-21	f	89
534	samedi	2021-05-22	f	89
535	lundi	2021-05-24	f	90
536	mardi	2021-05-25	f	90
537	mercredi	2021-05-26	f	90
538	jeudi	2021-05-27	f	90
539	vendredi	2021-05-28	f	90
540	samedi	2021-05-29	f	90
541	lundi	2021-05-31	f	91
542	mardi	2021-06-01	f	91
543	mercredi	2021-06-02	f	91
544	jeudi	2021-06-03	f	91
545	vendredi	2021-06-04	f	91
546	samedi	2021-06-05	f	91
547	lundi	2021-06-07	f	92
548	mardi	2021-06-08	f	92
549	mercredi	2021-06-09	f	92
550	jeudi	2021-06-10	f	92
551	vendredi	2021-06-11	f	92
552	samedi	2021-06-12	f	92
553	lundi	2021-06-14	f	93
554	mardi	2021-06-15	f	93
555	mercredi	2021-06-16	f	93
556	jeudi	2021-06-17	f	93
557	vendredi	2021-06-18	f	93
558	samedi	2021-06-19	f	93
559	lundi	2021-06-21	f	94
560	mardi	2021-06-22	f	94
561	mercredi	2021-06-23	f	94
562	jeudi	2021-06-24	f	94
563	vendredi	2021-06-25	f	94
564	samedi	2021-06-26	f	94
565	lundi	2021-06-28	f	95
566	mardi	2021-06-29	f	95
567	mercredi	2021-06-30	f	95
568	jeudi	2021-07-01	f	95
569	vendredi	2021-07-02	f	95
570	samedi	2021-07-03	f	95
571	lundi	2021-07-05	f	96
572	mardi	2021-07-06	f	96
573	mercredi	2021-07-07	f	96
574	jeudi	2021-07-08	f	96
575	vendredi	2021-07-09	f	96
576	samedi	2021-07-10	f	96
577	lundi	2021-07-12	f	97
578	mardi	2021-07-13	f	97
579	mercredi	2021-07-14	f	97
580	jeudi	2021-07-15	f	97
581	vendredi	2021-07-16	f	97
582	samedi	2021-07-17	f	97
583	lundi	2021-07-19	f	98
584	mardi	2021-07-20	f	98
585	mercredi	2021-07-21	f	98
586	jeudi	2021-07-22	f	98
587	vendredi	2021-07-23	f	98
588	samedi	2021-07-24	f	98
\.


--
-- Data for Name: planning_matiere; Type: TABLE DATA; Schema: public; Owner: leprince
--

COPY public.planning_matiere (id, libelle, code, credit, heure_magistral, heure_tpe, heure_td, total_heure, module_id, heure_tp, option_id, professeur_id) FROM stdin;
3	base de donnee	bd865	3	30	0	15	45	2	0	1	7
2	Cryptographie	CRY3152	2	20	10	10	30	2	0	1	4
1	Analyse Fontionnelle	ANF3151	3	30	15	15	45	2	0	1	4
4	Anglais Techique	ANT1021	2	30	0	15	45	3	0	2	7
5	linux et programmation  systeme	LINX	4	30	0	0	45	2	0	2	8
6	tse	tse	3	30	0	0	45	3	0	1	8
\.


--
-- Data for Name: planning_module; Type: TABLE DATA; Schema: public; Owner: leprince
--

COPY public.planning_module (id, libelle, code, type_module, nbre_credit, nbre_heure, tpe, numero_semestre, departement_id) FROM stdin;
2	Mathematique et Cryptographie	CDR315	Fondamentale	5	75	25	5	1
3	LANGUE	LANG	Obligation	5	30	0	1	1
\.


--
-- Data for Name: planning_parent; Type: TABLE DATA; Schema: public; Owner: leprince
--

COPY public.planning_parent (personne_ptr_id) FROM stdin;
\.


--
-- Data for Name: planning_parent_enfants; Type: TABLE DATA; Schema: public; Owner: leprince
--

COPY public.planning_parent_enfants (id, parent_id, etudiant_id) FROM stdin;
\.


--
-- Data for Name: planning_personne; Type: TABLE DATA; Schema: public; Owner: leprince
--

COPY public.planning_personne (user_ptr_id, telephone) FROM stdin;
4	678576986
5	695824454
6	695824455
9	695824453
7	695824456
8	695824457
10	695824458
\.


--
-- Data for Name: planning_planningsemaine; Type: TABLE DATA; Schema: public; Owner: leprince
--

COPY public.planning_planningsemaine (id, date_debut, date_fin, numero, etat, classe_id, responsable_niveau_id, semestre_id) FROM stdin;
63	2021-03-22	2021-03-27	1	non valider	1	7	12
64	2021-03-29	2021-04-03	2	non valider	1	7	12
65	2021-04-05	2021-04-10	3	non valider	1	7	12
66	2021-04-12	2021-04-17	4	non valider	1	7	12
67	2021-04-19	2021-04-24	5	non valider	1	7	12
68	2021-04-26	2021-05-01	6	non valider	1	7	12
69	2021-05-03	2021-05-08	7	non valider	1	7	12
70	2021-05-10	2021-05-15	8	non valider	1	7	12
71	2021-05-17	2021-05-22	9	non valider	1	7	12
72	2021-05-24	2021-05-29	10	non valider	1	7	12
73	2021-05-31	2021-06-05	11	non valider	1	7	12
74	2021-06-07	2021-06-12	12	non valider	1	7	12
75	2021-06-14	2021-06-19	13	non valider	1	7	12
76	2021-06-21	2021-06-26	14	non valider	1	7	12
77	2021-06-28	2021-07-03	15	non valider	1	7	12
78	2021-07-05	2021-07-10	16	non valider	1	7	12
79	2021-07-12	2021-07-17	17	non valider	1	7	12
80	2021-07-19	2021-07-24	18	non valider	1	7	12
81	2021-03-22	2021-03-27	1	non valider	2	8	13
82	2021-03-29	2021-04-03	2	non valider	2	8	13
83	2021-04-05	2021-04-10	3	non valider	2	8	13
84	2021-04-12	2021-04-17	4	non valider	2	8	13
85	2021-04-19	2021-04-24	5	non valider	2	8	13
86	2021-04-26	2021-05-01	6	non valider	2	8	13
87	2021-05-03	2021-05-08	7	non valider	2	8	13
88	2021-05-10	2021-05-15	8	non valider	2	8	13
89	2021-05-17	2021-05-22	9	non valider	2	8	13
90	2021-05-24	2021-05-29	10	non valider	2	8	13
91	2021-05-31	2021-06-05	11	non valider	2	8	13
92	2021-06-07	2021-06-12	12	non valider	2	8	13
93	2021-06-14	2021-06-19	13	non valider	2	8	13
94	2021-06-21	2021-06-26	14	non valider	2	8	13
95	2021-06-28	2021-07-03	15	non valider	2	8	13
96	2021-07-05	2021-07-10	16	non valider	2	8	13
97	2021-07-12	2021-07-17	17	non valider	2	8	13
98	2021-07-19	2021-07-24	18	non valider	2	8	13
\.


--
-- Data for Name: planning_professeur; Type: TABLE DATA; Schema: public; Owner: leprince
--

COPY public.planning_professeur (personne_ptr_id, titre) FROM stdin;
4	M.
5	Prof.
7	Dr.
8	Dr.
\.


--
-- Data for Name: planning_responsableniveau; Type: TABLE DATA; Schema: public; Owner: leprince
--

COPY public.planning_responsableniveau (professeur_ptr_id) FROM stdin;
7
8
\.


--
-- Data for Name: planning_ressource; Type: TABLE DATA; Schema: public; Owner: leprince
--

COPY public.planning_ressource (id, libelle, description, etat, "typeR", classe_id, departement_id) FROM stdin;
\.


--
-- Data for Name: planning_semestre; Type: TABLE DATA; Schema: public; Owner: leprince
--

COPY public.planning_semestre (id, numero, lmd, date_debut, date_fin, annee_id) FROM stdin;
12	4	6	2021-03-22	2021-07-31	2
13	2	3	2021-03-22	2021-07-31	2
\.


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leprince
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 6, true);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leprince
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 124, true);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leprince
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 96, true);


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leprince
--

SELECT pg_catalog.setval('public.auth_user_groups_id_seq', 11, true);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leprince
--

SELECT pg_catalog.setval('public.auth_user_id_seq', 10, true);


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leprince
--

SELECT pg_catalog.setval('public.auth_user_user_permissions_id_seq', 1, false);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leprince
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 69, true);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leprince
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 24, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leprince
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 26, true);


--
-- Name: planning_anneeacademique_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leprince
--

SELECT pg_catalog.setval('public.planning_anneeacademique_id_seq', 3, true);


--
-- Name: planning_classe_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leprince
--

SELECT pg_catalog.setval('public.planning_classe_id_seq', 2, true);


--
-- Name: planning_departement_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leprince
--

SELECT pg_catalog.setval('public.planning_departement_id_seq', 1, true);


--
-- Name: planning_departement_professeurs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leprince
--

SELECT pg_catalog.setval('public.planning_departement_professeurs_id_seq', 4, true);


--
-- Name: planning_doubleheure_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leprince
--

SELECT pg_catalog.setval('public.planning_doubleheure_id_seq', 2352, true);


--
-- Name: planning_doubleheure_matieres_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leprince
--

SELECT pg_catalog.setval('public.planning_doubleheure_matieres_id_seq', 30, true);


--
-- Name: planning_filiere_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leprince
--

SELECT pg_catalog.setval('public.planning_filiere_id_seq', 2, true);


--
-- Name: planning_jour_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leprince
--

SELECT pg_catalog.setval('public.planning_jour_id_seq', 588, true);


--
-- Name: planning_matiere_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leprince
--

SELECT pg_catalog.setval('public.planning_matiere_id_seq', 6, true);


--
-- Name: planning_module_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leprince
--

SELECT pg_catalog.setval('public.planning_module_id_seq', 3, true);


--
-- Name: planning_parent_enfants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leprince
--

SELECT pg_catalog.setval('public.planning_parent_enfants_id_seq', 1, false);


--
-- Name: planning_planningsemaine_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leprince
--

SELECT pg_catalog.setval('public.planning_planningsemaine_id_seq', 98, true);


--
-- Name: planning_ressource_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leprince
--

SELECT pg_catalog.setval('public.planning_ressource_id_seq', 1, false);


--
-- Name: planning_semestre_id_seq; Type: SEQUENCE SET; Schema: public; Owner: leprince
--

SELECT pg_catalog.setval('public.planning_semestre_id_seq', 13, true);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_user_id_group_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- Name: auth_user auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_permission_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- Name: auth_user auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: planning_anneeacademique planning_anneeacademique_libelle_key; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_anneeacademique
    ADD CONSTRAINT planning_anneeacademique_libelle_key UNIQUE (libelle);


--
-- Name: planning_anneeacademique planning_anneeacademique_pkey; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_anneeacademique
    ADD CONSTRAINT planning_anneeacademique_pkey PRIMARY KEY (id);


--
-- Name: planning_chefdepartement planning_chefdepartement_pkey; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_chefdepartement
    ADD CONSTRAINT planning_chefdepartement_pkey PRIMARY KEY (professeur_ptr_id);


--
-- Name: planning_classe planning_classe_pkey; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_classe
    ADD CONSTRAINT planning_classe_pkey PRIMARY KEY (id);


--
-- Name: planning_delegue planning_delegue_pkey; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_delegue
    ADD CONSTRAINT planning_delegue_pkey PRIMARY KEY (personne_ptr_id);


--
-- Name: planning_departement planning_departement_libelle_key; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_departement
    ADD CONSTRAINT planning_departement_libelle_key UNIQUE (libelle);


--
-- Name: planning_departement planning_departement_pkey; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_departement
    ADD CONSTRAINT planning_departement_pkey PRIMARY KEY (id);


--
-- Name: planning_departement_professeurs planning_departement_pro_departement_id_professeu_847fae9f_uniq; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_departement_professeurs
    ADD CONSTRAINT planning_departement_pro_departement_id_professeu_847fae9f_uniq UNIQUE (departement_id, professeur_id);


--
-- Name: planning_departement_professeurs planning_departement_professeurs_pkey; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_departement_professeurs
    ADD CONSTRAINT planning_departement_professeurs_pkey PRIMARY KEY (id);


--
-- Name: planning_doubleheure_matieres planning_doubleheure_mat_doubleheure_id_matiere_i_ae7130cf_uniq; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_doubleheure_matieres
    ADD CONSTRAINT planning_doubleheure_mat_doubleheure_id_matiere_i_ae7130cf_uniq UNIQUE (doubleheure_id, matiere_id);


--
-- Name: planning_doubleheure_matieres planning_doubleheure_matieres_pkey; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_doubleheure_matieres
    ADD CONSTRAINT planning_doubleheure_matieres_pkey PRIMARY KEY (id);


--
-- Name: planning_doubleheure planning_doubleheure_pkey; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_doubleheure
    ADD CONSTRAINT planning_doubleheure_pkey PRIMARY KEY (id);


--
-- Name: planning_etudiant planning_etudiant_pkey; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_etudiant
    ADD CONSTRAINT planning_etudiant_pkey PRIMARY KEY (personne_ptr_id);


--
-- Name: planning_filiere planning_filiere_libelle_key; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_filiere
    ADD CONSTRAINT planning_filiere_libelle_key UNIQUE (libelle);


--
-- Name: planning_filiere planning_filiere_pkey; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_filiere
    ADD CONSTRAINT planning_filiere_pkey PRIMARY KEY (id);


--
-- Name: planning_jour planning_jour_pkey; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_jour
    ADD CONSTRAINT planning_jour_pkey PRIMARY KEY (id);


--
-- Name: planning_matiere planning_matiere_code_key; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_matiere
    ADD CONSTRAINT planning_matiere_code_key UNIQUE (code);


--
-- Name: planning_matiere planning_matiere_pkey; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_matiere
    ADD CONSTRAINT planning_matiere_pkey PRIMARY KEY (id);


--
-- Name: planning_module planning_module_code_key; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_module
    ADD CONSTRAINT planning_module_code_key UNIQUE (code);


--
-- Name: planning_module planning_module_pkey; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_module
    ADD CONSTRAINT planning_module_pkey PRIMARY KEY (id);


--
-- Name: planning_parent_enfants planning_parent_enfants_parent_id_etudiant_id_6b1cc2bd_uniq; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_parent_enfants
    ADD CONSTRAINT planning_parent_enfants_parent_id_etudiant_id_6b1cc2bd_uniq UNIQUE (parent_id, etudiant_id);


--
-- Name: planning_parent_enfants planning_parent_enfants_pkey; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_parent_enfants
    ADD CONSTRAINT planning_parent_enfants_pkey PRIMARY KEY (id);


--
-- Name: planning_parent planning_parent_pkey; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_parent
    ADD CONSTRAINT planning_parent_pkey PRIMARY KEY (personne_ptr_id);


--
-- Name: planning_personne planning_personne_pkey; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_personne
    ADD CONSTRAINT planning_personne_pkey PRIMARY KEY (user_ptr_id);


--
-- Name: planning_personne planning_personne_telephone_key; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_personne
    ADD CONSTRAINT planning_personne_telephone_key UNIQUE (telephone);


--
-- Name: planning_planningsemaine planning_planningsemaine_pkey; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_planningsemaine
    ADD CONSTRAINT planning_planningsemaine_pkey PRIMARY KEY (id);


--
-- Name: planning_professeur planning_professeur_pkey; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_professeur
    ADD CONSTRAINT planning_professeur_pkey PRIMARY KEY (personne_ptr_id);


--
-- Name: planning_responsableniveau planning_responsableniveau_pkey; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_responsableniveau
    ADD CONSTRAINT planning_responsableniveau_pkey PRIMARY KEY (professeur_ptr_id);


--
-- Name: planning_ressource planning_ressource_pkey; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_ressource
    ADD CONSTRAINT planning_ressource_pkey PRIMARY KEY (id);


--
-- Name: planning_semestre planning_semestre_pkey; Type: CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_semestre
    ADD CONSTRAINT planning_semestre_pkey PRIMARY KEY (id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id_97559544; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX auth_user_groups_group_id_97559544 ON public.auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id_6a12ed8b; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX auth_user_groups_user_id_6a12ed8b ON public.auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id_1fbb5f2c; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX auth_user_user_permissions_permission_id_1fbb5f2c ON public.auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id_a95ead1b; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX auth_user_user_permissions_user_id_a95ead1b ON public.auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX auth_user_username_6821ab7c_like ON public.auth_user USING btree (username varchar_pattern_ops);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: planning_anneeacademique_libelle_e9bcd2bd_like; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX planning_anneeacademique_libelle_e9bcd2bd_like ON public.planning_anneeacademique USING btree (libelle varchar_pattern_ops);


--
-- Name: planning_classe_delegue_id_7455514f; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX planning_classe_delegue_id_7455514f ON public.planning_classe USING btree (delegue_id);


--
-- Name: planning_classe_filiere_id_5f251896; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX planning_classe_filiere_id_5f251896 ON public.planning_classe USING btree (filiere_id);


--
-- Name: planning_departement_chef_departement_id_80e922c6; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX planning_departement_chef_departement_id_80e922c6 ON public.planning_departement USING btree (chef_departement_id);


--
-- Name: planning_departement_libelle_067ac80a_like; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX planning_departement_libelle_067ac80a_like ON public.planning_departement USING btree (libelle varchar_pattern_ops);


--
-- Name: planning_departement_professeurs_departement_id_32484ba2; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX planning_departement_professeurs_departement_id_32484ba2 ON public.planning_departement_professeurs USING btree (departement_id);


--
-- Name: planning_departement_professeurs_professeur_id_34ad4957; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX planning_departement_professeurs_professeur_id_34ad4957 ON public.planning_departement_professeurs USING btree (professeur_id);


--
-- Name: planning_doubleheure_jour_id_8e674038; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX planning_doubleheure_jour_id_8e674038 ON public.planning_doubleheure USING btree (jour_id);


--
-- Name: planning_doubleheure_matiere_id_b74c818a; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX planning_doubleheure_matiere_id_b74c818a ON public.planning_doubleheure USING btree (matiere_id);


--
-- Name: planning_doubleheure_matieres_doubleheure_id_858a226e; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX planning_doubleheure_matieres_doubleheure_id_858a226e ON public.planning_doubleheure_matieres USING btree (doubleheure_id);


--
-- Name: planning_doubleheure_matieres_matiere_id_6b0cff3d; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX planning_doubleheure_matieres_matiere_id_6b0cff3d ON public.planning_doubleheure_matieres USING btree (matiere_id);


--
-- Name: planning_etudiant_option_id_9f2eb588; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX planning_etudiant_option_id_9f2eb588 ON public.planning_etudiant USING btree (option_id);


--
-- Name: planning_filiere_departement_id_15822774; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX planning_filiere_departement_id_15822774 ON public.planning_filiere USING btree (departement_id);


--
-- Name: planning_filiere_libelle_4c950940_like; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX planning_filiere_libelle_4c950940_like ON public.planning_filiere USING btree (libelle varchar_pattern_ops);


--
-- Name: planning_filiere_responsable_niveau_id_c4ad04c4; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX planning_filiere_responsable_niveau_id_c4ad04c4 ON public.planning_filiere USING btree (responsable_niveau_id);


--
-- Name: planning_jour_planning_id_8656a5b7; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX planning_jour_planning_id_8656a5b7 ON public.planning_jour USING btree (planning_id);


--
-- Name: planning_matiere_code_9da717a2_like; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX planning_matiere_code_9da717a2_like ON public.planning_matiere USING btree (code varchar_pattern_ops);


--
-- Name: planning_matiere_module_id_99d07074; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX planning_matiere_module_id_99d07074 ON public.planning_matiere USING btree (module_id);


--
-- Name: planning_matiere_option_id_80d0e787; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX planning_matiere_option_id_80d0e787 ON public.planning_matiere USING btree (option_id);


--
-- Name: planning_matiere_professeur_id_69f9a1ba; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX planning_matiere_professeur_id_69f9a1ba ON public.planning_matiere USING btree (professeur_id);


--
-- Name: planning_module_code_7cbec394_like; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX planning_module_code_7cbec394_like ON public.planning_module USING btree (code varchar_pattern_ops);


--
-- Name: planning_module_departement_id_5d37c084; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX planning_module_departement_id_5d37c084 ON public.planning_module USING btree (departement_id);


--
-- Name: planning_parent_enfants_etudiant_id_fc7a14b6; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX planning_parent_enfants_etudiant_id_fc7a14b6 ON public.planning_parent_enfants USING btree (etudiant_id);


--
-- Name: planning_parent_enfants_parent_id_4a7b63a8; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX planning_parent_enfants_parent_id_4a7b63a8 ON public.planning_parent_enfants USING btree (parent_id);


--
-- Name: planning_personne_telephone_36d1aa43_like; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX planning_personne_telephone_36d1aa43_like ON public.planning_personne USING btree (telephone varchar_pattern_ops);


--
-- Name: planning_planningsemaine_classe_id_72eca369; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX planning_planningsemaine_classe_id_72eca369 ON public.planning_planningsemaine USING btree (classe_id);


--
-- Name: planning_planningsemaine_responsable_niveau_id_8c2e6980; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX planning_planningsemaine_responsable_niveau_id_8c2e6980 ON public.planning_planningsemaine USING btree (responsable_niveau_id);


--
-- Name: planning_planningsemaine_semestre_id_fb399a52; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX planning_planningsemaine_semestre_id_fb399a52 ON public.planning_planningsemaine USING btree (semestre_id);


--
-- Name: planning_ressource_classe_id_aa387e50; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX planning_ressource_classe_id_aa387e50 ON public.planning_ressource USING btree (classe_id);


--
-- Name: planning_ressource_departement_id_f564f50a; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX planning_ressource_departement_id_f564f50a ON public.planning_ressource USING btree (departement_id);


--
-- Name: planning_semestre_annee_id_aa508d9a; Type: INDEX; Schema: public; Owner: leprince
--

CREATE INDEX planning_semestre_annee_id_aa508d9a ON public.planning_semestre USING btree (annee_id);


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: planning_chefdepartement planning_chefdeparte_professeur_ptr_id_a7af60f5_fk_planning_; Type: FK CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_chefdepartement
    ADD CONSTRAINT planning_chefdeparte_professeur_ptr_id_a7af60f5_fk_planning_ FOREIGN KEY (professeur_ptr_id) REFERENCES public.planning_professeur(personne_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: planning_classe planning_classe_delegue_id_7455514f_fk_planning_; Type: FK CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_classe
    ADD CONSTRAINT planning_classe_delegue_id_7455514f_fk_planning_ FOREIGN KEY (delegue_id) REFERENCES public.planning_delegue(personne_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: planning_classe planning_classe_filiere_id_5f251896_fk_planning_filiere_id; Type: FK CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_classe
    ADD CONSTRAINT planning_classe_filiere_id_5f251896_fk_planning_filiere_id FOREIGN KEY (filiere_id) REFERENCES public.planning_filiere(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: planning_delegue planning_delegue_personne_ptr_id_9064d40e_fk_planning_; Type: FK CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_delegue
    ADD CONSTRAINT planning_delegue_personne_ptr_id_9064d40e_fk_planning_ FOREIGN KEY (personne_ptr_id) REFERENCES public.planning_personne(user_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: planning_departement planning_departement_chef_departement_id_80e922c6_fk_planning_; Type: FK CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_departement
    ADD CONSTRAINT planning_departement_chef_departement_id_80e922c6_fk_planning_ FOREIGN KEY (chef_departement_id) REFERENCES public.planning_chefdepartement(professeur_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: planning_departement_professeurs planning_departement_departement_id_32484ba2_fk_planning_; Type: FK CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_departement_professeurs
    ADD CONSTRAINT planning_departement_departement_id_32484ba2_fk_planning_ FOREIGN KEY (departement_id) REFERENCES public.planning_departement(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: planning_departement_professeurs planning_departement_professeur_id_34ad4957_fk_planning_; Type: FK CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_departement_professeurs
    ADD CONSTRAINT planning_departement_professeur_id_34ad4957_fk_planning_ FOREIGN KEY (professeur_id) REFERENCES public.planning_professeur(personne_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: planning_doubleheure_matieres planning_doubleheure_doubleheure_id_858a226e_fk_planning_; Type: FK CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_doubleheure_matieres
    ADD CONSTRAINT planning_doubleheure_doubleheure_id_858a226e_fk_planning_ FOREIGN KEY (doubleheure_id) REFERENCES public.planning_doubleheure(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: planning_doubleheure planning_doubleheure_jour_id_8e674038_fk_planning_jour_id; Type: FK CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_doubleheure
    ADD CONSTRAINT planning_doubleheure_jour_id_8e674038_fk_planning_jour_id FOREIGN KEY (jour_id) REFERENCES public.planning_jour(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: planning_doubleheure_matieres planning_doubleheure_matiere_id_6b0cff3d_fk_planning_; Type: FK CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_doubleheure_matieres
    ADD CONSTRAINT planning_doubleheure_matiere_id_6b0cff3d_fk_planning_ FOREIGN KEY (matiere_id) REFERENCES public.planning_matiere(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: planning_doubleheure planning_doubleheure_matiere_id_b74c818a_fk_planning_matiere_id; Type: FK CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_doubleheure
    ADD CONSTRAINT planning_doubleheure_matiere_id_b74c818a_fk_planning_matiere_id FOREIGN KEY (matiere_id) REFERENCES public.planning_matiere(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: planning_etudiant planning_etudiant_option_id_9f2eb588_fk_planning_classe_id; Type: FK CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_etudiant
    ADD CONSTRAINT planning_etudiant_option_id_9f2eb588_fk_planning_classe_id FOREIGN KEY (option_id) REFERENCES public.planning_classe(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: planning_etudiant planning_etudiant_personne_ptr_id_717d8a28_fk_planning_; Type: FK CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_etudiant
    ADD CONSTRAINT planning_etudiant_personne_ptr_id_717d8a28_fk_planning_ FOREIGN KEY (personne_ptr_id) REFERENCES public.planning_personne(user_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: planning_filiere planning_filiere_departement_id_15822774_fk_planning_; Type: FK CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_filiere
    ADD CONSTRAINT planning_filiere_departement_id_15822774_fk_planning_ FOREIGN KEY (departement_id) REFERENCES public.planning_departement(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: planning_filiere planning_filiere_responsable_niveau_i_c4ad04c4_fk_planning_; Type: FK CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_filiere
    ADD CONSTRAINT planning_filiere_responsable_niveau_i_c4ad04c4_fk_planning_ FOREIGN KEY (responsable_niveau_id) REFERENCES public.planning_responsableniveau(professeur_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: planning_jour planning_jour_planning_id_8656a5b7_fk_planning_; Type: FK CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_jour
    ADD CONSTRAINT planning_jour_planning_id_8656a5b7_fk_planning_ FOREIGN KEY (planning_id) REFERENCES public.planning_planningsemaine(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: planning_matiere planning_matiere_module_id_99d07074_fk_planning_module_id; Type: FK CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_matiere
    ADD CONSTRAINT planning_matiere_module_id_99d07074_fk_planning_module_id FOREIGN KEY (module_id) REFERENCES public.planning_module(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: planning_matiere planning_matiere_option_id_80d0e787_fk_planning_classe_id; Type: FK CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_matiere
    ADD CONSTRAINT planning_matiere_option_id_80d0e787_fk_planning_classe_id FOREIGN KEY (option_id) REFERENCES public.planning_classe(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: planning_matiere planning_matiere_professeur_id_69f9a1ba_fk_planning_; Type: FK CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_matiere
    ADD CONSTRAINT planning_matiere_professeur_id_69f9a1ba_fk_planning_ FOREIGN KEY (professeur_id) REFERENCES public.planning_professeur(personne_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: planning_module planning_module_departement_id_5d37c084_fk_planning_; Type: FK CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_module
    ADD CONSTRAINT planning_module_departement_id_5d37c084_fk_planning_ FOREIGN KEY (departement_id) REFERENCES public.planning_departement(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: planning_parent_enfants planning_parent_enfa_etudiant_id_fc7a14b6_fk_planning_; Type: FK CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_parent_enfants
    ADD CONSTRAINT planning_parent_enfa_etudiant_id_fc7a14b6_fk_planning_ FOREIGN KEY (etudiant_id) REFERENCES public.planning_etudiant(personne_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: planning_parent_enfants planning_parent_enfa_parent_id_4a7b63a8_fk_planning_; Type: FK CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_parent_enfants
    ADD CONSTRAINT planning_parent_enfa_parent_id_4a7b63a8_fk_planning_ FOREIGN KEY (parent_id) REFERENCES public.planning_parent(personne_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: planning_parent planning_parent_personne_ptr_id_243b2748_fk_planning_; Type: FK CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_parent
    ADD CONSTRAINT planning_parent_personne_ptr_id_243b2748_fk_planning_ FOREIGN KEY (personne_ptr_id) REFERENCES public.planning_personne(user_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: planning_personne planning_personne_user_ptr_id_441cd987_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_personne
    ADD CONSTRAINT planning_personne_user_ptr_id_441cd987_fk_auth_user_id FOREIGN KEY (user_ptr_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: planning_planningsemaine planning_planningsem_classe_id_72eca369_fk_planning_; Type: FK CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_planningsemaine
    ADD CONSTRAINT planning_planningsem_classe_id_72eca369_fk_planning_ FOREIGN KEY (classe_id) REFERENCES public.planning_classe(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: planning_planningsemaine planning_planningsem_responsable_niveau_i_8c2e6980_fk_planning_; Type: FK CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_planningsemaine
    ADD CONSTRAINT planning_planningsem_responsable_niveau_i_8c2e6980_fk_planning_ FOREIGN KEY (responsable_niveau_id) REFERENCES public.planning_professeur(personne_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: planning_planningsemaine planning_planningsem_semestre_id_fb399a52_fk_planning_; Type: FK CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_planningsemaine
    ADD CONSTRAINT planning_planningsem_semestre_id_fb399a52_fk_planning_ FOREIGN KEY (semestre_id) REFERENCES public.planning_semestre(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: planning_professeur planning_professeur_personne_ptr_id_1273ec4d_fk_planning_; Type: FK CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_professeur
    ADD CONSTRAINT planning_professeur_personne_ptr_id_1273ec4d_fk_planning_ FOREIGN KEY (personne_ptr_id) REFERENCES public.planning_personne(user_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: planning_responsableniveau planning_responsable_professeur_ptr_id_3d9dacbe_fk_planning_; Type: FK CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_responsableniveau
    ADD CONSTRAINT planning_responsable_professeur_ptr_id_3d9dacbe_fk_planning_ FOREIGN KEY (professeur_ptr_id) REFERENCES public.planning_professeur(personne_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: planning_ressource planning_ressource_classe_id_aa387e50_fk_planning_classe_id; Type: FK CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_ressource
    ADD CONSTRAINT planning_ressource_classe_id_aa387e50_fk_planning_classe_id FOREIGN KEY (classe_id) REFERENCES public.planning_classe(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: planning_ressource planning_ressource_departement_id_f564f50a_fk_planning_; Type: FK CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_ressource
    ADD CONSTRAINT planning_ressource_departement_id_f564f50a_fk_planning_ FOREIGN KEY (departement_id) REFERENCES public.planning_departement(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: planning_semestre planning_semestre_annee_id_aa508d9a_fk_planning_; Type: FK CONSTRAINT; Schema: public; Owner: leprince
--

ALTER TABLE ONLY public.planning_semestre
    ADD CONSTRAINT planning_semestre_annee_id_aa508d9a_fk_planning_ FOREIGN KEY (annee_id) REFERENCES public.planning_anneeacademique(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

